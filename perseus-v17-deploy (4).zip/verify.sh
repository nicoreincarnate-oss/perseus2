#!/bin/bash
set -euo pipefail

# ─── PERSEUS V17 System Verification ─────────────────────────────────
# Checks all components are running and healthy

BOLD='\033[1m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASS=0
FAIL=0
WARN=0

ok()   { echo -e "  ${GREEN}✓${NC} $*"; ((PASS++)); }
fail() { echo -e "  ${RED}✗${NC} $*"; ((FAIL++)); }
warn() { echo -e "  ${YELLOW}⚠${NC} $*"; ((WARN++)); }

echo -e "\n${BOLD}PERSEUS V17 — System Verification${NC}\n"
echo "Running at: $(date)"
echo ""

# ── Docker Containers ──
echo -e "${BOLD}Docker Containers${NC}"
for SVC in postgres qdrant mem0 n8n; do
    CONTAINER="perseus-$SVC"
    if docker inspect "$CONTAINER" &>/dev/null; then
        STATE=$(docker inspect --format='{{.State.Status}}' "$CONTAINER")
        HEALTH=$(docker inspect --format='{{.State.Health.Status}}' "$CONTAINER" 2>/dev/null || echo "no healthcheck")
        if [[ "$STATE" == "running" && "$HEALTH" == "healthy" ]]; then
            ok "$SVC: running + healthy"
        elif [[ "$STATE" == "running" ]]; then
            warn "$SVC: running but health=$HEALTH"
        else
            fail "$SVC: $STATE"
        fi
    else
        fail "$SVC: container not found"
    fi
done

# Check crewai and pinchtab (built images)
for SVC in crewai pinchtab; do
    CONTAINER="perseus-$SVC"
    if docker inspect "$CONTAINER" &>/dev/null; then
        STATE=$(docker inspect --format='{{.State.Status}}' "$CONTAINER")
        if [[ "$STATE" == "running" ]]; then
            ok "$SVC: running"
        else
            warn "$SVC: $STATE"
        fi
    else
        warn "$SVC: not deployed yet (needs docker compose build)"
    fi
done

# ── Ollama ──
echo -e "\n${BOLD}Ollama${NC}"
if curl -sf http://localhost:11434/api/tags &>/dev/null; then
    ok "Ollama server responding on :11434"
    MODELS=$(curl -sf http://localhost:11434/api/tags | jq -r '.models[].name' 2>/dev/null || echo "")
    for MODEL in "qwen2.5:14b-instruct-q4_K_M" "llama3.2:3b" "nomic-embed-text"; do
        if echo "$MODELS" | grep -q "$MODEL"; then
            ok "Model loaded: $MODEL"
        else
            fail "Model missing: $MODEL"
        fi
    done
else
    fail "Ollama not responding on :11434"
fi

# ── Hermes Agent ──
echo -e "\n${BOLD}Hermes Agent${NC}"
if command -v hermes &>/dev/null; then
    ok "Hermes binary found: $(which hermes)"
    HERMES_VER=$(hermes --version 2>/dev/null || echo "unknown")
    ok "Hermes version: $HERMES_VER"
else
    fail "Hermes binary not found"
fi

if [[ -f "$HOME/.hermes/SOUL.md" ]]; then
    ok "SOUL.md persona file exists"
else
    fail "SOUL.md not found at ~/.hermes/SOUL.md"
fi

if [[ -f "$HOME/.hermes/config.env" ]]; then
    ok "Hermes config.env exists"
else
    warn "Hermes config.env not found — may use environment variables instead"
fi

# ── Port Availability ──
echo -e "\n${BOLD}Port Truth Table${NC}"
declare -A PORTS=(
    ["Postgres"]=5432
    ["Qdrant"]=6333
    ["Mem0"]=8888
    ["CrewAI"]=8001
    ["N8N"]=5678
    ["Pinchtab"]=9867
    ["Ollama"]=11434
)

for NAME in "${!PORTS[@]}"; do
    PORT=${PORTS[$NAME]}
    if lsof -i ":$PORT" &>/dev/null || nc -z localhost "$PORT" 2>/dev/null; then
        ok "$NAME: port $PORT listening"
    else
        warn "$NAME: port $PORT not listening"
    fi
done

# ── Database ──
echo -e "\n${BOLD}Database${NC}"
TABLE_COUNT=$(docker exec perseus-postgres psql -U perseus -d perseus -t -c \
    "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | tr -d ' ' || echo "0")
if (( TABLE_COUNT >= 7 )); then
    ok "Postgres schema initialized ($TABLE_COUNT tables)"
else
    warn "Postgres has $TABLE_COUNT tables (expected 7+)"
fi

# ── Environment ──
echo -e "\n${BOLD}Environment${NC}"
if [[ -f .env ]]; then
    ok ".env file exists"
    # Check for placeholder values
    PLACEHOLDERS=$(grep -c "CHANGE_ME" .env 2>/dev/null || echo "0")
    if (( PLACEHOLDERS > 0 )); then
        warn "$PLACEHOLDERS placeholder values still in .env (search for CHANGE_ME)"
    else
        ok "No placeholder values in .env"
    fi
else
    fail ".env file not found"
fi

# ── Backups ──
echo -e "\n${BOLD}Backups${NC}"
if [[ -f backup.sh ]]; then
    ok "backup.sh exists"
    if [[ -x backup.sh ]]; then
        ok "backup.sh is executable"
    else
        warn "backup.sh is not executable (run: chmod +x backup.sh)"
    fi
else
    fail "backup.sh not found"
fi

if crontab -l 2>/dev/null | grep -q "backup.sh"; then
    ok "Backup cron job installed"
else
    warn "No backup cron job found (run setup-wizard.sh or add manually)"
fi

# ── Summary ──
echo -e "\n${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${GREEN}PASS:${NC} $PASS    ${RED}FAIL:${NC} $FAIL    ${YELLOW}WARN:${NC} $WARN"

TOTAL=$((PASS + FAIL + WARN))
if (( FAIL == 0 )); then
    echo -e "\n  ${GREEN}${BOLD}SYSTEM READY${NC}"
    exit 0
elif (( FAIL <= 2 )); then
    echo -e "\n  ${YELLOW}${BOLD}SYSTEM PARTIALLY READY — fix failures above${NC}"
    exit 1
else
    echo -e "\n  ${RED}${BOLD}SYSTEM NOT READY — multiple failures${NC}"
    exit 2
fi
