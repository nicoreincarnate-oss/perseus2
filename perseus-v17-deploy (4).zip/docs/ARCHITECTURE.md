# PERSEUS Architecture Overview

See PERSEUS_V17.md Section B for complete technical documentation.

## Port Truth Table

| Service | Port |
|---------|------|
| Postgres | 5432 |
| Qdrant | 6333 |
| Mem0 | 8888 |
| CrewAI | 8001 |
| N8N | 5678 |
| Pinchtab | 9867 |
| Ollama | 11434 |
