"""
PERSEUS V17 — CrewAI Service
Main entrypoint for the 30-agent orchestration system.

Districts:
  1. Sales (5 agents)      — Lead Gen, Cold Outreach, Proposal Writer, Follow-Up, Pipeline Manager
  2. Delivery (5 agents)   — Site Planner, Code Generator, QA Reviewer, Deployer, Client Reporter
  3. Operations (5 agents) — Email Router, Invoice Manager, Client Onboarder, Nightly Reviewer, Budget Sentinel
  4. Learning (2 agents)   — Reflection Engine, Prompt Optimizer
  5. Evolution (5 agents)  — A/B Tester, Template Evolver, Pricing Optimizer, Market Scanner, Competitor Tracker
  6. Self-Awareness (3 agents)  — Code Auditor, Env Validator, Builder Test Enforcer
  7. Enterprise (5 agents) — DORMANT until MRR >= $8,000

Hermes Agent is NOT built by PERSEUS. It is installed externally via:
  curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
"""

import os
import logging
from contextlib import asynccontextmanager
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Ollama connection ──────────────────────────────────────────────
OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://host.docker.internal:11434/v1")
PRIMARY_MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")
SECONDARY_MODEL = os.getenv("OLLAMA_SECONDARY", "llama3.2:3b")
EMBED_MODEL = os.getenv("OLLAMA_EMBED", "nomic-embed-text")

# ── Enterprise activation gate ─────────────────────────────────────
ENTERPRISE_MRR_GATE = 8000  # USD — enterprise agents stay dormant below this


# ═══════════════════════════════════════════════════════════════════
# CREW REGISTRY — All 30 agents mapped to their crew modules
# ═══════════════════════════════════════════════════════════════════

CREW_REGISTRY: dict[str, dict[str, Any]] = {
    # ── District 1: Sales (5 agents) ──────────────────────────────
    "lead_gen": {
        "module": "crews.sales_crew",
        "function": "run_lead_gen",
        "district": "sales",
        "description": "Scrapes Google Maps, Yelp, industry directories for leads matching ICP",
    },
    "cold_outreach": {
        "module": "crews.sales_crew",
        "function": "run_cold_outreach",
        "district": "sales",
        "description": "Writes 3-email sequences per industry via Smartlead",
    },
    "proposal_writer": {
        "module": "crews.sales_crew",
        "function": "run_proposal_writer",
        "district": "sales",
        "description": "Generates PDF proposals with pricing, timeline, scope for qualified leads",
    },
    "follow_up": {
        "module": "crews.sales_crew",
        "function": "run_follow_up",
        "district": "sales",
        "description": "Sends follow-up sequences, handles objections, books calls",
    },
    "pipeline_manager": {
        "module": "crews.sales_crew",
        "function": "run_pipeline_manager",
        "district": "sales",
        "description": "Tracks lead→prospect→proposal→signed→building→delivered→hosting pipeline",
    },

    # ── District 2: Delivery (5 agents) ──────────────────────────
    "site_planner": {
        "module": "crews.site_builder_crew",
        "function": "run_site_planner",
        "district": "delivery",
        "description": "Creates sitemap, wireframe, content plan from client brief",
    },
    "code_generator": {
        "module": "crews.site_builder_crew",
        "function": "run_code_generator",
        "district": "delivery",
        "description": "Generates production HTML/CSS/JS using TITAN engine + industry templates",
    },
    "qa_reviewer": {
        "module": "crews.site_builder_crew",
        "function": "run_qa_reviewer",
        "district": "delivery",
        "description": "Lighthouse audit, mobile check, accessibility, link validation",
    },
    "deployer": {
        "module": "crews.site_builder_crew",
        "function": "run_deployer",
        "district": "delivery",
        "description": "Deploys to Netlify, configures DNS, SSL, CDN",
    },
    "client_reporter": {
        "module": "crews.site_builder_crew",
        "function": "run_client_reporter",
        "district": "delivery",
        "description": "Sends progress updates, delivery confirmation, handoff docs to client",
    },

    # ── District 3: Operations (5 agents) ────────────────────────
    "email_router": {
        "module": "crews.email_crew",
        "function": "run_email_router",
        "district": "operations",
        "description": "Classifies incoming email, routes to correct agent/queue",
    },
    "invoice_manager": {
        "module": "crews.email_crew",
        "function": "run_invoice_manager",
        "district": "operations",
        "description": "Generates Wise invoices, tracks payment, sends reminders",
    },
    "client_onboarder": {
        "module": "crews.client_onboard_crew",
        "function": "run_client_onboarder",
        "district": "operations",
        "description": "Collects client assets (logo, photos, copy), creates project folder, kicks off build",
    },
    "nightly_reviewer": {
        "module": "crews.nightly_review_crew",
        "function": "run_nightly_reviewer",
        "district": "operations",
        "description": "11 PM nightly: reviews day metrics, updates pipeline, generates tomorrow priorities",
    },
    "budget_sentinel": {
        "module": "crews.nightly_review_crew",
        "function": "run_budget_sentinel",
        "district": "operations",
        "description": "Enforces $600/mo hard cap, alerts at 80% threshold, kills GPU instances at budget",
    },

    # ── District 4: Learning (2 agents) ──────────────────────────
    "reflection_engine": {
        "module": "crews.learning_crew",
        "function": "run_reflection_engine",
        "district": "learning",
        "description": "Weekly: analyzes wins/losses, updates Mem0 with lessons learned",
    },
    "prompt_optimizer": {
        "module": "crews.learning_crew",
        "function": "run_prompt_optimizer",
        "district": "learning",
        "description": "A/B tests prompt variants, measures conversion, promotes winners",
    },

    # ── District 5: Evolution (5 agents) ─────────────────────────
    "ab_tester": {
        "module": "crews.evolution_crew",
        "function": "run_ab_tester",
        "district": "evolution",
        "description": "Runs A/B tests on email subject lines, site layouts, CTAs",
    },
    "template_evolver": {
        "module": "crews.evolution_crew",
        "function": "run_template_evolver",
        "district": "evolution",
        "description": "Evolves industry templates based on conversion data",
    },
    "pricing_optimizer": {
        "module": "crews.evolution_crew",
        "function": "run_pricing_optimizer",
        "district": "evolution",
        "description": "Monitors market rates, suggests pricing adjustments (human-approved)",
    },
    "market_scanner": {
        "module": "crews.evolution_crew",
        "function": "run_market_scanner",
        "district": "evolution",
        "description": "Weekly: scans market trends, new niches, emerging opportunities",
    },
    "competitor_tracker": {
        "module": "crews.evolution_crew",
        "function": "run_competitor_tracker",
        "district": "evolution",
        "description": "Monitors competitor pricing, features, positioning changes",
    },

    # ── District 6: Self-Awareness (3 agents) ────────────────────
    "code_auditor": {
        "module": "crews.self_awareness_crew",
        "function": "run_code_auditor",
        "district": "self_awareness",
        "description": "Reviews generated code for security, performance, accessibility issues",
    },
    "env_validator": {
        "module": "crews.self_awareness_crew",
        "function": "run_env_validator",
        "district": "self_awareness",
        "description": "Validates .env, Docker health, Ollama models, disk/RAM on startup and hourly",
    },
    "builder_test_enforcer": {
        "module": "crews.self_awareness_crew",
        "function": "run_builder_test_enforcer",
        "district": "self_awareness",
        "description": "Ensures every generated site passes Lighthouse >90, mobile-friendly, no broken links",
    },

    # ── District 7: Enterprise (5 agents) — DORMANT ──────────────
    "enterprise_account_manager": {
        "module": "crews.enterprise_crew",
        "function": "run_enterprise_account_manager",
        "district": "enterprise",
        "dormant": True,
        "activation_gate": f"MRR >= ${ENTERPRISE_MRR_GATE}",
        "description": "Manages enterprise client relationships, SLAs, escalations",
    },
    "enterprise_custom_builder": {
        "module": "crews.enterprise_crew",
        "function": "run_enterprise_custom_builder",
        "district": "enterprise",
        "dormant": True,
        "activation_gate": f"MRR >= ${ENTERPRISE_MRR_GATE}",
        "description": "Builds custom multi-page sites with CMS, e-commerce, booking systems",
    },
    "enterprise_sla_monitor": {
        "module": "crews.enterprise_crew",
        "function": "run_enterprise_sla_monitor",
        "district": "enterprise",
        "dormant": True,
        "activation_gate": f"MRR >= ${ENTERPRISE_MRR_GATE}",
        "description": "Monitors uptime SLAs, response time SLAs, triggers escalation on breach",
    },
    "enterprise_analytics": {
        "module": "crews.enterprise_crew",
        "function": "run_enterprise_analytics",
        "district": "enterprise",
        "dormant": True,
        "activation_gate": f"MRR >= ${ENTERPRISE_MRR_GATE}",
        "description": "Advanced analytics dashboards, conversion tracking, ROI reports for enterprise clients",
    },
    "enterprise_integrations": {
        "module": "crews.enterprise_crew",
        "function": "run_enterprise_integrations",
        "district": "enterprise",
        "dormant": True,
        "activation_gate": f"MRR >= ${ENTERPRISE_MRR_GATE}",
        "description": "CRM sync, booking system integration, POS integration for enterprise clients",
    },
}


# ═══════════════════════════════════════════════════════════════════
# Request models
# ═══════════════════════════════════════════════════════════════════

class GenerateSiteRequest(BaseModel):
    client_name: str
    business_name: str
    industry: str
    services: list[str]
    location: str = ""
    phone: str = ""
    color_preference: str = "auto"
    notes: str = ""


class GenerateCopyRequest(BaseModel):
    prompt: str
    context: str = ""
    max_tokens: int = 500


class CrewRunRequest(BaseModel):
    crew_name: str
    inputs: dict = {}


class AgentStatusResponse(BaseModel):
    name: str
    district: str
    status: str
    description: str


# ═══════════════════════════════════════════════════════════════════
# App lifecycle
# ═══════════════════════════════════════════════════════════════════

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown logic."""
    active = sum(1 for v in CREW_REGISTRY.values() if not v.get("dormant"))
    dormant = sum(1 for v in CREW_REGISTRY.values() if v.get("dormant"))
    logger.info("=" * 60)
    logger.info("PERSEUS CrewAI Service v17.0 starting...")
    logger.info(f"  Ollama URL:      {OLLAMA_URL}")
    logger.info(f"  Primary model:   {PRIMARY_MODEL}")
    logger.info(f"  Secondary model: {SECONDARY_MODEL}")
    logger.info(f"  Embed model:     {EMBED_MODEL}")
    logger.info(f"  Active agents:   {active}")
    logger.info(f"  Dormant agents:  {dormant} (enterprise, MRR gate: ${ENTERPRISE_MRR_GATE})")
    logger.info(f"  Total agents:    {len(CREW_REGISTRY)}")
    logger.info("=" * 60)
    yield
    logger.info("PERSEUS CrewAI service shutting down...")


app = FastAPI(
    title="PERSEUS CrewAI Service",
    description="30-agent autonomous business operating system",
    version="17.0",
    lifespan=lifespan,
)


# ═══════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════

@app.get("/api/health")
async def health():
    """Health check endpoint."""
    active = sum(1 for v in CREW_REGISTRY.values() if not v.get("dormant"))
    return {
        "status": "healthy",
        "service": "perseus-crewai",
        "version": "17.0",
        "model": PRIMARY_MODEL,
        "agents_active": active,
        "agents_total": len(CREW_REGISTRY),
    }


@app.get("/api/agents")
async def list_agents():
    """List all registered agents and their status."""
    agents = []
    for name, config in CREW_REGISTRY.items():
        is_dormant = config.get("dormant", False)
        agents.append({
            "name": name,
            "district": config["district"],
            "status": "dormant" if is_dormant else "active",
            "description": config["description"],
            "activation_gate": config.get("activation_gate", None),
        })
    return {
        "total": len(agents),
        "active": sum(1 for a in agents if a["status"] == "active"),
        "dormant": sum(1 for a in agents if a["status"] == "dormant"),
        "agents": agents,
    }


@app.get("/api/agents/district/{district}")
async def list_district_agents(district: str):
    """List agents in a specific district."""
    agents = [
        {"name": name, "status": "dormant" if c.get("dormant") else "active", "description": c["description"]}
        for name, c in CREW_REGISTRY.items()
        if c["district"] == district
    ]
    if not agents:
        raise HTTPException(status_code=404, detail=f"Unknown district: {district}")
    return {"district": district, "agents": agents}


@app.post("/api/generate-site")
async def generate_site(req: GenerateSiteRequest):
    """Trigger TITAN website generation pipeline (5 Delivery district agents)."""
    logger.info(f"Site generation request: {req.business_name} ({req.industry})")

    try:
        from crews.site_builder_crew import run_site_builder
        result = run_site_builder(
            client_name=req.client_name,
            business_name=req.business_name,
            industry=req.industry,
            services=req.services,
            location=req.location,
            phone=req.phone,
            color_preference=req.color_preference,
            notes=req.notes,
        )
        return {"status": "success", "result": result}
    except Exception as e:
        logger.error(f"Site generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/generate-copy")
async def generate_copy(req: GenerateCopyRequest):
    """Generate copy using Qwen via Ollama."""
    import requests as http_requests

    try:
        resp = http_requests.post(
            f"{OLLAMA_URL.replace('/v1', '')}/api/generate",
            json={
                "model": PRIMARY_MODEL,
                "prompt": req.prompt,
                "system": req.context,
                "stream": False,
                "options": {"num_predict": req.max_tokens},
            },
            timeout=120,
        )
        resp.raise_for_status()
        return {"status": "success", "text": resp.json().get("response", "")}
    except Exception as e:
        logger.error(f"Copy generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/pipeline/status")
async def pipeline_status():
    """Get current sales pipeline status."""
    try:
        from tools.metrics_collector import get_pipeline_status
        return get_pipeline_status()
    except Exception as e:
        logger.error(f"Pipeline status failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/crew/run")
async def run_crew(req: CrewRunRequest):
    """Execute any registered crew agent by name.
    
    Looks up the agent in CREW_REGISTRY, dynamically imports its module,
    and calls the registered function. Enterprise agents are blocked until
    the MRR gate is met.
    """
    logger.info(f"Crew run request: {req.crew_name}")

    if req.crew_name not in CREW_REGISTRY:
        available = [k for k, v in CREW_REGISTRY.items() if not v.get("dormant")]
        raise HTTPException(
            status_code=400,
            detail=f"Unknown crew: {req.crew_name}. Active crews: {available}"
        )

    config = CREW_REGISTRY[req.crew_name]

    # Enterprise gate check
    if config.get("dormant", False):
        raise HTTPException(
            status_code=403,
            detail=f"Agent '{req.crew_name}' is dormant. Activation requires: {config.get('activation_gate', 'unknown')}. "
                   f"No enterprise sales for first 9 months."
        )

    try:
        import importlib
        module = importlib.import_module(config["module"])
        func = getattr(module, config["function"])
        result = func(req.inputs)
        return {"status": "success", "crew": req.crew_name, "district": config["district"], "result": result}
    except Exception as e:
        logger.error(f"Crew {req.crew_name} failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/nightly-review")
async def trigger_nightly_review():
    """Manually trigger the nightly review cycle."""
    logger.info("Manual nightly review triggered")
    try:
        from crews.nightly_review_crew import run_nightly_reviewer
        result = run_nightly_reviewer({})
        return {"status": "success", "result": result}
    except Exception as e:
        logger.error(f"Nightly review failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/morning-briefing")
async def trigger_morning_briefing():
    """Generate morning briefing for Hermes to deliver via Telegram."""
    logger.info("Morning briefing requested")
    try:
        from crews.nightly_review_crew import generate_morning_briefing
        result = generate_morning_briefing()
        return {"status": "success", "briefing": result}
    except Exception as e:
        logger.error(f"Morning briefing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
