"""
PERSEUS V17 — Operations District: Email & Invoice Agents

Agents:
  - Email Router: Classifies incoming email, routes to correct queue
  - Invoice Manager: Generates Wise invoices, tracks payment, sends reminders

Pricing (non-negotiable):
  Simple 5-page website: $332
  Landing page: $265
  E-commerce: $1,330
  Logo + brand: $130
  AI chatbot: $398
  Hosting: $52/mo
  Social media: $130/mo

All payments via Wise Business → MXN bank account. NO crypto. NO USDC.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Any

from crewai import Agent, Task, Crew, Process

logger = logging.getLogger(__name__)

OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://host.docker.internal:11434/v1")
PRIMARY_MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")
SECONDARY_MODEL = os.getenv("OLLAMA_SECONDARY", "llama3.2:3b")

# ── Pricing constants (non-negotiable) ─────────────────────────────
PRICING = {
    "simple_website": 332,
    "landing_page": 265,
    "ecommerce": 1330,
    "logo_brand": 130,
    "ai_chatbot": 398,
    "hosting_monthly": 52,
    "social_media_monthly": 130,
}

# ── Email categories ───────────────────────────────────────────────
EMAIL_CATEGORIES = {
    "new_lead": {"priority": "high", "route_to": "sales_crew.cold_outreach"},
    "client_question": {"priority": "medium", "route_to": "client_onboard_crew"},
    "payment_inquiry": {"priority": "high", "route_to": "invoice_manager"},
    "revision_request": {"priority": "medium", "route_to": "site_builder_crew"},
    "support_request": {"priority": "medium", "route_to": "nightly_review_crew"},
    "spam": {"priority": "low", "route_to": "archive"},
    "personal": {"priority": "low", "route_to": "inbox"},
}


def _create_email_router_agent() -> Agent:
    """Create the Email Router agent."""
    return Agent(
        role="Email Router",
        goal="Classify every incoming email and route it to the correct PERSEUS agent or queue within 30 seconds",
        backstory=(
            "You are the central nervous system of PERSEUS email operations. "
            "Every email that arrives gets classified by you — new leads go to Sales, "
            "payment questions go to Invoice Manager, revision requests go to Delivery, "
            "and spam gets archived. You never miss an email and you never misroute."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
        allow_delegation=True,
    )


def _create_invoice_manager_agent() -> Agent:
    """Create the Invoice Manager agent."""
    return Agent(
        role="Invoice Manager",
        goal="Generate accurate Wise Business invoices, track all payments, and send friendly reminders for overdue invoices",
        backstory=(
            "You manage all PERSEUS invoicing through Wise Business. "
            "You generate invoices with correct pricing (Simple site: $332, Landing: $265, "
            "E-commerce: $1,330, Logo+brand: $130, AI chatbot: $398, Hosting: $52/mo, Social: $130/mo). "
            "All payments convert to MXN via Wise. No crypto, no USDC, no exceptions. "
            "You send reminders at 3, 7, and 14 days overdue with escalating urgency."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
    )


def run_email_router(inputs: dict = None) -> dict:
    """Classify and route an incoming email.

    Args:
        inputs: {
            "from": "sender@example.com",
            "subject": "Email subject",
            "body": "Email body text",
            "received_at": "ISO timestamp"
        }

    Returns:
        Dict with classification, priority, route, and suggested action
    """
    inputs = inputs or {}
    logger.info(f"Email Router processing: {inputs.get('subject', 'no subject')}")

    router = _create_email_router_agent()

    classify_task = Task(
        description=(
            f"Classify this email and determine the correct routing:\n\n"
            f"From: {inputs.get('from', 'unknown')}\n"
            f"Subject: {inputs.get('subject', 'no subject')}\n"
            f"Body: {inputs.get('body', 'empty')[:500]}\n\n"
            f"Categories: {list(EMAIL_CATEGORIES.keys())}\n"
            f"Return: category, priority (high/medium/low), route_to agent, "
            f"and a one-line suggested action."
        ),
        expected_output="JSON with category, priority, route_to, and suggested_action",
        agent=router,
    )

    crew = Crew(
        agents=[router],
        tasks=[classify_task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    return {
        "status": "completed",
        "crew": "email_router",
        "email_from": inputs.get("from", "unknown"),
        "email_subject": inputs.get("subject", "no subject"),
        "classification": str(result),
        "processed_at": datetime.utcnow().isoformat(),
    }


def run_invoice_manager(inputs: dict = None) -> dict:
    """Generate or manage an invoice via Wise Business.

    Args:
        inputs: {
            "action": "create" | "remind" | "status",
            "client_name": "Business Name",
            "client_email": "client@example.com",
            "service": "simple_website" | "landing_page" | "ecommerce" | etc.,
            "invoice_id": "INV-001" (for remind/status actions)
        }

    Returns:
        Dict with invoice details, amount, status
    """
    inputs = inputs or {}
    action = inputs.get("action", "create")
    logger.info(f"Invoice Manager: {action} for {inputs.get('client_name', 'unknown')}")

    invoicer = _create_invoice_manager_agent()

    service = inputs.get("service", "simple_website")
    amount = PRICING.get(service, PRICING["simple_website"])

    if action == "create":
        task_desc = (
            f"Generate a Wise Business invoice for:\n"
            f"Client: {inputs.get('client_name', 'Unknown Client')}\n"
            f"Email: {inputs.get('client_email', 'unknown')}\n"
            f"Service: {service}\n"
            f"Amount: ${amount} USD\n"
            f"Payment method: Wise Business transfer to MXN bank account\n"
            f"Due date: {(datetime.utcnow() + timedelta(days=14)).strftime('%Y-%m-%d')}\n\n"
            f"Create the invoice with professional formatting. Include PERSEUS branding."
        )
    elif action == "remind":
        task_desc = (
            f"Send a friendly payment reminder for invoice {inputs.get('invoice_id', 'unknown')}:\n"
            f"Client: {inputs.get('client_name', 'Unknown')}\n"
            f"Amount: ${amount}\n"
            f"Payment: Wise Business transfer\n\n"
            f"Tone: warm but clear. Include payment instructions."
        )
    else:
        task_desc = f"Check status of invoice {inputs.get('invoice_id', 'unknown')} via Wise API."

    invoice_task = Task(
        description=task_desc,
        expected_output="Invoice details with amount, due date, and payment instructions",
        agent=invoicer,
    )

    crew = Crew(
        agents=[invoicer],
        tasks=[invoice_task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    return {
        "status": "completed",
        "crew": "invoice_manager",
        "action": action,
        "client": inputs.get("client_name", "unknown"),
        "service": service,
        "amount_usd": amount,
        "payment_method": "Wise Business → MXN",
        "result": str(result),
        "processed_at": datetime.utcnow().isoformat(),
    }


# Legacy compatibility — maps to email_router
def run(inputs: dict = None) -> dict:
    """Legacy entry point for backward compatibility."""
    return run_email_router(inputs)
