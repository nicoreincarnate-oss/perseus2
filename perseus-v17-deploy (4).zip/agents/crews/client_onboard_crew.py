"""
PERSEUS V17 — Operations District: Client Onboarding

Agent:
  - Client Onboarder: Collects client assets (logo, photos, copy), creates project
    folder, sends welcome kit, kicks off the site build pipeline.

Onboarding flow:
  1. Receive signed contract + payment confirmation
  2. Send welcome email with asset request checklist
  3. Create project folder in Postgres (client record + project record)
  4. Track asset collection (logo, photos, copy, branding guidelines)
  5. When assets complete → trigger site_builder_crew pipeline
  6. Send "build started" notification via Telegram

Pricing (final, non-negotiable):
  Simple 5-page website: $332
  Landing page: $265
  E-commerce: $1,330
  Logo + brand: $130
  AI chatbot: $398
  Hosting: $52/mo
  Social media: $130/mo
"""

import os
import json
import logging
from datetime import datetime
from typing import Any

from crewai import Agent, Task, Crew, Process

logger = logging.getLogger(__name__)

OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://host.docker.internal:11434/v1")
PRIMARY_MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")

# ── Required assets checklist ──────────────────────────────────────
REQUIRED_ASSETS = {
    "simple_website": [
        "business_name", "owner_name", "phone", "email", "address",
        "services_list", "logo", "photos", "brand_colors", "tagline",
    ],
    "landing_page": [
        "business_name", "owner_name", "phone", "email",
        "main_offer", "logo", "hero_image", "cta_text",
    ],
    "ecommerce": [
        "business_name", "owner_name", "phone", "email", "address",
        "product_catalog", "logo", "photos", "brand_colors",
        "payment_processor", "shipping_info",
    ],
    "logo_brand": [
        "business_name", "industry", "target_audience",
        "color_preferences", "style_references",
    ],
}

# ── Asset collection status ────────────────────────────────────────
ASSET_STATUS = ["pending", "requested", "partial", "complete"]


def _create_client_onboarder() -> Agent:
    """Create the Client Onboarder agent."""
    return Agent(
        role="Client Onboarder",
        goal="Collect all required client assets, create the project record, and kick off the build pipeline",
        backstory=(
            "You are the bridge between Sales and Delivery. When a client signs, "
            "you take over: send the welcome email, request their assets (logo, photos, "
            "services list, branding), track collection progress, and when everything is "
            "in, you create the project in Postgres and trigger the site build pipeline. "
            "You are warm, professional, and persistent — you follow up every 48 hours "
            "for missing assets."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
        allow_delegation=True,
    )


def run_client_onboarder(inputs: dict = None) -> dict:
    """Onboard a new client after contract signing.

    Args:
        inputs: {
            "client_name": "Owner Name",
            "business_name": "Business Name",
            "client_email": "client@example.com",
            "service": "simple_website" | "landing_page" | "ecommerce" | "logo_brand",
            "industry": "plumber" | "dentist" | "restaurant" | etc.,
            "contract_signed": True,
            "payment_confirmed": True,
            "notes": "Any special requirements"
        }

    Returns:
        Dict with project ID, asset checklist, welcome email, and next steps
    """
    inputs = inputs or {}
    logger.info(f"Client onboarding: {inputs.get('business_name', 'unknown')}")

    service = inputs.get("service", "simple_website")
    required = REQUIRED_ASSETS.get(service, REQUIRED_ASSETS["simple_website"])

    onboarder = _create_client_onboarder()

    # ── Task 1: Create project record ──────────────────────────────
    project_task = Task(
        description=(
            f"Create a new client project record:\n\n"
            f"Client: {inputs.get('client_name', 'Unknown')}\n"
            f"Business: {inputs.get('business_name', 'Unknown')}\n"
            f"Email: {inputs.get('client_email', 'unknown')}\n"
            f"Service: {service}\n"
            f"Industry: {inputs.get('industry', 'general')}\n"
            f"Contract signed: {inputs.get('contract_signed', False)}\n"
            f"Payment confirmed: {inputs.get('payment_confirmed', False)}\n\n"
            f"Required assets: {json.dumps(required)}\n\n"
            f"1. Generate a project ID (format: PRJ-YYYY-NNN)\n"
            f"2. Create the project record in Postgres\n"
            f"3. Initialize asset tracking with status='pending' for each required asset\n"
            f"4. Return the project details"
        ),
        expected_output="Project record with ID, client details, and asset checklist",
        agent=onboarder,
    )

    # ── Task 2: Send welcome email ─────────────────────────────────
    welcome_task = Task(
        description=(
            f"Send a welcome email to {inputs.get('client_name', 'the client')} "
            f"at {inputs.get('client_email', 'their email')}:\n\n"
            f"Include:\n"
            f"1. Welcome and thank you for choosing PERSEUS\n"
            f"2. What to expect: 7-stage build process, ~5-7 business days\n"
            f"3. Asset request checklist: {json.dumps(required)}\n"
            f"4. How to send assets (email or shared folder)\n"
            f"5. Point of contact: Nico\n"
            f"6. Hosting details after delivery: $52/mo via Wise Business\n\n"
            f"Tone: warm, professional, excited to build for them."
        ),
        expected_output="Welcome email ready to send",
        agent=onboarder,
        context=[project_task],
    )

    # ── Execute ────────────────────────────────────────────────────
    crew = Crew(
        agents=[onboarder],
        tasks=[project_task, welcome_task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    return {
        "status": "completed",
        "crew": "client_onboarder",
        "client": inputs.get("client_name", "unknown"),
        "business": inputs.get("business_name", "unknown"),
        "service": service,
        "required_assets": required,
        "asset_status": "pending",
        "result": str(result),
        "onboarded_at": datetime.utcnow().isoformat(),
    }


# Legacy compatibility
def run(inputs: dict = None) -> dict:
    """Legacy entry point."""
    return run_client_onboarder(inputs)
