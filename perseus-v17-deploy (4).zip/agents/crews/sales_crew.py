"""
PERSEUS Sales District Crew
=============================
Manages the 5 sales agents that handle closing, social proof,
voice delivery, client success, and payment routing.

Agents:
  - Sales Closer Agent (Vapi voice + Qwen-backed)
  - Social Showcase Agent (auto 3 posts per delivery)
  - Voice Delivery Agent (Vapi white-label provisioning)
  - Client Success Agent (retention + upsell with 6hr delay)
  - Payment Router Agent (Stripe → Wise → MXN bank)

All revenue flows to Wise Business → MXN bank account.
No crypto. No USDC. No stablecoins.
"""

import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("perseus.crews.sales")

OLLAMA_BASE = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
MEM0_URL = os.getenv("MEM0_URL", "http://localhost:8888")
CREWAI_URL = os.getenv("CREWAI_URL", "http://localhost:8001")


class SalesCloserAgent:
    """
    Handles all inbound discovery calls autonomously for Layer 1 products.
    Closes website + AI receptionist bundles without Nico.

    Tech: Vapi voice agent + custom Qwen-backed persona. ElevenLabs voice synthesis.

    Workflow:
      Before call: Reads full Lead object from Mem0 — niche, city, website quality
                   score, email history, sequence step. Primes context with
                   WinningCallExample samples.
      During call: Runs soul_copy.md conversation flow. Listens for objections,
                   routes to trained responses. Books calendar or closes directly
                   for sub-$1,000 packages.
      After call:  Writes SalesCallLog to Mem0. Updates EmailEvent.closed_won/lost.
                   Fires WorldEvent: sale_closed if won.
                   Passes WinningCallExample or LosingCallExample to Reflection Agent.

    Escalation: Budget > $5,000 or "custom system" → Enterprise lead → Hermes notifies Nico.
    Autonomy: Fully autonomous for Layer 1. No approval gate.
    Skills: Persuasion & Negotiation, Active Listening
    Soul files: soul_values.md, soul_copy.md
    """

    AGENT_ID = "sales_closer"
    SOUL_FILES = ["soul_values", "soul_copy"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    AUTONOMY = "full_layer1"
    ESCALATION_THRESHOLD = 5000  # USD

    def __init__(self, mem0_client, vapi_client=None):
        self.mem0 = mem0_client
        self.vapi = vapi_client

    async def prepare_call_context(self, lead_id: str) -> dict:
        """Load full Lead object + winning examples before call."""
        lead = await self.mem0.get(f"lead:{lead_id}")
        examples = await self.mem0.search("WinningCallExample", limit=5)
        return {
            "lead": lead,
            "winning_examples": examples,
            "soul_loaded": True,
        }

    async def process_call_result(self, lead_id: str, outcome: dict):
        """Post-call processing: log, update, fire events."""
        await self.mem0.add({
            "category": "SalesCallLog",
            "lead_id": lead_id,
            "outcome": outcome.get("result"),  # closed/no_close/callback
            "call_duration": outcome.get("duration"),
            "objections_raised": outcome.get("objections", []),
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

        if outcome.get("result") == "closed":
            await self.mem0.add({
                "category": "WorldEvent",
                "event": "sale_closed",
                "lead_id": lead_id,
                "amount": outcome.get("amount"),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })

        if outcome.get("budget_mentioned", 0) > self.ESCALATION_THRESHOLD:
            logger.warning(f"Enterprise lead detected: {lead_id}, escalating")
            # Hermes picks this up via its own event polling
            await self.mem0.add({
                "category": "WorldEvent",
                "event": "enterprise_lead_detected",
                "lead_id": lead_id,
                "budget_mentioned": outcome["budget_mentioned"],
            })


class SocialShowcaseAgent:
    """
    Turns every delivered website into 3 social posts automatically.

    Trigger: WorldEvent: milestone_hit (via N8N)
    Tech: Blotato API for cross-platform scheduling.

    Workflow:
      1. Pull final site URL + niche + DesignInspiration from Client record
      2. Pinchtab captures 3 screenshots (hero, key section, CTA)
      3. Copywriter writes platform-fit captions using soul_copy.md
         — one for Instagram, one for Facebook, one for LinkedIn
      4. Schedule via Blotato at optimal send times per platform
      5. Write SocialPost record to Mem0
      6. After 48h: read engagement_score back from Blotato → update SocialPost

    Autonomy: Fully autonomous. Fires on every delivery. Never needs approval.
    Soul files: soul_values.md, soul_copy.md
    """

    AGENT_ID = "social_showcase"
    SOUL_FILES = ["soul_values", "soul_copy"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    PLATFORMS = ["instagram", "facebook", "linkedin"]

    def __init__(self, mem0_client, pinchtab_client=None, blotato_client=None):
        self.mem0 = mem0_client
        self.pinchtab = pinchtab_client
        self.blotato = blotato_client

    async def generate_posts(self, client_id: str) -> list:
        """Generate 3 platform-specific posts for a delivered site."""
        client = await self.mem0.get(f"client:{client_id}")
        posts = []
        for platform in self.PLATFORMS:
            posts.append({
                "platform": platform,
                "client_id": client_id,
                "site_url": client.get("site_url"),
                "niche": client.get("niche"),
                "status": "pending_generation",
            })
        return posts


class VoiceDeliveryAgent:
    """
    Adds AI receptionist to every Full Stack client sale automatically.

    Trigger: PaymentLog with package: full_stack
    Tech: Vapi white-label provisioning API.

    Workflow:
      1. PaymentLog entry → triggers this agent
      2. Reads Client record — niche, business name, hours, booking link
      3. Creates Vapi assistant with niche-appropriate greeting, FAQ,
         booking flow, emergency routing
      4. Sends client branded onboarding email with receptionist number + dashboard link
      5. Updates Client.upsells_purchased with ai_receptionist
      6. Fires WorldEvent: milestone_hit

    Autonomy: Fully autonomous. Every Full Stack sale gets a receptionist within 2 hours.
    Soul files: soul_values.md, soul_agent.md
    """

    AGENT_ID = "voice_delivery"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    DELIVERY_SLA_HOURS = 2

    def __init__(self, mem0_client, vapi_provision_client=None):
        self.mem0 = mem0_client
        self.vapi = vapi_provision_client


class ClientSuccessAgent:
    """
    Manages all client relationships post-delivery. Prevents churn. Drives upsells.

    Triggers: 30-day N8N schedule per Client + event-based (no opens 14 days,
              feedback_score drop).

    Workflow:
      1. Reads Client + HermesRelationshipLog + UserGoalState
      2. Churn risk (no opens 14+ days OR feedback_score < 3):
         → personal check-in via Copywriter
         → escalates to Hermes if no response after 3 days
      3. Healthy client: value-add email. Proposes upsell if retention_status = strong.
      4. Upsell → 6-hour hold before sending (v14):
         schedule_send(delay_hours=6, cancel_keyword="NO",
                       notify_channel="telegram", preview_truncated_to=200_chars)
         Hermes sends preview. No response = sends automatically.
      5. Updates Client.last_checkin_at and retention_status

    Autonomy: Fully autonomous for standard check-ins.
              Upsell emails have 6-hour soft checkpoint with Telegram preview + NO cancel.
    Soul files: soul_values.md, soul_agent.md
    """

    AGENT_ID = "client_success"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    UPSELL_DELAY_HOURS = 6
    CHURN_RISK_NO_OPEN_DAYS = 14
    CHURN_RISK_FEEDBACK_THRESHOLD = 3

    def __init__(self, mem0_client):
        self.mem0 = mem0_client


class PaymentRouterAgent:
    """
    Handles all money movement from payment confirmation to MXN bank account.
    Zero manual money handling.

    CRITICAL: No crypto. No USDC. No stablecoins.
    All revenue → Stripe → Wise Business → MXN bank account.

    Tech: N8N + Stripe Webhooks + Wise API.

    Workflow:
      1. stripe payment_intent.succeeded webhook → N8N trigger
      2. Log to PaymentLog with full transaction details
      3. is_new_destination = True → ApprovalRequest regardless of amount (v14)
      4. Routes (known destinations only):
         Layer 1 (< $1,500): Stripe → Wise Business → MXN bank
         Layer 2 (> $1,500): Stripe → Wise Business → MXN bank
         Layer 3 (template/reseller): Stripe → Wise under brand alias → MXN bank
      5. Fires WorldEvent: payment_received
      6. Updates CloudSpendLog running monthly total
      7. Monthly total approaches $4,000: Hermes notifies Nico

    Autonomy: Fully autonomous for routing to known, pre-configured destinations.
              New destination → ApprovalRequest regardless of amount.
    Soul files: soul_values.md, soul_agent.md
    """

    AGENT_ID = "payment_router"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "llama3.2:3b"  # lightweight routing logic
    CURRENCY = "MXN"
    NO_CRYPTO = True  # ENFORCED — no USDC, no stablecoins, no crypto

    def __init__(self, mem0_client, stripe_client=None, wise_client=None):
        self.mem0 = mem0_client
        self.stripe = stripe_client
        self.wise = wise_client
```
"""
