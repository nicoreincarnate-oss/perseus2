"""
PERSEUS V17 — Operations District: Nightly Review & Budget Sentinel

Agents:
  - Nightly Reviewer: 11 PM daily — reviews metrics, updates pipeline, generates tomorrow priorities
  - Budget Sentinel: Enforces $600/mo hard cap, alerts at 80%, kills GPU at budget limit

Also provides:
  - Morning Briefing generator (consumed by Hermes via Telegram)

Budget rules (non-negotiable):
  - $600/month hard cap — BudgetGuard enforces
  - Cloud GPU: $500 cap Month 1 only, $0 from Month 2 until MRR >= $8,000
  - All revenue to MXN bank via Wise Business. NO crypto. NO USDC.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Any

from crewai import Agent, Task, Crew, Process

logger = logging.getLogger(__name__)

OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://host.docker.internal:11434/v1")
PRIMARY_MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")
SECONDARY_MODEL = os.getenv("OLLAMA_SECONDARY", "llama3.2:3b")
MONTHLY_BUDGET = int(os.getenv("MONTHLY_BUDGET_CAP", "600"))
BUDGET_ALERT_THRESHOLD = float(os.getenv("BUDGET_ALERT_THRESHOLD", "0.80"))

# ── Nightly review checklist ───────────────────────────────────────
NIGHTLY_CHECKLIST = [
    "pipeline_status",       # Lead counts at each stage
    "revenue_today",         # Revenue received today
    "mrr_current",           # Current MRR from hosting + recurring
    "sites_in_progress",     # Active builds and their stage
    "email_warmup_status",   # Domain warm-up progress
    "budget_remaining",      # How much of $600/mo is left
    "system_health",         # Docker, Ollama, disk, RAM
    "tomorrow_priorities",   # Top 3 priorities for tomorrow
]


def _create_nightly_reviewer() -> Agent:
    """Create the Nightly Reviewer agent."""
    return Agent(
        role="Nightly Reviewer",
        goal="Review all daily metrics at 11 PM, update pipeline status, and generate tomorrow's top 3 priorities",
        backstory=(
            "You run every night at 11 PM. You pull metrics from Postgres, check the "
            "sales pipeline, review any completed or stalled builds, check budget status, "
            "and compile a concise nightly report. You also generate the morning briefing "
            "that Hermes delivers via Telegram at 7 AM."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
    )


def _create_budget_sentinel() -> Agent:
    """Create the Budget Sentinel agent."""
    return Agent(
        role="Budget Sentinel",
        goal=f"Enforce the ${MONTHLY_BUDGET}/month hard cap. Alert at {int(BUDGET_ALERT_THRESHOLD * 100)}% threshold. Kill GPU instances at budget limit.",
        backstory=(
            f"You are the financial guardian of PERSEUS. The monthly budget is ${MONTHLY_BUDGET} — "
            f"no exceptions, no overages. You monitor all spending: Smartlead ($39/mo), "
            f"hosting costs, domain renewals, cloud GPU usage. You alert at "
            f"{int(BUDGET_ALERT_THRESHOLD * 100)}% of budget and automatically kill any active "
            f"GPU instances if the budget is exhausted. Cloud GPU is Month 1 only ($500 cap), "
            f"$0 from Month 2 until MRR >= $8,000."
        ),
        llm=SECONDARY_MODEL,
        verbose=True,
    )


def run_nightly_reviewer(inputs: dict = None) -> dict:
    """Execute the nightly review cycle.

    Runs at 11 PM daily via cron. Collects metrics, updates pipeline,
    generates tomorrow's priorities and the morning briefing.

    Args:
        inputs: Optional overrides (e.g., {"force": True} for manual trigger)

    Returns:
        Dict with nightly report, priorities, and morning briefing
    """
    inputs = inputs or {}
    logger.info("Nightly Reviewer starting...")
    started_at = datetime.utcnow()

    reviewer = _create_nightly_reviewer()

    review_task = Task(
        description=(
            "Run the nightly review cycle:\n\n"
            f"Checklist: {json.dumps(NIGHTLY_CHECKLIST)}\n\n"
            "1. Query Postgres for today's pipeline changes\n"
            "2. Calculate revenue received today and MTD\n"
            "3. Check current MRR (hosting clients × $52/mo + social × $130/mo)\n"
            "4. List active site builds and their current stage\n"
            "5. Check Smartlead domain warm-up progress\n"
            f"6. Calculate budget remaining (${MONTHLY_BUDGET} - MTD spending)\n"
            "7. Check system health (Docker, Ollama, disk, RAM)\n"
            "8. Generate top 3 priorities for tomorrow\n"
            "9. Compile morning briefing for Hermes Telegram delivery\n\n"
            "Output: Complete nightly report with all sections."
        ),
        expected_output="Nightly report with metrics, priorities, and morning briefing",
        agent=reviewer,
    )

    crew = Crew(
        agents=[reviewer],
        tasks=[review_task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()
    elapsed = (datetime.utcnow() - started_at).total_seconds()

    logger.info(f"Nightly review complete in {elapsed:.0f}s")

    return {
        "status": "completed",
        "crew": "nightly_reviewer",
        "checklist": NIGHTLY_CHECKLIST,
        "elapsed_seconds": elapsed,
        "report": str(result),
        "run_at": datetime.utcnow().isoformat(),
    }


def run_budget_sentinel(inputs: dict = None) -> dict:
    """Check budget status and enforce spending limits.

    Args:
        inputs: {
            "action": "check" | "alert" | "kill_gpu",
            "current_spend": float (optional, pulls from Postgres if not provided)
        }

    Returns:
        Dict with budget status, alerts, and any actions taken
    """
    inputs = inputs or {}
    action = inputs.get("action", "check")
    logger.info(f"Budget Sentinel: {action}")

    sentinel = _create_budget_sentinel()

    task = Task(
        description=(
            f"Budget check requested (action: {action}):\n\n"
            f"Monthly budget: ${MONTHLY_BUDGET}\n"
            f"Alert threshold: {int(BUDGET_ALERT_THRESHOLD * 100)}%\n"
            f"Current spend provided: ${inputs.get('current_spend', 'unknown — query Postgres')}\n\n"
            "1. Calculate total MTD spending from all sources\n"
            "2. Calculate remaining budget\n"
            "3. Determine if alert threshold is breached\n"
            "4. If action=kill_gpu, verify and terminate any active cloud GPU instances\n"
            "5. Report status with recommendation\n\n"
            "Rules:\n"
            f"- Hard cap: ${MONTHLY_BUDGET}/mo — no exceptions\n"
            "- Cloud GPU: $500 cap Month 1 only\n"
            "- $0 cloud GPU from Month 2 until MRR >= $8,000\n"
            "- All revenue goes to MXN bank via Wise Business"
        ),
        expected_output="Budget status report with remaining balance and any alerts/actions",
        agent=sentinel,
    )

    crew = Crew(
        agents=[sentinel],
        tasks=[task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    return {
        "status": "completed",
        "crew": "budget_sentinel",
        "action": action,
        "monthly_budget": MONTHLY_BUDGET,
        "alert_threshold_pct": int(BUDGET_ALERT_THRESHOLD * 100),
        "result": str(result),
        "checked_at": datetime.utcnow().isoformat(),
    }


def generate_morning_briefing() -> dict:
    """Generate the morning briefing for Hermes to deliver via Telegram.

    Called by the /api/morning-briefing endpoint. Hermes reads this and
    sends it to the founder at 7 AM via Telegram.

    Returns:
        Dict with briefing text formatted for Telegram
    """
    logger.info("Generating morning briefing for Hermes delivery")

    reviewer = _create_nightly_reviewer()

    task = Task(
        description=(
            "Generate a concise morning briefing for Telegram delivery:\n\n"
            "Format (Telegram markdown):\n"
            "📊 *PERSEUS Morning Briefing*\n"
            "Date: [today]\n\n"
            "*Pipeline:* X leads → Y prospects → Z proposals → N active builds\n"
            "*MRR:* $X/mo (Y hosting clients)\n"
            "*Budget:* $X remaining of $600\n"
            "*Active Builds:* [list with stages]\n"
            "*Today's Priorities:*\n"
            "1. [priority 1]\n"
            "2. [priority 2]\n"
            "3. [priority 3]\n\n"
            "Keep it under 500 characters. No fluff."
        ),
        expected_output="Telegram-formatted morning briefing under 500 chars",
        agent=reviewer,
    )

    crew = Crew(
        agents=[reviewer],
        tasks=[task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    return {
        "briefing": str(result),
        "generated_at": datetime.utcnow().isoformat(),
        "delivery_channel": "telegram",
    }


# Legacy compatibility
def run(inputs: dict = None) -> dict:
    """Legacy entry point — runs nightly review."""
    return run_nightly_reviewer(inputs)
