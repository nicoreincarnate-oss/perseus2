"""
PERSEUS V17 — Delivery District: Site Builder Agents

Agents (5):
  - Site Planner: Creates sitemap, wireframe, content plan from client brief
  - Code Generator: Generates production HTML/CSS/JS via TITAN engine
  - QA Reviewer: Lighthouse audit, mobile check, accessibility, link validation
  - Deployer: Deploys to Netlify, configures DNS, SSL, CDN
  - Client Reporter: Sends progress updates, delivery confirmation to client

This crew orchestrates the full site build pipeline:
  Brief → Plan → Generate → QA → Deploy → Report

Hermes Agent is NOT part of this pipeline. It is installed externally via:
  curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
"""

import os
import json
import logging
from datetime import datetime
from typing import Any

from crewai import Agent, Task, Crew, Process

logger = logging.getLogger(__name__)

OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://host.docker.internal:11434/v1")
PRIMARY_MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")
SECONDARY_MODEL = os.getenv("OLLAMA_SECONDARY", "llama3.2:3b")
NETLIFY_TOKEN = os.getenv("NETLIFY_AUTH_TOKEN", "")

# ── Build stages ───────────────────────────────────────────────────
BUILD_STAGES = [
    "brief_received",
    "planning",
    "generating",
    "qa_review",
    "revision",
    "deploying",
    "delivered",
]


def _create_site_planner() -> Agent:
    """Site Planner — creates sitemap, wireframe, content plan."""
    return Agent(
        role="Site Planner",
        goal="Create a detailed sitemap, wireframe, and content plan from the client brief",
        backstory=(
            "You are a senior web strategist who turns a client brief into a complete "
            "build plan. You decide page structure, content hierarchy, and UX flow. "
            "You know exactly what a plumber, dentist, or restaurant needs on their site."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
    )


def _create_code_generator() -> Agent:
    """Code Generator — produces production HTML/CSS/JS."""
    return Agent(
        role="Code Generator",
        goal="Generate production-ready, mobile-first HTML/CSS/JS from the site plan using TITAN engine templates",
        backstory=(
            "You are a frontend engineer who generates clean, semantic, fast-loading "
            "websites. Every site scores 90+ on Lighthouse. You use industry templates "
            "as a starting point and customize for the client's brand, services, and location. "
            "You generate complete pages: hero, services, about, testimonials, contact/CTA, footer."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
    )


def _create_qa_reviewer() -> Agent:
    """QA Reviewer — audits everything before deploy."""
    return Agent(
        role="QA Reviewer",
        goal="Ensure every generated site passes Lighthouse >90, is mobile-friendly, accessible, and has no broken links",
        backstory=(
            "You are a ruthless QA engineer. No site ships without your approval. "
            "You check Lighthouse scores, mobile rendering, accessibility (WCAG AA), "
            "broken links, image optimization, and meta tags. If it fails, you send it "
            "back to Code Generator with specific fixes."
        ),
        llm=SECONDARY_MODEL,
        verbose=True,
    )


def _create_deployer() -> Agent:
    """Deployer — pushes to Netlify, configures DNS."""
    return Agent(
        role="Deployer",
        goal="Deploy the approved site to Netlify with SSL, CDN, and proper DNS configuration",
        backstory=(
            "You handle the deployment pipeline. You push to Netlify, configure custom "
            "domains, ensure SSL is active, and verify the live site matches the approved "
            "build. You also set up redirects and 404 pages."
        ),
        llm=SECONDARY_MODEL,
        verbose=True,
    )


def _create_client_reporter() -> Agent:
    """Client Reporter — sends updates and delivery confirmation."""
    return Agent(
        role="Client Reporter",
        goal="Send professional progress updates and delivery confirmation to the client",
        backstory=(
            "You are the client-facing communication specialist. You send status updates "
            "at each build stage, handle the delivery handoff, and provide the client with "
            "their live URL, hosting details ($52/mo), and how to request changes."
        ),
        llm=PRIMARY_MODEL,
        verbose=True,
    )


def run_site_builder(
    client_name: str,
    business_name: str,
    industry: str,
    services: list[str],
    location: str = "",
    phone: str = "",
    color_preference: str = "auto",
    notes: str = "",
) -> dict:
    """Execute the full site build pipeline with all 5 Delivery agents.
    
    Pipeline: Plan → Generate → QA → Deploy → Report
    """
    logger.info(f"Starting site build: {business_name} ({industry})")
    started_at = datetime.utcnow()

    brief = {
        "client_name": client_name,
        "business_name": business_name,
        "industry": industry,
        "services": services,
        "location": location,
        "phone": phone,
        "color_preference": color_preference,
        "notes": notes,
    }

    # Create all 5 agents
    planner = _create_site_planner()
    generator = _create_code_generator()
    qa = _create_qa_reviewer()
    deployer = _create_deployer()
    reporter = _create_client_reporter()

    # ── Task 1: Planning ───────────────────────────────────────────
    plan_task = Task(
        description=(
            f"Create a sitemap and content plan for this client:\n"
            f"{json.dumps(brief, indent=2)}\n\n"
            f"Output: JSON with pages (home, services, about, contact), "
            f"hero section content, service descriptions, CTA text, and meta tags."
        ),
        expected_output="Detailed sitemap and content plan as JSON",
        agent=planner,
    )

    # ── Task 2: Code Generation ────────────────────────────────────
    generate_task = Task(
        description=(
            f"Using the site plan, generate production-ready HTML/CSS/JS for {business_name}.\n"
            f"Industry: {industry}\n"
            f"Requirements: mobile-first, fast-loading, semantic HTML, "
            f"Lighthouse score >90, complete pages with real content.\n"
            f"Use the {industry} template from templates/ as the starting point."
        ),
        expected_output="Complete HTML/CSS/JS files for the website",
        agent=generator,
        context=[plan_task],
    )

    # ── Task 3: QA Review ──────────────────────────────────────────
    qa_task = Task(
        description=(
            f"Review the generated site for {business_name}:\n"
            f"1. Lighthouse audit (target: >90 all categories)\n"
            f"2. Mobile responsiveness check\n"
            f"3. Accessibility (WCAG AA)\n"
            f"4. Broken link detection\n"
            f"5. Image optimization\n"
            f"6. Meta tags and SEO basics\n"
            f"Return: pass/fail with specific issues to fix."
        ),
        expected_output="QA report: pass/fail with specific issues list",
        agent=qa,
        context=[generate_task],
    )

    # ── Task 4: Deployment ─────────────────────────────────────────
    deploy_task = Task(
        description=(
            f"Deploy the approved site for {business_name} to Netlify:\n"
            f"1. Create Netlify site\n"
            f"2. Push build artifacts\n"
            f"3. Configure custom domain (if provided)\n"
            f"4. Verify SSL is active\n"
            f"5. Test live URL\n"
            f"Return: live URL and deployment status."
        ),
        expected_output="Deployment confirmation with live URL",
        agent=deployer,
        context=[qa_task],
    )

    # ── Task 5: Client Report ──────────────────────────────────────
    report_task = Task(
        description=(
            f"Send delivery confirmation to {client_name} at {business_name}:\n"
            f"Include: live site URL, how to review, hosting details ($52/mo via Wise), "
            f"how to request revisions, and next steps.\n"
            f"Tone: professional, warm, celebratory."
        ),
        expected_output="Client delivery email with all details",
        agent=reporter,
        context=[deploy_task],
    )

    # ── Execute pipeline ───────────────────────────────────────────
    crew = Crew(
        agents=[planner, generator, qa, deployer, reporter],
        tasks=[plan_task, generate_task, qa_task, deploy_task, report_task],
        process=Process.sequential,
        verbose=True,
    )

    result = crew.kickoff()

    elapsed = (datetime.utcnow() - started_at).total_seconds()
    logger.info(f"Site build complete: {business_name} in {elapsed:.0f}s")

    return {
        "status": "completed",
        "crew": "site_builder",
        "client": client_name,
        "business": business_name,
        "industry": industry,
        "stages_completed": BUILD_STAGES,
        "elapsed_seconds": elapsed,
        "result": str(result),
    }


def run_site_planner(inputs: dict = None) -> dict:
    """Run only the Site Planner agent."""
    inputs = inputs or {}
    planner = _create_site_planner()
    task = Task(
        description=f"Create a sitemap and content plan for: {json.dumps(inputs)}",
        expected_output="Sitemap and content plan",
        agent=planner,
    )
    crew = Crew(agents=[planner], tasks=[task], process=Process.sequential, verbose=True)
    return {"status": "completed", "crew": "site_planner", "result": str(crew.kickoff())}


def run_code_generator(inputs: dict = None) -> dict:
    """Run only the Code Generator agent."""
    inputs = inputs or {}
    gen = _create_code_generator()
    task = Task(
        description=f"Generate HTML/CSS/JS for: {json.dumps(inputs)}",
        expected_output="Complete website files",
        agent=gen,
    )
    crew = Crew(agents=[gen], tasks=[task], process=Process.sequential, verbose=True)
    return {"status": "completed", "crew": "code_generator", "result": str(crew.kickoff())}


def run_qa_reviewer(inputs: dict = None) -> dict:
    """Run only the QA Reviewer agent."""
    inputs = inputs or {}
    qa = _create_qa_reviewer()
    task = Task(
        description=f"QA review the site: {json.dumps(inputs)}",
        expected_output="QA report",
        agent=qa,
    )
    crew = Crew(agents=[qa], tasks=[task], process=Process.sequential, verbose=True)
    return {"status": "completed", "crew": "qa_reviewer", "result": str(crew.kickoff())}


def run_deployer(inputs: dict = None) -> dict:
    """Run only the Deployer agent."""
    inputs = inputs or {}
    dep = _create_deployer()
    task = Task(
        description=f"Deploy the approved site: {json.dumps(inputs)}",
        expected_output="Deployment confirmation with live URL",
        agent=dep,
    )
    crew = Crew(agents=[dep], tasks=[task], process=Process.sequential, verbose=True)
    return {"status": "completed", "crew": "deployer", "result": str(crew.kickoff())}


def run_client_reporter(inputs: dict = None) -> dict:
    """Run only the Client Reporter agent."""
    inputs = inputs or {}
    rep = _create_client_reporter()
    task = Task(
        description=f"Send client update: {json.dumps(inputs)}",
        expected_output="Client communication message",
        agent=rep,
    )
    crew = Crew(agents=[rep], tasks=[task], process=Process.sequential, verbose=True)
    return {"status": "completed", "crew": "client_reporter", "result": str(crew.kickoff())}


# Legacy compatibility
def run(inputs: dict = None) -> dict:
    """Legacy entry point."""
    inputs = inputs or {}
    return run_site_builder(
        client_name=inputs.get("client_name", "Test Client"),
        business_name=inputs.get("business_name", "Test Business"),
        industry=inputs.get("industry", "plumber"),
        services=inputs.get("services", ["General Services"]),
        location=inputs.get("location", ""),
        phone=inputs.get("phone", ""),
    )
