"""
PERSEUS Self-Awareness District Crew
======================================
PERSEUS's immune system. These 3 agents ensure no bug survives
24 hours in the codebase before being detected and routed for a fix.

Agents:
  - Code Auditor Agent (nightly 1 AM — READ-ONLY codebase scan)
  - Env Validator Agent (nightly 1 AM + post-merge — READ-ONLY env check)
  - Builder Test Enforcer (mandatory gate on every Builder merge)

Target: zero undocumented failure modes, ever.
"""

import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("perseus.crews.self_awareness")


class CodeAuditorAgent:
    """
    Nightly read-only audit of the entire codebase for gaps and issues.

    Schedule: Nightly 1 AM
    Soul files: soul_values.md, soul_agent.md
    LLM: Llama 3.2 3B (lightweight scanning)

    Rules:
      - READ-ONLY. Never touches code.
      - All findings logged as CapabilityGap records.
      - Gap Analyst reviews these weekly and routes to Architect → Builder pipeline.
      - If a CRITICAL gap is found, fires Telegram alert IMMEDIATELY.

    Autonomy: Read-only. Escalates critical findings.
    """

    AGENT_ID = "code_auditor"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "llama3.2:3b"
    SCHEDULE = "0 1 * * *"  # nightly 1 AM
    READ_ONLY = True  # ENFORCED — never touches code

    def __init__(self, mem0_client, telegram_client=None):
        self.mem0 = mem0_client
        self.telegram = telegram_client

    async def run_nightly_audit(self, repo_path: str = "/app"):
        """Scan entire codebase for issues. READ-ONLY."""
        logger.info("Starting nightly code audit (READ-ONLY)")
        findings = []

        # Scan for common issues
        checks = [
            self._check_missing_tests,
            self._check_hardcoded_secrets,
            self._check_missing_error_handling,
            self._check_deprecated_patterns,
            self._check_missing_soul_loading,
        ]

        for check in checks:
            result = await check(repo_path)
            if result:
                findings.extend(result)

        # Log all findings as CapabilityGap records
        for finding in findings:
            await self.mem0.add({
                "category": "CapabilityGap",
                "source": "code_auditor",
                "severity": finding["severity"],
                "description": finding["description"],
                "file": finding.get("file"),
                "found_at": datetime.now(timezone.utc).isoformat(),
            })

            # CRITICAL findings → immediate Telegram alert
            if finding["severity"] == "CRITICAL" and self.telegram:
                await self.telegram.send(
                    f"🚨 CRITICAL code gap: {finding['description']}\n"
                    f"File: {finding.get('file', 'unknown')}"
                )

        logger.info(f"Code audit complete: {len(findings)} findings")
        return findings

    async def _check_missing_tests(self, repo_path) -> list:
        return []

    async def _check_hardcoded_secrets(self, repo_path) -> list:
        return []

    async def _check_missing_error_handling(self, repo_path) -> list:
        return []

    async def _check_deprecated_patterns(self, repo_path) -> list:
        return []

    async def _check_missing_soul_loading(self, repo_path) -> list:
        return []


class EnvValidatorAgent:
    """
    Validates environment configuration integrity.

    Schedule: Nightly 1 AM AND after every Builder Agent merge
    Soul files: soul_values.md, soul_agent.md
    LLM: Llama 3.2 3B (lightweight validation)

    Rules:
      - READ-ONLY. Never touches docker-compose.yaml or .env.
      - Critical env var gaps fire immediate Telegram alert.
      - All findings logged as CapabilityGap records.

    Autonomy: Read-only. Escalates critical findings.
    """

    AGENT_ID = "env_validator"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "llama3.2:3b"
    SCHEDULE = "0 1 * * *"  # nightly 1 AM + post-merge trigger
    READ_ONLY = True  # ENFORCED — never touches env files

    REQUIRED_ENV_VARS = [
        "POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB",
        "MEM0_API_KEY", "OLLAMA_BASE_URL",
        "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
        "SMARTLEAD_API_KEY",
        "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET",
        "WISE_API_KEY",
    ]

    REQUIRED_SERVICES = [
        ("postgres", 5432),
        ("qdrant", 6333),
        ("mem0", 8888),
        ("n8n", 5678),
        ("crewai", 8001),
        ("ollama", 11434),
        ("pinchtab", 9867),
    ]

    def __init__(self, mem0_client, telegram_client=None):
        self.mem0 = mem0_client
        self.telegram = telegram_client

    async def run_validation(self):
        """Validate all environment variables and service connectivity."""
        logger.info("Starting environment validation (READ-ONLY)")
        findings = []

        # Check required env vars
        for var in self.REQUIRED_ENV_VARS:
            if not os.getenv(var):
                findings.append({
                    "severity": "CRITICAL" if "PASSWORD" in var or "KEY" in var else "WARNING",
                    "description": f"Missing environment variable: {var}",
                    "type": "missing_env_var",
                })

        # Log findings
        for finding in findings:
            await self.mem0.add({
                "category": "CapabilityGap",
                "source": "env_validator",
                "severity": finding["severity"],
                "description": finding["description"],
                "found_at": datetime.now(timezone.utc).isoformat(),
            })

            if finding["severity"] == "CRITICAL" and self.telegram:
                await self.telegram.send(
                    f"🚨 CRITICAL env gap: {finding['description']}"
                )

        logger.info(f"Env validation complete: {len(findings)} findings")
        return findings


class BuilderTestEnforcer:
    """
    MANDATORY gate on every Builder Agent merge attempt.

    Schedule: Event-driven (Builder merge attempts)
    Soul files: soul_values.md, soul_agent.md
    LLM: Llama 3.2 3B (lightweight test enforcement)
    Scope lock: write access to /tests/ ONLY

    Rules:
      - Builder Agent MUST POST diff to http://crewai:8001/kickoff/enforce_tests before merge
      - If enforcer returns block_merge: Builder fixes and resubmits. Does NOT bypass.
      - If enforcer is unavailable (container down): Builder escalates to Nico via Telegram.
        NO auto-merge without either enforcer sign-off or explicit Nico override.

    Autonomy: Gate-only. Blocks or allows merges.
    """

    AGENT_ID = "builder_test_enforcer"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "llama3.2:3b"
    SCOPE_LOCK = ["/tests/"]  # Write access to /tests/ ONLY
    ENFORCER_ENDPOINT = "http://crewai:8001/kickoff/enforce_tests"

    def __init__(self, mem0_client=None, telegram_client=None):
        self.mem0 = mem0_client
        self.telegram = telegram_client

    async def evaluate_merge(self, diff: str, task_id: str) -> dict:
        """Evaluate a Builder Agent merge request."""
        logger.info(f"Evaluating merge for task {task_id}")

        # Run tests against the diff
        test_results = await self._run_tests(diff)

        if test_results["all_passed"]:
            return {
                "decision": "allow_merge",
                "task_id": task_id,
                "tests_passed": test_results["passed"],
                "tests_total": test_results["total"],
            }
        else:
            return {
                "decision": "block_merge",
                "task_id": task_id,
                "failures": test_results["failures"],
                "message": "Fix failing tests and resubmit. Do NOT bypass.",
            }

    async def _run_tests(self, diff: str) -> dict:
        """Run test suite against proposed changes."""
        # Placeholder — actual implementation runs pytest
        return {"all_passed": True, "passed": 0, "total": 0, "failures": []}
