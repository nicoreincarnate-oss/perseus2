"""
PERSEUS Learning District Crew
================================
Manages the 2 learning agents that drive nightly self-improvement.

Agents:
  - Reflection Agent (nightly 2 AM — analyzes all data, proposes strategy changes)
  - Prompt Optimizer (nightly 2 AM — evolves prompts based on win/loss data)

These agents are how PERSEUS learns and gets better every single day.
"""

import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("perseus.crews.learning")


class ReflectionAgent:
    """
    Nightly analysis of all outreach and sales data. The brain of the learning loop.

    Schedule: Nightly 2 AM
    Soul files: soul_values.md, soul_agent.md

    Workflow:
      1. Query all EmailEvents + SalesCallLogs + Client changes last 24h
      2. Compute rates by: niche, country, offer type, subject pattern,
         price band, call outcome, website_quality_score
      3. <thinking> chain before writing conclusions
      4. PT-RF-02 (Contradiction Finder) when LearningNotes conflict
      5. PT-RF-05 (Methodology Audit) monthly; PT-RF-06 (Master Synthesis) weekly Sunday
      6. Write LearningNotes, propose StrategyConfig changes
      7. High-impact changes (boostedNiches, suppressedNiches, priceRangeByNiche,
         activeOffers) → shadow_pending=True, applies_at = now + 24h,
         Telegram notification to Nico
      8. Low-impact changes (winningSubjects, losingSubjects) → apply immediately
      9. Correlate DesignInspiration.structural_pattern → client_feedback_avg
      10. Correlate LearningNote.surfaced_during_mode → approval quality
          → CognitiveRhythmModel
      11. Check UserGoalState progress markers → notify Hermes on milestone hits
      12. Flag big changes as ApprovalRequest with goal_alignment tag
      13. PT-RF-09 + PT-RF-10 on every output

    Autonomy: Shadow mode for high-impact changes (24h auto-apply if no NO).
              Immediate apply for low-impact changes.
    """

    AGENT_ID = "reflection_agent"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    SCHEDULE = "0 2 * * *"  # nightly 2 AM
    SHADOW_DELAY_HOURS = 24

    HIGH_IMPACT_FIELDS = [
        "boostedNiches", "suppressedNiches",
        "priceRangeByNiche", "activeOffers",
    ]
    LOW_IMPACT_FIELDS = ["winningSubjects", "losingSubjects"]

    GATES = ["PT-RF-02", "PT-RF-05", "PT-RF-06", "PT-RF-09", "PT-RF-10"]

    def __init__(self, mem0_client, postgres_client=None):
        self.mem0 = mem0_client
        self.postgres = postgres_client

    async def run_nightly_reflection(self):
        """Execute the full nightly reflection cycle."""
        logger.info("Starting nightly reflection cycle")
        timestamp = datetime.now(timezone.utc).isoformat()

        # Step 1: Query last 24h data
        email_events = await self.mem0.search("EmailEvent", filters={"last_24h": True})
        call_logs = await self.mem0.search("SalesCallLog", filters={"last_24h": True})
        client_changes = await self.mem0.search("Client", filters={"modified_last_24h": True})

        # Step 2: Compute rates by segment
        rates = self._compute_segment_rates(email_events, call_logs)

        # Step 3-6: Analysis with <thinking> chain
        conclusions = self._analyze_with_thinking(rates, client_changes)

        # Step 7-8: Route changes by impact level
        for change in conclusions.get("proposed_changes", []):
            field = change.get("field")
            if field in self.HIGH_IMPACT_FIELDS:
                change["shadow_pending"] = True
                change["applies_at"] = self._now_plus_hours(self.SHADOW_DELAY_HOURS)
                logger.info(f"High-impact change queued with 24h shadow: {field}")
            elif field in self.LOW_IMPACT_FIELDS:
                change["shadow_pending"] = False
                logger.info(f"Low-impact change applied immediately: {field}")

        # Step 11: Check milestones
        await self._check_milestones()

        logger.info("Nightly reflection cycle complete")
        return conclusions

    def _compute_segment_rates(self, email_events, call_logs) -> dict:
        """Compute performance rates segmented by niche, country, etc."""
        # Placeholder — actual implementation computes open/reply/close rates
        return {"segments": [], "computed_at": datetime.now(timezone.utc).isoformat()}

    def _analyze_with_thinking(self, rates, client_changes) -> dict:
        """Use <thinking> chain to analyze data before conclusions."""
        return {"proposed_changes": [], "learning_notes": []}

    def _now_plus_hours(self, hours):
        from datetime import timedelta
        return (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()

    async def _check_milestones(self):
        """Check UserGoalState progress markers."""
        pass


class PromptOptimizer:
    """
    Evolves agent prompts based on win/loss data.

    Schedule: Nightly 2 AM (runs after Reflection Agent)
    Soul files: soul_values.md, soul_agent.md

    Workflow:
      Win/loss examples → proposed prompt edit with diff + confidence score
      If confidence > threshold → ApprovalRequest
      Logs in PromptChangeLog with rollback pointer

    Autonomy: Approval required for all prompt changes.
    """

    AGENT_ID = "prompt_optimizer"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    SCHEDULE = "0 2 * * *"  # nightly 2 AM
    CONFIDENCE_THRESHOLD = 0.7

    def __init__(self, mem0_client):
        self.mem0 = mem0_client

    async def run_nightly_optimization(self):
        """Analyze win/loss examples and propose prompt improvements."""
        logger.info("Starting prompt optimization cycle")

        # Get recent win/loss examples
        wins = await self.mem0.search("WinningEmailExample", limit=20)
        losses = await self.mem0.search("LosingEmailExample", limit=20)

        proposals = []
        for proposal in self._generate_proposals(wins, losses):
            if proposal["confidence"] > self.CONFIDENCE_THRESHOLD:
                proposal["requires_approval"] = True
                proposal["rollback_pointer"] = proposal.get("current_prompt_hash")
            proposals.append(proposal)

            # Log to PromptChangeLog
            await self.mem0.add({
                "category": "PromptChangeLog",
                "agent": proposal["target_agent"],
                "proposed_diff": proposal["diff"],
                "confidence": proposal["confidence"],
                "rollback_pointer": proposal.get("rollback_pointer"),
                "created_at": datetime.now(timezone.utc).isoformat(),
            })

        logger.info(f"Prompt optimization complete: {len(proposals)} proposals")
        return proposals

    def _generate_proposals(self, wins, losses) -> list:
        """Generate prompt edit proposals from win/loss data."""
        # Placeholder — actual implementation uses LLM to compare patterns
        return []
