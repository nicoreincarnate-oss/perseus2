"""
PERSEUS Evolution District Crew
=================================
Manages the 5 evolution agents that keep PERSEUS growing and improving.

Agents:
  - Tech Radar Agent (weekly — monitors tech landscape)
  - Gap Analyst (weekly — identifies capability gaps)
  - Architect Agent (event-driven — converts gaps to blueprints)
  - Builder Agent (event-driven — builds and ships new agents)
  - System Auditor (weekly — regression testing)

These agents are how PERSEUS evolves itself.
"""

import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("perseus.crews.evolution")


class TechRadarAgent:
    """
    Monitors technology landscape and curates DesignInspiration pool.

    Schedule: Weekly Sunday 3 AM
    Soul files: soul_values.md, soul_agent.md

    Workflow:
      - Loads all WatchlistItems, Pinchtab checks for triggers
      - PT-RF-01 (Intake Protocol) before evaluating any new tool
      - Browses high-performing niche sites → DesignInspiration pool
      - Fires ProposedAddition → ApprovalRequest when triggers fire

    Autonomy: Approval required for additions.
    """

    AGENT_ID = "tech_radar"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    SCHEDULE = "0 3 * * 0"  # weekly Sunday 3 AM
    GATES = ["PT-RF-01"]

    def __init__(self, mem0_client, pinchtab_client=None):
        self.mem0 = mem0_client
        self.pinchtab = pinchtab_client

    async def run_weekly_scan(self):
        """Execute weekly tech radar scan."""
        logger.info("Starting weekly tech radar scan")
        watchlist = await self.mem0.search("WatchlistItem", limit=100)
        # Scan each item, check triggers, propose additions
        return {"scanned": len(watchlist), "proposals": []}


class GapAnalyst:
    """
    Identifies capability gaps and creates agent blueprints.

    Schedule: Weekly Sunday 4 AM
    Soul files: soul_values.md, soul_agent.md
    Skills: Growth & Product, RICE Prioritization

    Workflow:
      - PT-RF-04 → CapabilityGap records
      - PT-RF-07 monthly
      - PT-RF-03 for new strategy
      - Converts CapabilityGap → AgentBlueprint with:
        soul file assignment, tools, memory schema, N8N trigger,
        CrewAI process, test criteria, rollback plan

    Autonomy: Approval required for blueprints.
    """

    AGENT_ID = "gap_analyst"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    SCHEDULE = "0 4 * * 0"  # weekly Sunday 4 AM
    GATES = ["PT-RF-03", "PT-RF-04", "PT-RF-07"]

    def __init__(self, mem0_client):
        self.mem0 = mem0_client

    async def run_weekly_analysis(self):
        """Analyze capability gaps and propose blueprints."""
        logger.info("Starting weekly gap analysis")
        gaps = await self.mem0.search("CapabilityGap", filters={"status": "open"})
        blueprints = []
        for gap in gaps:
            blueprint = self._gap_to_blueprint(gap)
            if blueprint:
                blueprints.append(blueprint)
        return {"gaps_analyzed": len(gaps), "blueprints_proposed": len(blueprints)}

    def _gap_to_blueprint(self, gap) -> dict | None:
        """Convert a CapabilityGap into an AgentBlueprint."""
        return {
            "agent_name": gap.get("proposed_agent"),
            "role_description": gap.get("description"),
            "soul_variant": "soul_agent",
            "tools_needed": gap.get("tools", []),
            "memory_schema": gap.get("memory_needs", {}),
            "n8n_trigger": gap.get("trigger"),
            "crewai_process": "sequential",
            "test_criteria": gap.get("test_criteria", []),
            "rollback_plan": "Revert to previous agent version via git",
            "status": "pending_approval",
        }


class ArchitectAgent:
    """
    Converts approved CapabilityGaps into full AgentBlueprints.

    Schedule: Event-driven (on approved CapabilityGap)
    Soul files: soul_values.md, soul_agent.md

    Produces complete blueprint with:
      soul file assignment, tools, memory schema, N8N trigger,
      CrewAI process, test criteria, rollback plan.

    Autonomy: Full (only receives already-approved gaps).
    """

    AGENT_ID = "architect_agent"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"

    def __init__(self, mem0_client):
        self.mem0 = mem0_client


class BuilderAgent:
    """
    Builds and ships new agents through isolated development pipeline.

    Schedule: Event-driven (on approved AgentBlueprint)
    Soul files: soul_values.md, soul_agent.md
    Skills: Senior Engineering, Clean Architecture, Loki Mode
    Scope lock: write access ONLY to /agents/, /tools/, /world/, /mobile/

    Workflow:
      1. Generates Artifact doc (task plan, files, functions, test criteria, expected outcomes)
      2. Submits to Superset.sh → isolated Git worktrees
      3. Cursor Agent in each worktree — reads AGENTS.md + SKILL.md files
      4. 3 parallel instances for critical agents — pick best implementation
      5. Diff surfaces in Superset → review + approve before merge (via BUILD mobile app)
      6. On approval: merges to main → deploys to live stack
      7. Outputs SKILL.md to .agent/skills/titan/, writes SystemChangeLog
      8. Also builds /world/ and /mobile/ code, and Enterprise agent set when activated

    Autonomy: Approval required before every merge.
    MANDATORY: Must pass Builder Test Enforcer before any merge.
    """

    AGENT_ID = "builder_agent"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "qwen2.5:14b-instruct-q4_K_M"
    SCOPE_LOCK = ["/agents/", "/tools/", "/world/", "/mobile/"]
    ENFORCER_URL = "http://crewai:8001/kickoff/enforce_tests"

    def __init__(self, mem0_client):
        self.mem0 = mem0_client


class SystemAuditor:
    """
    Weekly regression testing of all agents against test criteria.

    Schedule: Weekly Sunday 5 AM
    Soul files: soul_values.md, soul_agent.md

    Workflow:
      All agents vs test_criteria. Regressions >10% → ApprovalRequest.
      SystemChangeLog append-only.

    Autonomy: Escalate on regression >10%.
    """

    AGENT_ID = "system_auditor"
    SOUL_FILES = ["soul_values", "soul_agent"]
    LLM = "llama3.2:3b"  # lightweight audit checks
    SCHEDULE = "0 5 * * 0"  # weekly Sunday 5 AM
    REGRESSION_THRESHOLD = 0.10  # 10%

    def __init__(self, mem0_client):
        self.mem0 = mem0_client

    async def run_weekly_audit(self):
        """Run regression tests on all agents."""
        logger.info("Starting weekly system audit")
        changelog = await self.mem0.search("SystemChangeLog", limit=50)
        return {"audited": len(changelog), "regressions": []}
