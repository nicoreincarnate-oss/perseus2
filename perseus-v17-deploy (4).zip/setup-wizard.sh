#!/bin/bash
set -euo pipefail

# ─── PERSEUS V17 Setup Wizard ────────────────────────────────────────
# Interactive setup script for first-time installation
# Run: chmod +x setup-wizard.sh && ./setup-wizard.sh

BOLD='\033[1m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

LOGFILE="$HOME/perseus-setup.log"
REPO_DIR="$(cd "$(dirname "$0")" && pwd)"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOGFILE"; }
info() { echo -e "${CYAN}[INFO]${NC} $*"; log "INFO: $*"; }
ok() { echo -e "${GREEN}[  OK]${NC} $*"; log "OK: $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; log "WARN: $*"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; log "FAIL: $*"; }
step() { echo -e "\n${BOLD}═══ $* ═══${NC}\n"; log "STEP: $*"; }

prompt_value() {
    local prompt="$1" default="$2" value
    if [ -n "$default" ]; then
        read -rp "  $prompt [$default]: " value
        echo "${value:-$default}"
    else
        read -rp "  $prompt: " value
        echo "$value"
    fi
}

prompt_secret() {
    local prompt="$1" value
    read -srp "  $prompt: " value
    echo "$value"
    echo ""
}

check_command() {
    if command -v "$1" &>/dev/null; then
        ok "$1 found: $(command -v "$1")"
        return 0
    else
        fail "$1 not found"
        return 1
    fi
}

# ─── Banner ──────────────────────────────────────────────────────────
clear
echo -e "${BOLD}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║          PERSEUS V17 — SETUP WIZARD                    ║"
echo "║          Ship-Ready System Package                     ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "This wizard will configure your Mac Studio for PERSEUS."
echo "Estimated time: 15-30 minutes"
echo "Log file: $LOGFILE"
echo ""
read -rp "Press Enter to begin..."

# ═══ STEP 1: Prerequisites ═══
step "Step 1/8: Checking Prerequisites"

PREREQ_OK=true

info "Checking system..."
OS=$(uname -s)
ARCH=$(uname -m)
if [[ "$OS" == "Darwin" && "$ARCH" == "arm64" ]]; then
    ok "macOS on Apple Silicon detected"
else
    warn "Expected macOS arm64, got $OS/$ARCH — proceeding anyway"
fi

RAM_GB=$(sysctl -n hw.memsize 2>/dev/null | awk '{printf "%.0f", $1/1073741824}' || echo "unknown")
if [[ "$RAM_GB" != "unknown" ]]; then
    info "Total RAM: ${RAM_GB} GB"
    if (( RAM_GB < 32 )); then
        warn "Less than 32 GB RAM detected. PERSEUS requires 32 GB minimum."
    else
        ok "RAM: ${RAM_GB} GB (meets 32 GB requirement)"
    fi
fi

check_command docker || PREREQ_OK=false
check_command "docker compose" 2>/dev/null || check_command docker-compose || PREREQ_OK=false

if docker info &>/dev/null; then
    ok "Docker daemon is running"
    DOCKER_MEM=$(docker info 2>/dev/null | grep "Total Memory" | awk '{print $3, $4}')
    info "Docker memory: $DOCKER_MEM"
else
    fail "Docker daemon is not running — start Docker Desktop first"
    PREREQ_OK=false
fi

check_command curl || PREREQ_OK=false
check_command git || PREREQ_OK=false
check_command jq || { warn "jq not found — installing via Homebrew"; brew install jq 2>/dev/null || true; }

if [[ "$PREREQ_OK" == "false" ]]; then
    fail "Prerequisites not met. Install missing tools and re-run."
    exit 1
fi
ok "All prerequisites met"

# ═══ STEP 2: Ollama Setup ═══
step "Step 2/8: Ollama Setup"

if check_command ollama; then
    OLLAMA_VERSION=$(ollama --version 2>/dev/null || echo "unknown")
    info "Ollama version: $OLLAMA_VERSION"
else
    info "Installing Ollama..."
    curl -fsSL https://ollama.ai/install.sh | sh
    ok "Ollama installed"
fi

if curl -sf http://localhost:11434/api/tags &>/dev/null; then
    ok "Ollama server is running"
else
    info "Starting Ollama server..."
    ollama serve &>/dev/null &
    sleep 3
    if curl -sf http://localhost:11434/api/tags &>/dev/null; then
        ok "Ollama server started"
    else
        fail "Could not start Ollama server"
        exit 1
    fi
fi

info "Pulling required models (this may take 10-20 minutes)..."

for MODEL in "qwen2.5:14b-instruct-q4_K_M" "llama3.2:3b" "nomic-embed-text"; do
    if ollama list 2>/dev/null | grep -q "$MODEL"; then
        ok "Model already pulled: $MODEL"
    else
        info "Pulling $MODEL..."
        ollama pull "$MODEL"
        ok "Pulled: $MODEL"
    fi
done

ollama list > "$REPO_DIR/MODELS_MANIFEST.txt"
ok "Model manifest saved"

# ═══ STEP 3: Hermes Agent Installation ═══
step "Step 3/8: Hermes Agent Installation"

info "Hermes Agent has an interactive setup wizard during install."
info "It will ask ~15-20 questions about providers, tools, and gateways."
echo ""
echo -e "${BOLD}══ HERMES SETUP CHEAT SHEET ══${NC}"
echo ""
echo "  When Hermes asks you to choose an LLM provider:"
echo "    → Select: Custom Endpoint (self-hosted / VLLM / etc.)"
echo "    → API Base URL: http://localhost:11434/v1"
echo "    → API Key: ollama"
echo "    → Model name: qwen2.5:14b-instruct-q4_K_M"
echo ""
echo "  When Hermes asks about tools:"
echo "    → Enable: terminal, file operations, web search, browser"
echo "    → Disable: anything requiring paid API keys you don't have"
echo ""
echo "  When Hermes asks about terminal backend:"
echo "    → Select: local (NOT Docker — we need Docker for PERSEUS stack)"
echo ""
echo "  When Hermes asks about messaging gateway:"
echo "    → Select: Telegram"
echo "    → Bot token: (your @BotFather token)"
echo "    → Chat ID: (your Telegram chat ID)"
echo ""
echo "  For everything else: accept defaults or press Enter to skip."
echo ""
echo -e "${YELLOW}TIP: You can reconfigure any of this later with:${NC}"
echo "  hermes model     — Change LLM provider/model"
echo "  hermes tools     — Enable/disable tools"
echo "  hermes gateway setup  — Reconfigure Telegram"
echo "  hermes setup     — Full setup wizard again"
echo ""
read -rp "Press Enter when ready to start Hermes installation..."

# Pre-create config directory so the installer finds it
mkdir -p "$HOME/.hermes"

# Pre-write the .env so Hermes can find Ollama immediately
cat > "$HOME/.hermes/.env" << 'HERMES_ENV'
# PERSEUS — Hermes points to local Ollama
OPENAI_BASE_URL=http://localhost:11434/v1
OPENAI_API_KEY=ollama
LLM_MODEL=qwen2.5:14b-instruct-q4_K_M
HERMES_ENV
info "Pre-wrote ~/.hermes/.env with Ollama connection"

if command -v hermes &>/dev/null; then
    HERMES_VER=$(hermes --version 2>/dev/null || echo "installed")
    ok "Hermes Agent already installed: $HERMES_VER"
    info "Skipping install — run 'hermes setup' to reconfigure."
else
    info "Installing Hermes Agent from Nous Research..."
    info "IMPORTANT: This is the ONLY valid installation method."
    echo ""
    curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
    ok "Hermes Agent installed"
fi

# Source the shell to pick up hermes in PATH
source "$HOME/.bashrc" 2>/dev/null || source "$HOME/.zshrc" 2>/dev/null || true

# Post-install: write config.yaml with PERSEUS-specific settings
if [ -f "$HOME/.hermes/config.yaml" ]; then
    info "Patching Hermes config for PERSEUS..."
else
    info "Creating Hermes config for PERSEUS..."
fi

# Use hermes config set if available, otherwise write directly
if command -v hermes &>/dev/null; then
    hermes config set terminal.backend local 2>/dev/null || true
    hermes config set model.provider custom 2>/dev/null || true
    hermes config set model.default qwen2.5:14b-instruct-q4_K_M 2>/dev/null || true
    ok "Hermes config updated via CLI"
else
    warn "hermes command not in PATH yet — config will be set on first run"
fi

# Write SOUL.md — this is the PERSEUS personality
info "Writing Hermes SOUL.md persona..."
cp "$REPO_DIR/soul/soul_hermes.md" "$HOME/.hermes/SOUL.md"
ok "SOUL.md installed — Hermes now knows it's PERSEUS"

# Also keep the legacy config.env for backward compat
cat > "$HOME/.hermes/config.env" << 'HERMES_CONFIG'
export OPENAI_BASE_URL=http://localhost:11434/v1
export OPENAI_API_KEY=ollama
export LLM_MODEL=qwen2.5:14b-instruct-q4_K_M
HERMES_CONFIG
ok "Hermes configured for Ollama"

# ═══ STEP 4: Telegram Bot Setup ═══
step "Step 4/8: Telegram Bot Configuration"

echo "To set up the Telegram gateway, you need:"
echo "  1. A Telegram bot token (from @BotFather)"
echo "  2. Your Telegram chat ID"
echo ""

TELEGRAM_TOKEN=$(prompt_secret "Telegram Bot Token (or press Enter to skip)")
if [ -n "$TELEGRAM_TOKEN" ]; then
    TELEGRAM_CHAT_ID=$(prompt_value "Telegram Chat ID" "")
    ok "Telegram credentials collected"
else
    warn "Telegram setup skipped — configure later in .env"
    TELEGRAM_TOKEN="CHANGE_ME"
    TELEGRAM_CHAT_ID="CHANGE_ME"
fi

# ═══ STEP 5: Environment Configuration ═══
step "Step 5/8: Environment Configuration"

cd "$REPO_DIR"

info "Generating .env file..."

PG_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
N8N_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)

SMARTLEAD_KEY=$(prompt_secret "Smartlead API Key (or Enter to skip)")
WISE_TOKEN=$(prompt_secret "Wise Business API Token (or Enter to skip)")
NETLIFY_TOKEN=$(prompt_secret "Netlify Auth Token (or Enter to skip)")

cat > .env << ENV_FILE
# ─── PERSEUS V17 — Generated $(date '+%Y-%m-%d %H:%M:%S') ─────────
# WARNING: Contains secrets. Never commit this file.

# ── Postgres ──
POSTGRES_USER=perseus
POSTGRES_PASSWORD=$PG_PASS
POSTGRES_DB=perseus

# ── N8N ──
N8N_USER=perseus
N8N_PASSWORD=$N8N_PASS
WEBHOOK_URL=http://localhost:5678

# ── Ollama ──
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5:14b-instruct-q4_K_M
OLLAMA_SECONDARY=llama3.2:3b
OLLAMA_EMBED=nomic-embed-text

# ── Hermes Agent ──
OPENAI_BASE_URL=http://localhost:11434/v1
OPENAI_API_KEY=ollama
LLM_MODEL=qwen2.5:14b-instruct-q4_K_M

# ── Telegram ──
TELEGRAM_BOT_TOKEN=$TELEGRAM_TOKEN
TELEGRAM_CHAT_ID=$TELEGRAM_CHAT_ID

# ── Smartlead ──
SMARTLEAD_API_KEY=${SMARTLEAD_KEY:-CHANGE_ME}

# ── Wise Business ──
WISE_API_TOKEN=${WISE_TOKEN:-CHANGE_ME}
WISE_PROFILE_ID=CHANGE_ME

# ── Netlify ──
NETLIFY_AUTH_TOKEN=${NETLIFY_TOKEN:-CHANGE_ME}

# ── Budget ──
MONTHLY_BUDGET_CAP=600
BUDGET_ALERT_THRESHOLD=0.80
ENV_FILE

ok ".env file generated with secure passwords"

# ═══ STEP 6: Docker Stack Launch ═══
step "Step 6/8: Launching Docker Stack"

info "Pulling Docker images..."
docker compose pull 2>&1 | tail -5
ok "Images pulled"

info "Starting containers..."
docker compose up -d 2>&1 | tail -10

info "Waiting for services to be healthy..."
sleep 15

HEALTHY=true
for SERVICE in postgres qdrant mem0 n8n; do
    CONTAINER="perseus-$SERVICE"
    STATUS=$(docker inspect --format='{{.State.Health.Status}}' "$CONTAINER" 2>/dev/null || echo "not found")
    if [[ "$STATUS" == "healthy" ]]; then
        ok "$SERVICE: healthy"
    else
        warn "$SERVICE: $STATUS (may still be starting)"
        HEALTHY=false
    fi
done

if [[ "$HEALTHY" == "false" ]]; then
    info "Some services still starting — waiting 30 more seconds..."
    sleep 30
fi

# ═══ STEP 7: Database Initialization ═══
step "Step 7/8: Database Setup"

info "Checking if database schema is initialized..."
TABLE_COUNT=$(docker exec perseus-postgres psql -U perseus -d perseus -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | tr -d ' ' || echo "0")

if (( TABLE_COUNT > 0 )); then
    ok "Database already initialized ($TABLE_COUNT tables)"
else
    info "Database schema was loaded via init-db.sql on first start"
    ok "Database initialized"
fi

# ═══ STEP 8: Setup Hermes Cron Jobs ═══
step "Step 8/8: Hermes Cron Jobs"

if command -v hermes &>/dev/null; then
    info "Setting up Hermes cron jobs..."

    hermes cron add "morning-briefing" "0 7 * * *" \
        "Generate morning briefing: pipeline status, MRR, system health, today's priorities" 2>/dev/null || \
        warn "Could not add morning-briefing cron (add manually after Hermes gateway setup)"

    hermes cron add "nightly-review" "0 23 * * *" \
        "Run nightly review: pull Smartlead metrics, check domain health, compare against baselines, store in Mem0" 2>/dev/null || \
        warn "Could not add nightly-review cron"

    hermes cron add "uptime-check" "0 */6 * * *" \
        "Check all hosted client sites for uptime. Alert if any return non-200 status." 2>/dev/null || \
        warn "Could not add uptime-check cron"

    hermes cron add "monthly-reports" "0 9 1 * *" \
        "Generate monthly hosting reports for all active clients." 2>/dev/null || \
        warn "Could not add monthly-reports cron"

    hermes cron add "budget-check" "0 8 * * 1" \
        "Calculate current month spending. Alert if >80% of $600 budget consumed." 2>/dev/null || \
        warn "Could not add budget-check cron"

    ok "Hermes cron jobs configured"
else
    warn "Hermes not found — cron jobs will need manual setup"
fi

# ═══ Setup Backup Cron ═══
info "Setting up backup cron..."
CRON_LINE="0 2 * * * $REPO_DIR/backup.sh >> $HOME/perseus-backup.log 2>&1"
(crontab -l 2>/dev/null | grep -v "backup.sh"; echo "$CRON_LINE") | crontab -
ok "Daily backup cron installed (2:00 AM)"

# ═══ Final Summary ═══
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗"
echo "║          SETUP COMPLETE                                 ║"
echo -e "╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${GREEN}Docker Stack:${NC}     6 containers running"
echo -e "  ${GREEN}Ollama:${NC}           3 models loaded"
echo -e "  ${GREEN}Hermes Agent:${NC}     Installed + configured"
echo -e "  ${GREEN}Database:${NC}         Schema initialized"
echo -e "  ${GREEN}Backups:${NC}          Daily at 2:00 AM"
echo ""
echo -e "  ${YELLOW}Next steps:${NC}"
echo "  1. Run ./verify.sh to confirm everything works"
echo "  2. Configure Telegram bot if skipped"
echo "  3. Set up Smartlead account and update .env"
echo "  4. Set up Wise Business account and update .env"
echo "  5. Begin domain warm-up (see Section G of V17 document)"
echo ""
echo -e "  ${CYAN}Quick commands:${NC}"
echo "  ./verify.sh          — Full system verification"
echo "  docker compose ps    — Check container status"
echo "  docker compose logs  — View container logs"
echo "  make status          — Quick status check"
echo ""
echo "Setup log: $LOGFILE"
