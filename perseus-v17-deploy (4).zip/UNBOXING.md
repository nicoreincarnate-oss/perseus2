# PERSEUS V17 — UNBOXING GUIDE

**What you are holding:** Everything needed to go from a sealed Mac Studio box to a revenue-generating AI business in one day.

**Date:** March 30, 2026
**Hardware:** Mac Studio M4 Max, 32GB Unified RAM
**Location:** El Sargento, Baja California Sur, Mexico

---

## What Is In This Package

```
perseus-v17/
├── UNBOXING.md              ← You are here. Start-to-finish guide.
├── PROMPTS.md               ← Every command you need, copy-paste ready
├── docs/
│   ├── PERSEUS_V17.md       ← Complete system documentation (3,446 lines)
│   └── ARCHITECTURE.md      ← Quick architecture reference
├── setup-wizard.sh          ← Interactive setup script (runs everything)
├── verify.sh                ← System verification (run after setup)
├── backup.sh                ← Backup script (auto-scheduled daily)
├── docker-compose.yaml      ← 6-container Docker stack
├── Makefile                 ← Quick commands (make status, make up, etc.)
├── .env.example             ← Template for secrets
├── cloud/                   ← Cloud GPU bootstrap (Month 1 only)
│   ├── cloud_prime.sh       ← GPU rental + fine-tuning orchestrator
│   ├── generate_agents.py   ← Agent scaffolding + LoRA pipeline
│   ├── synthetic_data_gen.py← Training data generator (500K examples)
│   ├── training_config.yaml ← Fine-tuning hyperparameters
│   └── n8n_gpu_workflow.json← Automated nightly GPU reflection workflow
├── agents/                  ← CrewAI agent definitions + source code
├── titan_builder/           ← TITAN autonomous site builder engine
├── tools/                   ← Budget guard, Smartlead, metrics, payments
├── templates/               ← Industry templates (plumber, dentist, restaurant)
├── soul/                    ← PERSEUS soul, values, copy, Hermes persona
├── scripts/                 ← DB init, health checks
├── tests/                   ← Test infrastructure
├── logs/                    ← Log output directory
└── backups/                 ← Backup storage directory
```

---

## PHASE 0: BEFORE MARCH 30 (Do Now)

Complete these from any computer. Each takes 5-15 minutes.

| # | Task | Time | Status |
|---|------|------|--------|
| 1 | **Download this package** to USB drive as backup | 2 min | ☐ |
| 2 | **Create Telegram bot** via @BotFather — save token + your chat ID | 10 min | ☐ |
| 3 | **Sign up for Smartlead** at smartlead.ai — Base plan ($39/mo) — save API key | 10 min | ☐ |
| 4 | **Sign up for Wise Business** at wise.com/business — save API token after approval | 15 min | ☐ |
| 5 | **Purchase 4 sending domains** — .com variants (e.g., perseus-web.com, etc.) | 10 min | ☐ |
| 6 | **Create Netlify account** — free tier, save auth token | 5 min | ☐ |
| 7 | **Create GitHub repo** — private, named `perseus-v17` | 5 min | ☐ |
| 8 | **Create Vast.ai account** — fund with $100 initial deposit | 10 min | ☐ |

**Total pre-arrival time: ~1 hour**

After completing these, you will have these values ready:
- Telegram bot token + chat ID
- Smartlead API key
- Wise Business API token
- Netlify auth token
- Vast.ai API key
- 4 domain names

---

## PHASE 1: ARRIVAL DAY — Mac Studio Setup (2-3 hours)

### Step 1: Unbox + Connect (15 min)

1. Unbox Mac Studio M4 Max
2. Connect to power, display, keyboard, mouse
3. Complete macOS setup (skip iCloud if you want, but enable it for Find My)
4. Connect to Starlink WiFi
5. Open Terminal

### Step 2: Install Prerequisites (10 min)

Copy-paste each block from PROMPTS.md, or type:

```bash
# Install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install essentials
brew install git jq python3

# Install Docker Desktop
brew install --cask docker
```

**After Docker Desktop installs:** Open it → Settings → Resources → set Memory to **6 GB** → Apply & Restart.

### Step 3: Get PERSEUS (5 min)

**Option A — From USB:**
```bash
cp -r /Volumes/USB/perseus-v17 ~/perseus-v17
cd ~/perseus-v17
```

**Option B — From GitHub:**
```bash
git clone https://github.com/YOUR_USERNAME/perseus-v17.git ~/perseus-v17
cd ~/perseus-v17
```

### Step 4: Run Setup Wizard (20-30 min)

```bash
chmod +x setup-wizard.sh verify.sh backup.sh
./setup-wizard.sh
```

The wizard walks you through 8 steps:
1. ✅ Prerequisites check
2. ✅ Ollama install + 3 model pulls (~10-20 min download)
3. ✅ Hermes Agent install (official Nous Research script) — **SEE CHEAT SHEET BELOW**
4. ✅ Telegram bot configuration
5. ✅ Environment file generation (enter your API keys)
6. ✅ Docker stack launch (6 containers)
7. ✅ Database initialization
8. ✅ Hermes cron jobs setup

#### ⚠️ HERMES SETUP CHEAT SHEET

Hermes has its own interactive wizard during install. It asks ~15-20 questions. Here's exactly what to answer:

| When Hermes Asks | Your Answer |
|------------------|-------------|
| **LLM Provider** | Custom Endpoint (self-hosted / VLLM / etc.) |
| **API Base URL** | `http://localhost:11434/v1` |
| **API Key** | `ollama` |
| **Model name** | `qwen2.5:14b-instruct-q4_K_M` |
| **Terminal backend** | `local` (NOT Docker — Docker is for PERSEUS stack) |
| **Messaging gateway** | Telegram |
| **Telegram bot token** | (paste your @BotFather token) |
| **Telegram chat ID** | (paste your chat ID) |
| **Everything else** | Accept defaults / press Enter to skip |

**If you mess up any answer:** Run `hermes setup` to redo it, or fix individual settings:
- `hermes model` — change LLM provider/model
- `hermes tools` — enable/disable tools
- `hermes gateway setup` — reconfigure Telegram
- `hermes config set KEY VALUE` — change any single setting

### Step 5: Verify (5 min)

```bash
./verify.sh
```

All checks should pass. If any fail, the script tells you exactly what to fix.

### Step 6: Smoke Test (10 min)

```bash
# Test Hermes via Telegram — send /status to your bot
# Test site generation
curl -X POST http://localhost:8001/api/generate-site \
  -H "Content-Type: application/json" \
  -d '{
    "client_name": "Test Client",
    "business_name": "Test Plumbing Co",
    "industry": "plumber",
    "services": ["Drain cleaning", "Water heater repair"],
    "location": "Austin, TX",
    "phone": "512-555-0100"
  }'

# Check all services
make status
```

**At this point: PERSEUS is running.** All 6 Docker containers, Ollama with 3 models, Hermes Agent with Telegram gateway. System operational.

---

## PHASE 2: CLOUD GPU BOOTSTRAP (Optional, Month 1 only)

This phase uses rented cloud GPUs to generate custom fine-tuned models and synthetic training data. Budget: $500 max, enforced by BudgetGuard.

**Skip this phase if:** You want to run on stock Qwen2.5:14b only. The system works without custom models — this is an optimization.

### Step 1: Install Vast.ai CLI (5 min)

```bash
pip3 install vastai
vastai set api-key YOUR_VAST_AI_KEY
```

### Step 2: Run Phase 1 — Heavy Bootstrap

```bash
cd ~/perseus-v17/cloud
chmod +x cloud_prime.sh
./cloud_prime.sh phase1
```

This will:
- Search Vast.ai for 4× A100 80GB instances (~$0.86/GPU/hr)
- Rent the cheapest available instance
- Upload the training pipeline
- Generate 500K synthetic training examples
- Fine-tune a custom 7B model with LoRA
- Convert to GGUF for local Ollama use
- Auto-kill instance after 4 hours

**Estimated cost:** $110-150 for the full Phase 1 sprint.

### Step 3: Pull Results Back

```bash
./cloud_prime.sh sync
```

### Step 4: Load Custom Model into Ollama

```bash
# Copy the GGUF to Ollama
cp ~/perseus-cloud-results/perseus-7b.gguf ~/
cd ~
cat > Modelfile << 'EOF'
FROM ./perseus-7b.gguf
PARAMETER temperature 0.7
PARAMETER num_ctx 2048
SYSTEM "You are Perseus, an AI website builder for small businesses."
EOF
ollama create perseus-7b -f Modelfile
ollama run perseus-7b "Generate a homepage hero section for a plumber in Austin, TX"
```

### Step 5: Check Budget

```bash
./cloud_prime.sh status
```

### Step 6: Set Up Nightly Reflection (Optional)

Import the N8N workflow for automated nightly GPU reflection runs:
1. Open N8N at http://localhost:5678
2. Import `cloud/n8n_gpu_workflow.json`
3. Activate the workflow
4. It runs at 11 PM nightly, exports Mem0 delta, rents a cheap A100, processes, tears down

---

## PHASE 3: BUSINESS LAUNCH (Days 2-7)

### Day 2: Email Setup (2 hours)

1. Log into Smartlead at smartlead.ai
2. Add your 4 sending domains
3. Configure SPF, DKIM, DMARC records (Smartlead provides them)
4. Enable warm-up for all 4 domains
5. **Do NOT send campaigns yet** — domains need 2+ weeks warming

### Day 3: Lead Lists (2 hours)

Build lead lists of 500+ businesses per industry:
- Plumbers in your target metro areas
- Dentists in your target metro areas
- Restaurants in your target metro areas

Sources: Google Maps, Yelp, industry directories. Export to CSV.

### Day 4: Campaign Setup (1 hour)

1. Upload lead lists to Smartlead
2. Create 3-email sequences per industry (see `soul/soul_copy.md` for templates)
3. Set warm-up limits: start at 5 emails/domain/day
4. Schedule campaigns to auto-send once warm-up completes (~Week 3)

### Day 5: Payment Infrastructure (1 hour)

1. Complete Wise Business verification (if not done)
2. Create invoice template in Wise
3. Test: send yourself a test invoice
4. Verify MXN conversion works

### Days 6-7: Monitor + Polish (15 min/day)

```bash
# Daily check
make status
./verify.sh

# Check warm-up progress in Smartlead dashboard
# Review Hermes morning briefing in Telegram
```

---

## QUICK REFERENCE

### Daily Commands

```bash
make status          # System health
make up              # Start Docker stack
make down            # Stop Docker stack
make logs            # Tail container logs
./verify.sh          # Full verification
./backup.sh          # Manual backup
```

### Hermes Commands (via Telegram)

```
/status              # System status
/briefing            # Morning briefing
/pipeline            # Sales pipeline status
/budget              # Budget status
/site <industry>     # Quick site generation
```

### Port Truth Table

| Service  | Port  | URL                        |
|----------|-------|----------------------------|
| Postgres | 5432  | localhost:5432              |
| Qdrant   | 6333  | http://localhost:6333       |
| Mem0     | 8888  | http://localhost:8888       |
| CrewAI   | 8001  | http://localhost:8001       |
| N8N      | 5678  | http://localhost:5678       |
| Pinchtab | 9867  | http://localhost:9867       |
| Ollama   | 11434 | http://localhost:11434      |

### Emergency Procedures

**Everything crashed:**
```bash
docker compose down && docker compose up -d
ollama serve &
```

**Out of RAM:**
```bash
docker stats              # Find the hog
docker restart <service>  # Restart it
```

**Hermes is not responding:**
```bash
# Verify Hermes is the REAL Nous Research install
which hermes
hermes --version
# If invalid, reinstall:
curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
```

**Budget alert:**
```bash
cat ~/.perseus/gpu_budget.json | jq .
# Or via Hermes: /budget
```

---

## CONSTRAINTS (Non-Negotiable)

1. **32 GB RAM** — all allocations respect this ceiling
2. **$600/month hard cap** — BudgetGuard enforces, no exceptions
3. **No crypto, no USDC** — all revenue to MXN bank via Wise Business
4. **No enterprise sales** for 9 months — small business only
5. **Solo founder, ~6 hrs/day** — system must be autonomous
6. **Hermes Agent** — installed ONLY via official Nous Research script
7. **Cloud GPU Month 1 only** — $500 cap, $0 from Month 2 until MRR ≥ $8,000
8. **Models:** Qwen2.5:14b-instruct-q4_K_M (~9GB), Llama3.2:3b (~2GB), nomic-embed-text (~0.5GB). NO Qwen3 30B.

---

*PERSEUS V17 — Professional Deployment Package*
*March 30, 2026*
*This is the box. Everything you need is in it.*
