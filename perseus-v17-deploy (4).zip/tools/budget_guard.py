"""Budget Guard — Enforces $600/month hard cap for PERSEUS operations."""

import os
import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Optional

import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)

MONTHLY_CAP = Decimal(os.getenv("MONTHLY_BUDGET_CAP", "600"))
ALERT_THRESHOLD = float(os.getenv("BUDGET_ALERT_THRESHOLD", "0.80"))

DB_URL = os.getenv(
    "POSTGRES_URL",
    "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
)


def get_db():
    """Get database connection."""
    return psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)


def get_month_spending(month: Optional[date] = None) -> dict:
    """Get total spending for a given month.

    Returns:
        dict with keys: total_spent, remaining, percent_used, categories
    """
    if month is None:
        month = date.today().replace(day=1)

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    COALESCE(SUM(amount), 0) as total_spent,
                    %s - COALESCE(SUM(amount), 0) as remaining,
                    CASE WHEN %s > 0
                        THEN ROUND(COALESCE(SUM(amount), 0) / %s * 100, 1)
                        ELSE 0
                    END as percent_used
                FROM budget_tracking
                WHERE month = %s
                """,
                (MONTHLY_CAP, MONTHLY_CAP, MONTHLY_CAP, month)
            )
            summary = dict(cur.fetchone())

            cur.execute(
                """
                SELECT category, SUM(amount) as amount
                FROM budget_tracking
                WHERE month = %s
                GROUP BY category
                ORDER BY amount DESC
                """,
                (month,)
            )
            summary["categories"] = [dict(row) for row in cur.fetchall()]

    return summary


def can_spend(amount: Decimal, category: str) -> dict:
    """Check if a spend is allowed under the budget cap.

    Returns:
        dict with keys: allowed (bool), reason (str), remaining (Decimal)
    """
    spending = get_month_spending()
    remaining = Decimal(str(spending["remaining"]))

    if amount > remaining:
        return {
            "allowed": False,
            "reason": f"Spend of ${amount} exceeds remaining budget of ${remaining}. "
                      f"Monthly cap: ${MONTHLY_CAP}. Already spent: ${spending['total_spent']}.",
            "remaining": remaining,
        }

    new_remaining = remaining - amount
    new_percent = float((Decimal(str(spending["total_spent"])) + amount) / MONTHLY_CAP)

    result = {
        "allowed": True,
        "reason": f"Approved. Remaining after spend: ${new_remaining}.",
        "remaining": new_remaining,
    }

    if new_percent >= ALERT_THRESHOLD:
        result["warning"] = (
            f"Budget alert: spending will reach {new_percent*100:.1f}% "
            f"of ${MONTHLY_CAP} monthly cap."
        )

    return result


def record_spend(amount: Decimal, category: str, description: str,
                 receipt_url: str = None) -> dict:
    """Record a spend after checking budget.

    Returns:
        dict with keys: recorded (bool), spend_id (int), budget_status (dict)
    """
    check = can_spend(amount, category)
    if not check["allowed"]:
        return {"recorded": False, "reason": check["reason"]}

    month = date.today().replace(day=1)

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO budget_tracking (month, category, amount, description, receipt_url)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING id
                """,
                (month, category, amount, description, receipt_url)
            )
            spend_id = cur.fetchone()["id"]
        conn.commit()

    return {
        "recorded": True,
        "spend_id": spend_id,
        "budget_status": get_month_spending(month),
    }


def get_budget_report() -> str:
    """Generate a formatted budget report for Hermes/Telegram."""
    spending = get_month_spending()
    month_name = date.today().strftime("%B %Y")

    lines = [
        f"BUDGET — {month_name}",
        f"├── Spent: ${spending['total_spent']} / ${MONTHLY_CAP}",
        f"├── Remaining: ${spending['remaining']}",
        f"└── Used: {spending['percent_used']}%",
    ]

    if spending["categories"]:
        lines.append("")
        lines.append("BREAKDOWN")
        for cat in spending["categories"]:
            lines.append(f"  ├── {cat['category']}: ${cat['amount']}")

    alert = ""
    if float(spending["percent_used"]) >= ALERT_THRESHOLD * 100:
        alert = "\n⚠️ BUDGET ALERT: Approaching monthly cap!"

    return "\n".join(lines) + alert
