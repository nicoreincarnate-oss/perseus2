"""Payment Router — Wise Business integration for PERSEUS."""

import os
import logging
from datetime import date
from decimal import Decimal
from typing import Optional

import requests

logger = logging.getLogger(__name__)

WISE_API_TOKEN = os.getenv("WISE_API_TOKEN", "")
WISE_PROFILE_ID = os.getenv("WISE_PROFILE_ID", "")
WISE_BASE_URL = "https://api.wise.com"


def _headers():
    return {
        "Authorization": f"Bearer {WISE_API_TOKEN}",
        "Content-Type": "application/json",
    }


def get_balance() -> dict:
    """Get current Wise Business balance."""
    resp = requests.get(
        f"{WISE_BASE_URL}/v4/profiles/{WISE_PROFILE_ID}/balances?types=STANDARD",
        headers=_headers()
    )
    resp.raise_for_status()
    balances = resp.json()

    result = {}
    for bal in balances:
        currency = bal["currency"]
        amount = bal["amount"]["value"]
        result[currency] = float(amount)

    return result


def create_invoice(client_name: str, amount: float, description: str,
                   client_email: str) -> dict:
    """Create a Wise payment request / invoice.

    Returns dict with payment link URL.
    """
    # Wise doesn't have a direct invoice API in all regions
    # For now, generate a payment link manually
    logger.info(f"Creating invoice for {client_name}: ${amount} - {description}")

    return {
        "client_name": client_name,
        "amount": amount,
        "currency": "USD",
        "description": description,
        "payment_method": "wise_business",
        "instructions": (
            f"Send ${amount} USD to PERSEUS Wise Business account. "
            f"Reference: {client_name} - {description}"
        ),
        "status": "pending",
    }


def record_payment(client_id: int, amount: float, product: str,
                   wise_reference: str = None) -> dict:
    """Record a received payment in the database."""
    import psycopg2
    from psycopg2.extras import RealDictCursor

    db_url = os.getenv(
        "POSTGRES_URL",
        "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
    )

    with psycopg2.connect(db_url, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO deals (client_id, product, amount, status, paid_at, wise_reference)
                VALUES (%s, %s, %s, 'paid', NOW(), %s)
                RETURNING id, client_id, product, amount, status, paid_at
                """,
                (client_id, product, amount, wise_reference)
            )
            deal = dict(cur.fetchone())

            # Log activity
            cur.execute(
                """
                INSERT INTO activity_log (entity_type, entity_id, action, details)
                VALUES ('deal', %s, 'payment_received', %s)
                """,
                (deal["id"], f'{{"amount": {amount}, "product": "{product}", "wise_ref": "{wise_reference}"}}')
            )
        conn.commit()

    return deal


def calculate_fees(amount_usd: float) -> dict:
    """Calculate Wise fees for a USD transaction converting to MXN."""
    conversion_fee_rate = 0.007  # 0.70%
    conversion_fee = round(amount_usd * conversion_fee_rate, 2)
    net_usd = round(amount_usd - conversion_fee, 2)

    # Approximate MXN rate (actual rate fetched at conversion time)
    approx_mxn_rate = 17.5
    approx_mxn = round(net_usd * approx_mxn_rate, 2)

    return {
        "gross_usd": amount_usd,
        "conversion_fee": conversion_fee,
        "fee_rate": "0.70%",
        "net_usd": net_usd,
        "approx_mxn_rate": approx_mxn_rate,
        "approx_mxn": approx_mxn,
        "comparison_stripe": round(amount_usd * 0.036 + 0.17, 2),
        "savings_vs_stripe": round((amount_usd * 0.036 + 0.17) - conversion_fee, 2),
    }
