"""Site Monitor — Checks uptime for all hosted client sites."""

import os
import logging
from datetime import datetime
from typing import Optional

import requests
import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)

DB_URL = os.getenv(
    "POSTGRES_URL",
    "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
)

TIMEOUT_SECONDS = 15


def get_db():
    return psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)


def get_active_sites() -> list:
    """Get all active hosting subscriptions with their domains."""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT h.id, h.domain, h.netlify_site_id, c.business_name, c.email
                FROM hosting_subscriptions h
                JOIN clients c ON c.id = h.client_id
                WHERE h.status = 'active' AND h.domain IS NOT NULL
                """
            )
            return [dict(row) for row in cur.fetchall()]


def check_site(domain: str) -> dict:
    """Check a single site's health.

    Returns: http_status, response_time_ms, ssl_valid, ssl_expiry
    """
    url = f"https://{domain}"
    result = {
        "http_status": None,
        "response_time_ms": None,
        "ssl_valid": False,
        "ssl_expiry": None,
        "error": None,
    }

    try:
        resp = requests.get(url, timeout=TIMEOUT_SECONDS, allow_redirects=True)
        result["http_status"] = resp.status_code
        result["response_time_ms"] = int(resp.elapsed.total_seconds() * 1000)
        result["ssl_valid"] = url.startswith("https://")

    except requests.exceptions.SSLError as e:
        result["error"] = f"SSL error: {str(e)[:100]}"
        result["ssl_valid"] = False
        # Try without SSL
        try:
            resp = requests.get(f"http://{domain}", timeout=TIMEOUT_SECONDS)
            result["http_status"] = resp.status_code
            result["response_time_ms"] = int(resp.elapsed.total_seconds() * 1000)
        except Exception:
            pass

    except requests.exceptions.Timeout:
        result["error"] = f"Timeout after {TIMEOUT_SECONDS}s"

    except requests.exceptions.ConnectionError as e:
        result["error"] = f"Connection error: {str(e)[:100]}"

    except Exception as e:
        result["error"] = f"Unexpected error: {str(e)[:100]}"

    return result


def run_uptime_check() -> list:
    """Check all active sites and store results.

    Returns list of dicts with site info + check results.
    """
    sites = get_active_sites()
    results = []

    for site in sites:
        check = check_site(site["domain"])

        # Store in database
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO site_health
                        (hosting_id, http_status, response_time_ms, ssl_valid, notes)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (
                        site["id"],
                        check["http_status"],
                        check["response_time_ms"],
                        check["ssl_valid"],
                        check.get("error"),
                    )
                )
            conn.commit()

        results.append({**site, **check})

    return results


def generate_uptime_report() -> str:
    """Generate formatted uptime report for Telegram."""
    results = run_uptime_check()

    if not results:
        return "UPTIME CHECK\n└── No active hosted sites"

    lines = ["UPTIME CHECK"]
    alerts = []

    for site in results:
        status = site["http_status"]
        time_ms = site["response_time_ms"]
        ssl = "🔒" if site["ssl_valid"] else "⚠️"

        if status == 200:
            icon = "✅"
        elif status is not None:
            icon = "⚠️"
            alerts.append(f"{site['domain']} returned HTTP {status}")
        else:
            icon = "🔴"
            alerts.append(f"{site['domain']} is DOWN: {site.get('error', 'unknown')}")

        time_str = f"{time_ms}ms" if time_ms else "N/A"
        lines.append(f"├── {icon} {site['domain']}: HTTP {status or 'FAIL'} ({time_str}) {ssl}")

    if alerts:
        lines.append("")
        lines.append("⚠️ ALERTS")
        for alert in alerts:
            lines.append(f"  └── {alert}")

    return "\n".join(lines)
