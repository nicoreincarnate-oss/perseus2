"""Soul Loader — Loads PERSEUS personality files for agent prompts."""

import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

SOUL_DIR = Path(os.getenv("SOUL_DIR", "./soul"))


def load_soul(name: str) -> str:
    """Load a soul file by name (without extension).

    Args:
        name: One of 'soul_hermes', 'soul_agent', 'soul_copy', 'soul_values'

    Returns:
        Contents of the soul file as a string.
    """
    file_path = SOUL_DIR / f"{name}.md"

    if not file_path.exists():
        logger.warning(f"Soul file not found: {file_path}")
        return f"[Soul file '{name}' not found at {file_path}]"

    content = file_path.read_text(encoding="utf-8")
    logger.info(f"Loaded soul: {name} ({len(content)} chars)")
    return content


def load_all_souls() -> dict:
    """Load all soul files.

    Returns:
        Dict mapping name → content for all .md files in soul directory.
    """
    souls = {}
    if not SOUL_DIR.exists():
        logger.warning(f"Soul directory not found: {SOUL_DIR}")
        return souls

    for file_path in SOUL_DIR.glob("*.md"):
        name = file_path.stem
        souls[name] = file_path.read_text(encoding="utf-8")
        logger.info(f"Loaded soul: {name} ({len(souls[name])} chars)")

    return souls


def get_hermes_persona() -> str:
    """Get the Hermes Agent persona for SOUL.md."""
    return load_soul("soul_hermes")


def get_copywriting_voice() -> str:
    """Get the copywriting voice guide."""
    return load_soul("soul_copy")
