"""Smartlead API Client — Manages cold email campaigns for PERSEUS."""

import os
import logging
from datetime import date, timedelta
from typing import Optional

import requests

logger = logging.getLogger(__name__)

API_KEY = os.getenv("SMARTLEAD_API_KEY", "")
BASE_URL = "https://server.smartlead.ai/api/v1"

# Domain health thresholds
BOUNCE_THRESHOLD = 0.05      # 5% — auto-pause
SPAM_THRESHOLD = 0.001       # 0.1% — immediate pause
OPEN_RATE_MIN = 0.15         # 15% — flag for review
REPLY_RATE_MIN = 0.01        # 1% — flag for review


def _headers():
    return {"Content-Type": "application/json"}


def _params():
    return {"api_key": API_KEY}


def get_campaigns() -> list:
    """List all campaigns."""
    resp = requests.get(f"{BASE_URL}/campaigns", params=_params())
    resp.raise_for_status()
    return resp.json()


def get_campaign_stats(campaign_id: int) -> dict:
    """Get stats for a specific campaign."""
    resp = requests.get(
        f"{BASE_URL}/campaigns/{campaign_id}/statistics",
        params=_params()
    )
    resp.raise_for_status()
    return resp.json()


def get_campaign_replies(campaign_id: int) -> list:
    """Get replies for a campaign."""
    resp = requests.get(
        f"{BASE_URL}/campaigns/{campaign_id}/replies",
        params=_params()
    )
    resp.raise_for_status()
    return resp.json()


def pause_campaign(campaign_id: int) -> dict:
    """Pause a campaign."""
    resp = requests.post(
        f"{BASE_URL}/campaigns/{campaign_id}/pause",
        params=_params()
    )
    resp.raise_for_status()
    return resp.json()


def get_email_accounts() -> list:
    """List all email sending accounts."""
    resp = requests.get(f"{BASE_URL}/email-accounts", params=_params())
    resp.raise_for_status()
    return resp.json()


def check_domain_health(domain: str, days: int = 7) -> dict:
    """Check health metrics for a sending domain over recent days.

    Returns dict with: bounce_rate, open_rate, reply_rate, spam_rate,
                       health_status ('OK', 'WARNING', 'CRITICAL'),
                       recommendations (list of strings)
    """
    # Aggregate from stored metrics
    import psycopg2
    from psycopg2.extras import RealDictCursor

    db_url = os.getenv(
        "POSTGRES_URL",
        "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
    )

    with psycopg2.connect(db_url, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    SUM(emails_sent) as total_sent,
                    SUM(opens) as total_opens,
                    SUM(replies) as total_replies,
                    SUM(bounces) as total_bounces,
                    SUM(spam_complaints) as total_spam
                FROM outreach_metrics
                WHERE domain = %s AND date >= %s
                """,
                (domain, date.today() - timedelta(days=days))
            )
            row = cur.fetchone()

    if not row or not row["total_sent"] or row["total_sent"] == 0:
        return {
            "bounce_rate": 0,
            "open_rate": 0,
            "reply_rate": 0,
            "spam_rate": 0,
            "health_status": "NO_DATA",
            "recommendations": ["No data for this domain in the last {days} days"],
        }

    sent = row["total_sent"]
    bounce_rate = (row["total_bounces"] or 0) / sent
    open_rate = (row["total_opens"] or 0) / sent
    reply_rate = (row["total_replies"] or 0) / max(row["total_opens"] or 1, 1)
    spam_rate = (row["total_spam"] or 0) / sent

    recommendations = []
    status = "OK"

    if spam_rate >= SPAM_THRESHOLD:
        status = "CRITICAL"
        recommendations.append(f"SPAM rate {spam_rate*100:.2f}% exceeds {SPAM_THRESHOLD*100}% — PAUSE IMMEDIATELY")

    if bounce_rate >= BOUNCE_THRESHOLD:
        status = "CRITICAL"
        recommendations.append(f"Bounce rate {bounce_rate*100:.1f}% exceeds {BOUNCE_THRESHOLD*100}% — pause and check list quality")

    if open_rate < OPEN_RATE_MIN and status != "CRITICAL":
        status = "WARNING"
        recommendations.append(f"Open rate {open_rate*100:.1f}% below {OPEN_RATE_MIN*100}% — review subject lines")

    if reply_rate < REPLY_RATE_MIN and status != "CRITICAL":
        if status != "WARNING":
            status = "WARNING"
        recommendations.append(f"Reply rate {reply_rate*100:.1f}% below {REPLY_RATE_MIN*100}% — review email copy")

    return {
        "bounce_rate": round(bounce_rate, 4),
        "open_rate": round(open_rate, 4),
        "reply_rate": round(reply_rate, 4),
        "spam_rate": round(spam_rate, 4),
        "health_status": status,
        "recommendations": recommendations or ["All metrics within healthy ranges"],
    }


def generate_domain_report(domains: list) -> str:
    """Generate formatted domain health report for all sending domains."""
    lines = ["DOMAIN HEALTH"]

    for domain in domains:
        health = check_domain_health(domain)
        status_icon = {"OK": "✅", "WARNING": "⚠️", "CRITICAL": "🔴", "NO_DATA": "❓"}.get(
            health["health_status"], "❓"
        )
        lines.append(
            f"├── {domain}: {status_icon} "
            f"bounce={health['bounce_rate']*100:.1f}% "
            f"open={health['open_rate']*100:.1f}% "
            f"reply={health['reply_rate']*100:.1f}%"
        )
        for rec in health["recommendations"]:
            if rec != "All metrics within healthy ranges":
                lines.append(f"│   └── {rec}")

    return "\n".join(lines)
