"""Metrics Collector — Aggregates data from all PERSEUS sources for reports."""

import os
import logging
from datetime import date, timedelta
from typing import Optional

import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)

DB_URL = os.getenv(
    "POSTGRES_URL",
    "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
)


def get_db():
    return psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)


def get_pipeline_status() -> dict:
    """Get current pipeline metrics."""
    with get_db() as conn:
        with conn.cursor() as cur:
            # Active leads
            cur.execute("SELECT COUNT(*) as count FROM clients WHERE status = 'lead'")
            leads = cur.fetchone()["count"]

            # Active deals
            cur.execute("SELECT COUNT(*) as count FROM deals WHERE status = 'pending'")
            pending_deals = cur.fetchone()["count"]

            # Closed this month
            cur.execute(
                """
                SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as revenue
                FROM deals
                WHERE status = 'paid'
                AND paid_at >= date_trunc('month', CURRENT_DATE)
                """
            )
            month_deals = cur.fetchone()

            # MRR
            cur.execute("SELECT * FROM v_active_mrr")
            mrr = cur.fetchone()

            # Active hosting clients
            cur.execute("SELECT COUNT(*) as count FROM hosting_subscriptions WHERE status = 'active'")
            hosting = cur.fetchone()["count"]

            # Active receptionist clients
            cur.execute("SELECT COUNT(*) as count FROM receptionist_subscriptions WHERE status = 'active'")
            receptionist = cur.fetchone()["count"]

    return {
        "active_leads": leads,
        "pending_deals": pending_deals,
        "deals_this_month": month_deals["count"],
        "revenue_this_month": float(month_deals["revenue"]),
        "hosting_mrr": float(mrr["hosting_mrr"]),
        "receptionist_mrr": float(mrr["receptionist_mrr"]),
        "total_mrr": float(mrr["total_mrr"]),
        "active_hosting": hosting,
        "active_receptionist": receptionist,
    }


def get_outreach_summary(days: int = 7) -> dict:
    """Get outreach metrics for the last N days."""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    SUM(emails_sent) as total_sent,
                    SUM(opens) as total_opens,
                    SUM(replies) as total_replies,
                    SUM(bounces) as total_bounces,
                    SUM(interested_replies) as total_interested
                FROM outreach_metrics
                WHERE date >= %s
                """,
                (date.today() - timedelta(days=days),)
            )
            row = cur.fetchone()

    sent = row["total_sent"] or 0
    opens = row["total_opens"] or 0
    replies = row["total_replies"] or 0

    return {
        "period_days": days,
        "total_sent": sent,
        "total_opens": opens,
        "total_replies": replies,
        "total_bounces": row["total_bounces"] or 0,
        "total_interested": row["total_interested"] or 0,
        "open_rate": round(opens / max(sent, 1) * 100, 1),
        "reply_rate": round(replies / max(opens, 1) * 100, 1),
    }


def get_system_health() -> dict:
    """Check Docker containers and Ollama status."""
    import subprocess
    import requests

    health = {"docker": {}, "ollama": {}, "disk": {}}

    # Docker containers
    expected = ["perseus-postgres", "perseus-qdrant", "perseus-mem0",
                "perseus-crewai", "perseus-n8n", "perseus-pinchtab"]
    try:
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}:{{.Status}}"],
            capture_output=True, text=True, timeout=10
        )
        running = {}
        for line in result.stdout.strip().split("\n"):
            if ":" in line:
                name, status = line.split(":", 1)
                running[name] = status

        for container in expected:
            health["docker"][container] = running.get(container, "NOT RUNNING")
    except Exception as e:
        health["docker"]["error"] = str(e)

    # Ollama
    try:
        resp = requests.get("http://localhost:11434/api/tags", timeout=5)
        if resp.ok:
            models = [m["name"] for m in resp.json().get("models", [])]
            health["ollama"]["status"] = "running"
            health["ollama"]["models"] = models
        else:
            health["ollama"]["status"] = "error"
    except Exception:
        health["ollama"]["status"] = "not responding"

    # Disk
    try:
        result = subprocess.run(
            ["df", "-h", "/"],
            capture_output=True, text=True, timeout=5
        )
        lines = result.stdout.strip().split("\n")
        if len(lines) >= 2:
            parts = lines[1].split()
            health["disk"]["total"] = parts[1] if len(parts) > 1 else "?"
            health["disk"]["used"] = parts[2] if len(parts) > 2 else "?"
            health["disk"]["percent"] = parts[4] if len(parts) > 4 else "?"
    except Exception:
        health["disk"]["error"] = "Could not read disk usage"

    return health


def generate_morning_briefing() -> str:
    """Generate the morning briefing message for Hermes → Telegram."""
    pipeline = get_pipeline_status()
    outreach = get_outreach_summary(days=7)
    system = get_system_health()

    from tools.budget_guard import get_budget_report
    budget = get_budget_report()

    # Docker status line
    docker_running = sum(1 for v in system["docker"].values()
                        if isinstance(v, str) and "Up" in v)
    docker_total = len([k for k in system["docker"] if k != "error"])

    # Ollama status
    ollama_status = system["ollama"].get("status", "unknown")
    ollama_models = ", ".join(system["ollama"].get("models", []))

    briefing = f"""☀️ MORNING BRIEFING — {date.today().strftime('%A, %B %d, %Y')}

PIPELINE
├── Active leads: {pipeline['active_leads']}
├── Pending deals: {pipeline['pending_deals']}
├── Deals this month: {pipeline['deals_this_month']}
├── Revenue this month: ${pipeline['revenue_this_month']:.2f}
└── MRR: ${pipeline['total_mrr']:.2f} (hosting: ${pipeline['hosting_mrr']:.2f}, receptionist: ${pipeline['receptionist_mrr']:.2f})

OUTREACH (7-day)
├── Emails sent: {outreach['total_sent']}
├── Open rate: {outreach['open_rate']}%
├── Reply rate: {outreach['reply_rate']}%
└── Interested replies: {outreach['total_interested']}

SYSTEM
├── Docker: {docker_running}/{docker_total} containers running
├── Ollama: {ollama_status} [{ollama_models}]
├── Disk: {system['disk'].get('percent', '?')} used
└── Mem0: {'responsive' if 'perseus-mem0' in system['docker'] else 'check status'}

{budget}"""

    return briefing


def generate_nightly_review() -> str:
    """Generate the nightly review message for Hermes → Telegram."""
    from tools.smartlead_client import generate_domain_report

    pipeline = get_pipeline_status()
    outreach = get_outreach_summary(days=1)

    # Get sending domains from env or default
    domains = os.getenv("SENDING_DOMAINS", "").split(",")
    domains = [d.strip() for d in domains if d.strip()]

    domain_report = generate_domain_report(domains) if domains else "DOMAIN HEALTH\n└── No sending domains configured"

    review = f"""📊 NIGHTLY REVIEW — {date.today().strftime('%Y-%m-%d')}

OUTREACH (today)
├── Emails sent today: {outreach['total_sent']}
├── Open rate (7-day): {get_outreach_summary(7)['open_rate']}%
├── Reply rate (7-day): {get_outreach_summary(7)['reply_rate']}%
└── Interested replies today: {outreach['total_interested']}

{domain_report}

PIPELINE
├── Active leads: {pipeline['active_leads']}
├── Deals this week: {pipeline['deals_this_month']}
├── Revenue this month: ${pipeline['revenue_this_month']:.2f}
└── MRR: ${pipeline['total_mrr']:.2f}"""

    return review
