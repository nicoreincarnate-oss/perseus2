# PERSEUS V17 — Professional Deployment Package

AI-powered business operating system with 30 autonomous agents for building and managing websites for small businesses. Runs on a Mac Studio M4 Max (32GB), zero cloud cost after Month 1.

## Start Here

**Read [UNBOXING.md](UNBOXING.md) first.** It walks you through everything from sealed box to running system.

**Keep [PROMPTS.md](PROMPTS.md) open.** Every command you need, copy-paste ready.

## Quick Start

```bash
chmod +x setup-wizard.sh verify.sh backup.sh cloud/cloud_prime.sh
./setup-wizard.sh
./verify.sh
```

## Package Contents

| File/Dir | What It Is |
|----------|-----------|
| `UNBOXING.md` | Start-to-finish Day 0 guide |
| `PROMPTS.md` | Every command/prompt, copy-paste ready |
| `setup-wizard.sh` | Interactive 8-step setup wizard |
| `verify.sh` | Full system verification |
| `backup.sh` | Daily backup script |
| `docker-compose.yaml` | 6-container Docker stack |
| `Makefile` | Quick commands (`make status`, `make up`, etc.) |
| `cloud/` | Cloud GPU bootstrap scripts (Month 1, $500 cap) |
| `agents/` | CrewAI agent definitions + orchestration |
| `titan_builder/` | TITAN autonomous site builder engine |
| `tools/` | Budget guard, Smartlead, metrics, payments |
| `templates/` | Industry templates (plumber, dentist, restaurant) |
| `soul/` | PERSEUS soul, values, copy, Hermes persona |
| `scripts/` | Database init, health checks |
| `docs/` | Full V17 documentation (3,446 lines) |

## Architecture

- **Hardware:** Mac Studio M4 Max (32 GB unified RAM)
- **LLM:** Qwen2.5:14b-instruct-q4_K_M via Ollama (local, zero cloud cost)
- **Containers:** 6 Docker services (Postgres, Qdrant, Mem0, CrewAI, N8N, Pinchtab)
- **Native:** Ollama + Hermes Agent (Nous Research)
- **Agents:** 30 autonomous CrewAI agents across 7 districts (Sales, Delivery, Ops, Learning, Evolution, Self-Awareness, Enterprise)
- **Revenue:** Simple 5-page site ($332) | Landing page ($265) | E-commerce ($1,330) | Logo+brand ($130) | AI chatbot ($398) | Hosting ($52/mo) | Social media ($130/mo)
- **Budget:** $600/month hard cap, BudgetGuard enforced

## Port Truth Table

| Service | Port |
|---------|------|
| Postgres | 5432 |
| Qdrant | 6333 |
| Mem0 | 8888 |
| CrewAI | 8001 |
| N8N | 5678 |
| Pinchtab | 9867 |
| Ollama | 11434 |

## License

MIT
