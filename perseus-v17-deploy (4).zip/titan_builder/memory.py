"""
TITAN Builder — Memory (Mem0 Integration)
============================================
Logs build learnings to Mem0 so TITAN gets smarter over time.
Every success, failure, and pattern is remembered.

Memory categories:
  - build_success: What worked and how
  - build_failure: What broke and why
  - code_pattern: Reusable code patterns discovered
  - performance: Timing data for optimization
  - strategy: High-level build strategy learnings
"""

import json
import logging
import os
import time
from datetime import datetime, timezone

import httpx

logger = logging.getLogger("titan.memory")

MEM0_URL = os.getenv("MEM0_URL", "http://localhost:8888")
MEM0_API_KEY = os.getenv("MEM0_API_KEY", "")
MEMORY_USER_ID = "titan_builder"
TIMEOUT = 10  # seconds


def _mem0_headers() -> dict:
    """Build headers for Mem0 API requests."""
    headers = {"Content-Type": "application/json"}
    if MEM0_API_KEY:
        headers["Authorization"] = f"Bearer {MEM0_API_KEY}"
    return headers


def _mem0_request(method: str, endpoint: str, data: dict | None = None) -> dict | None:
    """Make a request to Mem0 API with error handling.

    Returns response JSON or None on failure.
    """
    url = f"{MEM0_URL}{endpoint}"
    try:
        if method == "POST":
            response = httpx.post(
                url, json=data, headers=_mem0_headers(), timeout=TIMEOUT
            )
        elif method == "GET":
            response = httpx.get(
                url, params=data, headers=_mem0_headers(), timeout=TIMEOUT
            )
        else:
            logger.error(f"Unsupported HTTP method: {method}")
            return None

        if response.status_code in (200, 201):
            return response.json()
        else:
            logger.warning(
                f"Mem0 {method} {endpoint} returned {response.status_code}: "
                f"{response.text[:200]}"
            )
            return None
    except httpx.ConnectError:
        logger.warning("Mem0 is not reachable — memory operation skipped")
        return None
    except httpx.TimeoutException:
        logger.warning(f"Mem0 timeout on {method} {endpoint}")
        return None
    except Exception as e:
        logger.error(f"Mem0 error: {e}")
        return None


class BuildMemory:
    """Logs build events and learnings to Mem0."""

    def __init__(self):
        self.events_logged = 0
        self.events_failed = 0

    def log_build_success(self, task: dict, files_written: list[str],
                          duration_sec: float) -> None:
        """Log a successful build to memory."""
        memory_text = (
            f"TITAN successfully built task '{task['title']}' (ID: {task['id']}). "
            f"Phase {task['phase']}, priority {task['priority']}. "
            f"Files created: {', '.join(files_written)}. "
            f"Build took {duration_sec:.1f} seconds. "
            f"Description: {task['description'][:200]}"
        )
        self._store(memory_text, category="build_success", metadata={
            "task_id": task["id"],
            "phase": task["phase"],
            "files": files_written,
            "duration_sec": round(duration_sec, 1),
        })

    def log_build_failure(self, task: dict, error: str,
                          attempt: int) -> None:
        """Log a failed build to memory for future avoidance."""
        memory_text = (
            f"TITAN failed to build task '{task['title']}' (ID: {task['id']}). "
            f"Attempt {attempt}/3. Error: {error[:300]}. "
            f"Description: {task['description'][:200]}"
        )
        self._store(memory_text, category="build_failure", metadata={
            "task_id": task["id"],
            "attempt": attempt,
            "error": error[:500],
        })

    def log_code_pattern(self, pattern_name: str, description: str,
                         example: str) -> None:
        """Log a discovered code pattern for reuse."""
        memory_text = (
            f"Code pattern discovered: '{pattern_name}'. "
            f"{description}. "
            f"Example: {example[:300]}"
        )
        self._store(memory_text, category="code_pattern", metadata={
            "pattern_name": pattern_name,
        })

    def log_performance(self, task_id: str, metric_name: str,
                        value: float, unit: str) -> None:
        """Log a performance metric."""
        memory_text = (
            f"Performance metric for task {task_id}: "
            f"{metric_name} = {value} {unit}."
        )
        self._store(memory_text, category="performance", metadata={
            "task_id": task_id,
            "metric": metric_name,
            "value": value,
            "unit": unit,
        })

    def log_strategy(self, insight: str) -> None:
        """Log a strategic insight about the build process."""
        memory_text = f"Build strategy insight: {insight}"
        self._store(memory_text, category="strategy")

    def recall_failures(self, task_description: str) -> list[dict]:
        """Search memory for past failures related to a task.

        Returns list of relevant failure memories to avoid repeating mistakes.
        """
        result = _mem0_request("POST", "/v1/memories/search/", data={
            "query": f"build failure: {task_description[:200]}",
            "user_id": MEMORY_USER_ID,
            "limit": 5,
        })

        if result and isinstance(result, list):
            logger.info(f"Recalled {len(result)} failure memories for context")
            return result
        elif result and isinstance(result, dict):
            memories = result.get("results", result.get("memories", []))
            logger.info(f"Recalled {len(memories)} failure memories for context")
            return memories
        return []

    def recall_patterns(self, context: str) -> list[dict]:
        """Search memory for relevant code patterns.

        Returns list of pattern memories to guide code generation.
        """
        result = _mem0_request("POST", "/v1/memories/search/", data={
            "query": f"code pattern: {context[:200]}",
            "user_id": MEMORY_USER_ID,
            "limit": 5,
        })

        if result and isinstance(result, list):
            return result
        elif result and isinstance(result, dict):
            return result.get("results", result.get("memories", []))
        return []

    def get_build_history(self, limit: int = 20) -> list[dict]:
        """Get recent build history from memory.

        Returns list of recent build events.
        """
        result = _mem0_request("GET", "/v1/memories/", data={
            "user_id": MEMORY_USER_ID,
            "limit": limit,
        })

        if result and isinstance(result, list):
            return result
        elif result and isinstance(result, dict):
            return result.get("results", result.get("memories", []))
        return []

    def generate_nightly_summary(self) -> dict:
        """Compile a summary of today's build activity from memory.

        Returns a dict with counts and highlights.
        """
        history = self.get_build_history(limit=50)

        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        today_events = [
            m for m in history
            if m.get("created_at", "").startswith(today)
            or m.get("metadata", {}).get("created_at", "").startswith(today)
        ]

        successes = [
            m for m in today_events
            if "success" in str(m.get("metadata", {}).get("category", ""))
            or "successfully built" in str(m.get("memory", "")).lower()
        ]
        failures = [
            m for m in today_events
            if "failure" in str(m.get("metadata", {}).get("category", ""))
            or "failed to build" in str(m.get("memory", "")).lower()
        ]

        return {
            "date": today,
            "total_events": len(today_events),
            "successes": len(successes),
            "failures": len(failures),
            "events_logged_this_session": self.events_logged,
            "events_failed_this_session": self.events_failed,
        }

    def _store(self, text: str, category: str,
               metadata: dict | None = None) -> None:
        """Store a memory in Mem0."""
        payload = {
            "messages": [{"role": "user", "content": text}],
            "user_id": MEMORY_USER_ID,
            "metadata": {
                "category": category,
                "created_at": datetime.now(timezone.utc).isoformat(),
                **(metadata or {}),
            },
        }

        result = _mem0_request("POST", "/v1/memories/", data=payload)
        if result:
            self.events_logged += 1
            logger.debug(f"Stored memory [{category}]: {text[:80]}...")
        else:
            self.events_failed += 1
            logger.warning(f"Failed to store memory [{category}]: {text[:80]}...")

    def get_stats(self) -> dict:
        """Return memory system statistics."""
        return {
            "events_logged": self.events_logged,
            "events_failed": self.events_failed,
            "mem0_url": MEM0_URL,
            "mem0_reachable": self._check_reachable(),
        }

    def _check_reachable(self) -> bool:
        """Check if Mem0 is reachable."""
        try:
            response = httpx.get(
                f"{MEM0_URL}/health", headers=_mem0_headers(), timeout=3
            )
            return response.status_code == 200
        except Exception:
            return False
