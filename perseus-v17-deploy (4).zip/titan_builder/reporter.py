"""
TITAN Builder — Reporter
==========================
Sends build progress updates to Nico via Telegram.
Handles approval requests for risky operations.
All messages go through the same Telegram bot that Hermes uses.
"""

import json
import logging
import os
import time
from datetime import datetime, timezone

import httpx

logger = logging.getLogger("titan.reporter")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
TELEGRAM_API = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"
POLL_INTERVAL = 10  # seconds between checking for approval responses
APPROVAL_TIMEOUT = 3600  # 1 hour max wait for approval


def _send_telegram(text: str, parse_mode: str = "HTML") -> bool:
    """Send a message to Nico via Telegram."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram not configured — message not sent")
        logger.info(f"[UNSENT] {text}")
        return False

    try:
        response = httpx.post(
            f"{TELEGRAM_API}/sendMessage",
            json={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": text,
                "parse_mode": parse_mode,
            },
            timeout=10,
        )
        if response.status_code == 200:
            return True
        else:
            logger.error(f"Telegram send failed: {response.status_code} {response.text}")
            return False
    except Exception as e:
        logger.error(f"Telegram error: {e}")
        return False


def _send_telegram_with_buttons(
    text: str, buttons: list[list[dict]]
) -> int | None:
    """Send a message with inline keyboard buttons. Returns message_id."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram not configured")
        return None

    try:
        response = httpx.post(
            f"{TELEGRAM_API}/sendMessage",
            json={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": text,
                "parse_mode": "HTML",
                "reply_markup": {"inline_keyboard": buttons},
            },
            timeout=10,
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("result", {}).get("message_id")
        return None
    except Exception as e:
        logger.error(f"Telegram button send error: {e}")
        return None


def _get_callback_response(timeout: int = APPROVAL_TIMEOUT) -> str | None:
    """Poll for a callback query response (button press).

    Returns the callback data string, or None if timeout.
    """
    if not TELEGRAM_BOT_TOKEN:
        return None

    # Use getUpdates with long polling
    last_update_id = 0
    start = time.time()

    while time.time() - start < timeout:
        try:
            response = httpx.get(
                f"{TELEGRAM_API}/getUpdates",
                params={
                    "offset": last_update_id + 1,
                    "timeout": POLL_INTERVAL,
                    "allowed_updates": '["callback_query"]',
                },
                timeout=POLL_INTERVAL + 5,
            )
            if response.status_code != 200:
                time.sleep(POLL_INTERVAL)
                continue

            data = response.json()
            updates = data.get("result", [])

            for update in updates:
                last_update_id = update["update_id"]
                callback = update.get("callback_query")
                if callback:
                    # Acknowledge the callback
                    httpx.post(
                        f"{TELEGRAM_API}/answerCallbackQuery",
                        json={"callback_query_id": callback["id"]},
                        timeout=5,
                    )
                    return callback.get("data")

        except Exception as e:
            logger.warning(f"Polling error: {e}")
            time.sleep(POLL_INTERVAL)

    return None


class Reporter:
    """Sends build progress to Telegram."""

    def __init__(self):
        self.messages_sent = 0

    def task_started(self, task: dict):
        """Notify that a build task has started."""
        msg = (
            f"🔨 <b>TITAN Building</b>\n\n"
            f"<b>Task:</b> {task['title']}\n"
            f"<b>Phase:</b> {task['phase']}\n"
            f"<b>ID:</b> {task['id']}\n"
        )
        _send_telegram(msg)
        self.messages_sent += 1

    def task_completed(self, task: dict, files_written: list[str]):
        """Notify that a build task completed successfully."""
        files_str = "\n".join(f"  • {f}" for f in files_written)
        msg = (
            f"✅ <b>TITAN Built</b>\n\n"
            f"<b>Task:</b> {task['title']}\n"
            f"<b>Files:</b>\n{files_str}\n"
        )
        _send_telegram(msg)
        self.messages_sent += 1

    def task_failed(self, task: dict, error: str):
        """Notify that a build task failed."""
        msg = (
            f"❌ <b>TITAN Build Failed</b>\n\n"
            f"<b>Task:</b> {task['title']}\n"
            f"<b>Error:</b> {error[:300]}\n"
            f"<b>Attempts:</b> {task.get('attempts', 0)}/3\n"
        )
        _send_telegram(msg)
        self.messages_sent += 1

    def daily_summary(self, summary: dict):
        """Send daily build progress summary."""
        msg = (
            f"📊 <b>TITAN Daily Summary</b>\n\n"
            f"<b>Progress:</b> {summary['progress_pct']}%\n"
            f"<b>Completed:</b> {summary['completed']}/{summary['total_tasks']}\n"
            f"<b>In Progress:</b> {summary['in_progress']}\n"
            f"<b>Failed:</b> {summary['failed']}\n"
            f"<b>Blocked:</b> {summary['blocked']}\n"
            f"<b>Current Phase:</b> {summary['current_phase']}\n"
        )
        _send_telegram(msg)
        self.messages_sent += 1

    def request_approval(self, action: str, details: str) -> bool:
        """Request approval from Nico for a risky action.

        Sends a message with Approve/Deny buttons and waits for response.
        Returns True if approved, False if denied or timeout.
        """
        msg = (
            f"⚠️ <b>TITAN Needs Approval</b>\n\n"
            f"<b>Action:</b> {action}\n"
            f"<b>Details:</b> {details}\n\n"
            f"Tap a button to respond:"
        )

        buttons = [[
            {"text": "✅ Approve", "callback_data": "titan_approve"},
            {"text": "❌ Deny", "callback_data": "titan_deny"},
        ]]

        msg_id = _send_telegram_with_buttons(msg, buttons)
        if not msg_id:
            logger.warning("Could not send approval request — proceeding with caution")
            return False

        logger.info(f"Waiting for approval: {action}")
        response = _get_callback_response()

        if response == "titan_approve":
            _send_telegram("✅ <b>Approved.</b> TITAN proceeding.")
            logger.info(f"Approved: {action}")
            return True
        elif response == "titan_deny":
            _send_telegram("🚫 <b>Denied.</b> TITAN skipping this action.")
            logger.info(f"Denied: {action}")
            return False
        else:
            _send_telegram("⏰ <b>Approval timed out.</b> TITAN skipping this action.")
            logger.warning(f"Approval timeout: {action}")
            return False

    def system_alert(self, message: str):
        """Send a system-level alert (errors, warnings)."""
        msg = f"🚨 <b>TITAN Alert</b>\n\n{message}"
        _send_telegram(msg)
        self.messages_sent += 1

    def build_progress(self, current_task: str, progress_pct: float):
        """Send a brief progress update."""
        bar_len = 20
        filled = int(bar_len * progress_pct / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        msg = (
            f"🏗️ <b>TITAN Progress</b>\n"
            f"[{bar}] {progress_pct:.1f}%\n"
            f"Building: {current_task}"
        )
        _send_telegram(msg)
        self.messages_sent += 1
