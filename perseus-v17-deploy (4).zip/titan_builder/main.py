"""TITAN Website Builder — Main entrypoint."""

import os
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

TEMPLATES_DIR = Path(os.getenv("TEMPLATES_DIR", "./templates"))
OLLAMA_URL = os.getenv("OPENAI_BASE_URL", "http://localhost:11434/v1")
MODEL = os.getenv("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")


def build_site(client_data: dict, output_dir: str) -> dict:
    """Build a website from template + client data.
    
    Args:
        client_data: Dict with business_name, industry, services, etc.
        output_dir: Where to write the generated site files
        
    Returns:
        Dict with status, output_path, and any warnings
    """
    from titan_builder.planner import select_template
    from titan_builder.code_agent import generate_content
    from titan_builder.test_runner import validate_site
    from titan_builder.deployer import deploy_to_netlify
    
    industry = client_data.get("industry", "general")
    
    # Step 1: Select template
    template = select_template(industry, TEMPLATES_DIR)
    logger.info(f"Selected template: {template['name']} for {industry}")
    
    # Step 2: Generate content
    site_files = generate_content(template, client_data, MODEL)
    logger.info(f"Generated {len(site_files)} files")
    
    # Step 3: Write to output directory
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    for filename, content in site_files.items():
        (output_path / filename).write_text(content)
    
    # Step 4: Validate
    validation = validate_site(output_path)
    
    return {
        "status": "success" if validation["passed"] else "needs_review",
        "output_path": str(output_path),
        "files": list(site_files.keys()),
        "validation": validation,
    }
