"""
TITAN Builder — Deployer
==========================
Handles writing generated code to disk, restarting Docker services,
and rolling back if something breaks.

Safety: Always creates a backup before overwriting. Checks Docker health
after any restart. If health fails, rolls back automatically.
"""

import logging
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("titan.deployer")

REPO_ROOT = Path(os.getenv("REPO_ROOT", "/app"))
BACKUP_DIR = REPO_ROOT / "backups" / "titan_builder"
DOCKER_TIMEOUT = 60  # seconds to wait for healthy after restart


class DeployResult:
    """Result of a deploy operation."""

    def __init__(self, success: bool, action: str, details: str = ""):
        self.success = success
        self.action = action
        self.details = details

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "action": self.action,
            "details": self.details,
        }


class Deployer:
    """Writes code to disk and manages Docker service restarts."""

    def __init__(self):
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    def write_file(self, filepath: str, content: str) -> DeployResult:
        """Write generated code to the repo with backup.

        Creates parent directories if needed. Backs up existing file.
        """
        full_path = REPO_ROOT / filepath
        backup_path = None

        # Backup existing file
        if full_path.exists():
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            safe_name = filepath.replace("/", "__")
            backup_path = BACKUP_DIR / f"{safe_name}.{timestamp}.bak"
            try:
                shutil.copy2(full_path, backup_path)
                logger.info(f"Backed up {filepath} → {backup_path}")
            except Exception as e:
                return DeployResult(
                    False, "backup",
                    f"Failed to backup {filepath}: {e}"
                )

        # Create parent directories
        full_path.parent.mkdir(parents=True, exist_ok=True)

        # Ensure __init__.py exists in parent if it's a Python package
        if filepath.endswith(".py"):
            init_path = full_path.parent / "__init__.py"
            if not init_path.exists() and full_path.parent != REPO_ROOT:
                init_path.touch()
                logger.info(f"Created {init_path.relative_to(REPO_ROOT)}")

        # Write the file
        try:
            full_path.write_text(content)
            logger.info(f"Wrote {filepath} ({len(content)} bytes)")
            return DeployResult(
                True, "write",
                f"Wrote {filepath} ({content.count(chr(10)) + 1} lines)"
            )
        except Exception as e:
            # Restore backup if write failed
            if backup_path and backup_path.exists():
                shutil.copy2(backup_path, full_path)
                logger.info(f"Restored backup for {filepath}")
            return DeployResult(False, "write", f"Failed to write {filepath}: {e}")

    def rollback_file(self, filepath: str) -> DeployResult:
        """Rollback a file to its most recent backup."""
        safe_name = filepath.replace("/", "__")
        backups = sorted(
            BACKUP_DIR.glob(f"{safe_name}.*.bak"),
            reverse=True
        )

        if not backups:
            return DeployResult(
                False, "rollback",
                f"No backups found for {filepath}"
            )

        latest_backup = backups[0]
        full_path = REPO_ROOT / filepath

        try:
            shutil.copy2(latest_backup, full_path)
            logger.info(f"Rolled back {filepath} from {latest_backup.name}")
            return DeployResult(
                True, "rollback",
                f"Rolled back {filepath} to {latest_backup.name}"
            )
        except Exception as e:
            return DeployResult(
                False, "rollback",
                f"Rollback failed for {filepath}: {e}"
            )

    def restart_service(self, service_name: str) -> DeployResult:
        """Restart a Docker Compose service and wait for health."""
        logger.info(f"Restarting Docker service: {service_name}")

        try:
            # Restart the service
            result = subprocess.run(
                ["docker", "compose", "restart", service_name],
                capture_output=True, text=True, timeout=30,
                cwd=str(REPO_ROOT),
            )
            if result.returncode != 0:
                return DeployResult(
                    False, "restart",
                    f"docker compose restart {service_name} failed: {result.stderr}"
                )

            # Wait for healthy
            healthy = self._wait_for_healthy(service_name)
            if healthy:
                return DeployResult(
                    True, "restart",
                    f"Service {service_name} restarted and healthy"
                )
            else:
                return DeployResult(
                    False, "restart",
                    f"Service {service_name} restarted but not healthy after {DOCKER_TIMEOUT}s"
                )

        except subprocess.TimeoutExpired:
            return DeployResult(
                False, "restart",
                f"Restart command timed out for {service_name}"
            )
        except Exception as e:
            return DeployResult(
                False, "restart",
                f"Restart failed for {service_name}: {e}"
            )

    def rebuild_service(self, service_name: str) -> DeployResult:
        """Rebuild and restart a Docker Compose service."""
        logger.info(f"Rebuilding Docker service: {service_name}")

        try:
            result = subprocess.run(
                ["docker", "compose", "up", "-d", "--build", service_name],
                capture_output=True, text=True, timeout=120,
                cwd=str(REPO_ROOT),
            )
            if result.returncode != 0:
                return DeployResult(
                    False, "rebuild",
                    f"Rebuild failed for {service_name}: {result.stderr}"
                )

            healthy = self._wait_for_healthy(service_name)
            if healthy:
                return DeployResult(
                    True, "rebuild",
                    f"Service {service_name} rebuilt and healthy"
                )
            else:
                return DeployResult(
                    False, "rebuild",
                    f"Service {service_name} rebuilt but not healthy"
                )

        except subprocess.TimeoutExpired:
            return DeployResult(
                False, "rebuild",
                f"Rebuild timed out for {service_name}"
            )
        except Exception as e:
            return DeployResult(
                False, "rebuild",
                f"Rebuild error for {service_name}: {e}"
            )

    def check_all_healthy(self) -> DeployResult:
        """Check that all Docker services are healthy."""
        try:
            result = subprocess.run(
                ["docker", "compose", "ps", "--format", "json"],
                capture_output=True, text=True, timeout=15,
                cwd=str(REPO_ROOT),
            )
            if result.returncode != 0:
                return DeployResult(
                    False, "health_check",
                    f"docker compose ps failed: {result.stderr}"
                )

            # Count running vs not
            lines = result.stdout.strip().split("\n")
            running = sum(1 for line in lines if "running" in line.lower())
            total = len(lines)

            if running == total and total > 0:
                return DeployResult(
                    True, "health_check",
                    f"All {total} services running"
                )
            else:
                return DeployResult(
                    False, "health_check",
                    f"Only {running}/{total} services running"
                )

        except Exception as e:
            return DeployResult(
                False, "health_check",
                f"Health check error: {e}"
            )

    def determine_affected_service(self, filepath: str) -> str | None:
        """Determine which Docker service is affected by a file change."""
        service_map = {
            "agents/": "crewai",
            "tools/": "crewai",
            # Hermes is NOT a Docker service — installed natively via Nous Research script.
            # Do NOT map hermes/ to any container.
            "world/": None,  # Deferred
            "titan_builder/": None,  # Runs natively, not in Docker
            "n8n_workflows/": None,  # Imported via N8N API, no restart
            "tests/": None,  # No restart needed
        }

        for prefix, service in service_map.items():
            if filepath.startswith(prefix):
                return service

        return None

    def _wait_for_healthy(self, service_name: str) -> bool:
        """Wait for a Docker service to become healthy."""
        start = time.time()
        while time.time() - start < DOCKER_TIMEOUT:
            try:
                result = subprocess.run(
                    [
                        "docker", "inspect",
                        "--format", "{{.State.Health.Status}}",
                        f"perseus-repo-{service_name}-1",
                    ],
                    capture_output=True, text=True, timeout=5,
                )
                status = result.stdout.strip()
                if status == "healthy":
                    return True
                if status == "unhealthy":
                    logger.warning(f"{service_name} is unhealthy")
                    return False
            except Exception:
                pass
            time.sleep(3)

        return False
