"""
TITAN Builder — Code Agent
============================
Uses Qwen2.5 14B running on local Ollama to generate, edit, and review code.
This is the hands that build PERSEUS — the planner decides what, this builds it.

Safety rules:
  - Never deletes files without backup
  - Never modifies .env or docker-compose.yaml directly (uses deployer)
  - Never runs pip install or system commands (uses deployer)
  - All generated code goes through test_runner before commit
  - Max file size: 500 lines (splits into modules if bigger)
"""

import json
import logging
import os
import re
from pathlib import Path
from datetime import datetime, timezone

import ollama

logger = logging.getLogger("titan.code_agent")

MODEL = os.getenv("TITAN_MODEL", "qwen2.5:14b-instruct-q4_K_M")
REPO_ROOT = Path(os.getenv("REPO_ROOT", "/app"))
MAX_FILE_LINES = 500
MAX_RETRIES = 2
OLLAMA_TIMEOUT = 180  # seconds


def _call_ollama(system_prompt: str, user_prompt: str) -> str:
    """Call Qwen2.5 14B via Ollama with timeout."""
    try:
        response = ollama.chat(
            model=MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            options={"timeout": OLLAMA_TIMEOUT, "num_ctx": 8192},
        )
        return response["message"]["content"]
    except Exception as e:
        logger.error(f"Ollama call failed: {e}")
        raise


def _extract_code_blocks(text: str) -> list[dict]:
    """Extract code blocks from LLM response.
    Returns list of {filename, language, content}."""
    blocks = []
    # Match ```language\n...``` or ```filename\n...```
    pattern = r'```(\w+)?\s*\n(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    for lang, content in matches:
        blocks.append({
            "language": lang or "python",
            "content": content.strip(),
        })
    return blocks


def _extract_filename_from_response(text: str, task: dict) -> str | None:
    """Try to extract the target filename from the LLM response."""
    # Check if LLM specified a filename
    match = re.search(r'#\s*File:\s*(.+\.py)', text)
    if match:
        return match.group(1).strip()
    # Fall back to task's output_files
    output_files = task.get("output_files", [])
    if output_files:
        return output_files[0]
    return None


# ── System Prompts ────────────────────────────────────────

SYSTEM_PROMPT_BUILD = """You are TITAN, an autonomous code agent building the PERSEUS system.
You are running on a Mac Studio M4 Max with 32GB RAM in El Sargento, Mexico.

RULES:
1. Write clean, production-ready Python code. No placeholders, no TODOs, no "implement later".
2. Every function must have a docstring.
3. Every file must have a module docstring explaining what it does.
4. Use type hints on all function signatures.
5. Handle errors explicitly — never bare except.
6. Log important operations using the logging module.
7. Keep files under 500 lines. Split into modules if needed.
8. Follow the existing code style in the PERSEUS repo.
9. Import from tools/ and agents/ using the existing module structure.
10. Use httpx for HTTP calls, ollama for model calls, mem0 for memory.

CONTEXT:
- Ollama runs at http://localhost:11434
- Mem0 runs at http://localhost:8888 (requires MEM0_API_KEY header)
- Qdrant runs at http://localhost:6333
- N8N runs at http://localhost:5678
- Hermes Agent is installed natively via official Nous Research script (NOT a PERSEUS-managed service)
- CrewAI runs at http://localhost:8001
- PostgreSQL is internal Docker only (use docker exec for queries)

OUTPUT FORMAT:
Return ONLY the complete file content inside a single code block.
Start with: # File: <filepath>
Then the full code. No explanation before or after the code block."""


SYSTEM_PROMPT_EDIT = """You are TITAN, editing an existing file in the PERSEUS system.

RULES:
1. Return the COMPLETE updated file, not just the changes.
2. Preserve all existing functionality — do not remove working code.
3. Add your changes cleanly integrated with the existing code.
4. Keep the same coding style as the original file.
5. If the file is getting too long (>500 lines), suggest splitting in a comment.

OUTPUT FORMAT:
Return ONLY the complete updated file content inside a single code block.
Start with: # File: <filepath>
Then the full updated code."""


SYSTEM_PROMPT_REVIEW = """You are TITAN, reviewing code for correctness and safety.

Check for:
1. Syntax errors
2. Import errors (missing or wrong imports)
3. Undefined variables or functions
4. Security issues (injection, path traversal, exposed secrets)
5. Logic errors
6. Missing error handling
7. Compliance with PERSEUS architecture

OUTPUT FORMAT:
Return a JSON object:
{
  "passed": true/false,
  "issues": ["issue 1", "issue 2"],
  "severity": "none" | "minor" | "major" | "critical",
  "suggested_fixes": ["fix 1", "fix 2"]
}"""


SYSTEM_PROMPT_N8N = """You are TITAN, building N8N workflow definitions for PERSEUS.

RULES:
1. Output valid N8N workflow JSON that can be imported directly.
2. Use webhook triggers for external events.
3. Use cron triggers for scheduled tasks.
4. Use HTTP Request nodes for API calls to internal services.
5. Use Function nodes for custom logic.
6. Include error handling nodes (Error Trigger).
7. Set reasonable timeouts on all HTTP requests.

CONTEXT:
- Mem0 API: http://mem0:8888 (internal Docker network, use service name)
- CrewAI API: http://crewai:8001
- Hermes Agent runs natively on macOS (installed via curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash). NOT a Docker service. Do not create or reference any hermes/ directory or hermes container.
- All Docker services are on the perseus-net Docker network.
- Use MEM0_API_KEY from environment for Mem0 auth.

OUTPUT FORMAT:
Return ONLY the complete N8N workflow JSON inside a single code block.
No explanation before or after."""


class CodeAgent:
    """Generates and edits code using Qwen2.5 14B."""

    def __init__(self):
        self.build_count = 0
        self.error_count = 0

    def build_file(self, task: dict) -> dict:
        """Generate a new file based on task description.

        Returns:
            {
                "success": bool,
                "filepath": str,
                "content": str,
                "review": dict,
                "error": str | None,
            }
        """
        logger.info(f"Building file for task: {task['id']} — {task['title']}")

        # Determine which system prompt to use
        output_files = task.get("output_files", [])
        is_n8n = any(f.endswith(".json") and "n8n" in f for f in output_files)
        system_prompt = SYSTEM_PROMPT_N8N if is_n8n else SYSTEM_PROMPT_BUILD

        # Build the user prompt with full context
        user_prompt = self._build_prompt(task)

        # Generate code
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = _call_ollama(system_prompt, user_prompt)
                code_blocks = _extract_code_blocks(response)

                if not code_blocks:
                    # Try to use the raw response as code
                    logger.warning("No code blocks found, using raw response")
                    content = response.strip()
                else:
                    content = code_blocks[0]["content"]

                filepath = _extract_filename_from_response(response, task)
                if not filepath:
                    return {
                        "success": False,
                        "filepath": None,
                        "content": None,
                        "review": None,
                        "error": "Could not determine output filepath",
                    }

                # Strip the "# File: ..." header if present
                if content.startswith("# File:"):
                    content = "\n".join(content.split("\n")[1:]).strip()

                # Review the generated code
                review = self.review_code(content, filepath)

                if review.get("severity") == "critical":
                    if attempt < MAX_RETRIES:
                        logger.warning(
                            f"Critical issues found, retrying ({attempt + 1}/{MAX_RETRIES}): "
                            f"{review['issues']}"
                        )
                        user_prompt += (
                            f"\n\nPREVIOUS ATTEMPT HAD CRITICAL ISSUES:\n"
                            f"{json.dumps(review['issues'])}\n"
                            f"Fix these issues in your next attempt."
                        )
                        continue
                    else:
                        return {
                            "success": False,
                            "filepath": filepath,
                            "content": content,
                            "review": review,
                            "error": f"Critical issues after {MAX_RETRIES} retries: {review['issues']}",
                        }

                self.build_count += 1
                return {
                    "success": True,
                    "filepath": filepath,
                    "content": content,
                    "review": review,
                }

            except Exception as e:
                logger.error(f"Build attempt {attempt + 1} failed: {e}")
                if attempt == MAX_RETRIES:
                    self.error_count += 1
                    return {
                        "success": False,
                        "filepath": None,
                        "content": None,
                        "review": None,
                        "error": str(e),
                    }

    def edit_file(self, filepath: str, instructions: str) -> dict:
        """Edit an existing file based on instructions.

        Returns same structure as build_file.
        """
        full_path = REPO_ROOT / filepath
        if not full_path.exists():
            return {
                "success": False,
                "filepath": filepath,
                "content": None,
                "review": None,
                "error": f"File not found: {filepath}",
            }

        existing_content = full_path.read_text()

        user_prompt = (
            f"Edit this file: {filepath}\n\n"
            f"Current content:\n```python\n{existing_content}\n```\n\n"
            f"Instructions:\n{instructions}"
        )

        try:
            response = _call_ollama(SYSTEM_PROMPT_EDIT, user_prompt)
            code_blocks = _extract_code_blocks(response)

            if not code_blocks:
                content = response.strip()
            else:
                content = code_blocks[0]["content"]

            if content.startswith("# File:"):
                content = "\n".join(content.split("\n")[1:]).strip()

            review = self.review_code(content, filepath)

            return {
                "success": review.get("severity") != "critical",
                "filepath": filepath,
                "content": content,
                "review": review,
            }
        except Exception as e:
            return {
                "success": False,
                "filepath": filepath,
                "content": None,
                "review": None,
                "error": str(e),
            }

    def review_code(self, content: str, filepath: str) -> dict:
        """Review code for correctness and safety."""
        user_prompt = (
            f"Review this code for file: {filepath}\n\n"
            f"```python\n{content}\n```"
        )

        try:
            response = _call_ollama(SYSTEM_PROMPT_REVIEW, user_prompt)
            # Try to parse as JSON
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {
                "passed": True,
                "issues": [],
                "severity": "none",
                "suggested_fixes": [],
            }
        except (json.JSONDecodeError, Exception) as e:
            logger.warning(f"Review parsing failed: {e}")
            return {
                "passed": True,
                "issues": ["Review could not be parsed — manual check recommended"],
                "severity": "minor",
                "suggested_fixes": [],
            }

    def _build_prompt(self, task: dict) -> str:
        """Build a detailed prompt for code generation."""
        parts = [
            f"BUILD TASK: {task['title']}",
            f"\nDESCRIPTION:\n{task['description']}",
        ]

        output_files = task.get("output_files", [])
        if output_files:
            parts.append(f"\nOUTPUT FILE(S): {', '.join(output_files)}")

        # Add context about existing files that might be relevant
        deps = task.get("depends_on", [])
        if deps:
            parts.append(f"\nThis task depends on: {', '.join(deps)}")
            parts.append("Reference the output of those tasks in your implementation.")

        # Add existing file context for edits
        for out_file in output_files:
            existing = REPO_ROOT / out_file
            parent_init = existing.parent / "__init__.py"
            if parent_init.exists() and parent_init.stat().st_size > 0:
                parts.append(
                    f"\nExisting __init__.py in {existing.parent.name}/:\n"
                    f"```python\n{parent_init.read_text()}\n```"
                )

        return "\n".join(parts)

    def get_stats(self) -> dict:
        """Return agent statistics."""
        return {
            "files_built": self.build_count,
            "errors": self.error_count,
            "model": MODEL,
        }
