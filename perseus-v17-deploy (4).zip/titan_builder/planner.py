"""
TITAN Builder — Task Planner
==============================
Reads the PERSEUS v13 blueprint and maintains a prioritized build queue.
Each task is atomic: one file, one workflow, one integration at a time.
The planner never skips ahead — each task must pass testing before the next starts.

Build priority order (from v13 Part 14, revised for self-build-first):
  Phase 0: TITAN Builder Agent itself (self-improvement)
  Phase 1: Outbound email pipeline (fastest to revenue)
  Phase 2: Website auto-builder
  Phase 3: AI receptionist upsell
  Phase 4: Hermes configuration (native install — NOT built by PERSEUS)
  Phase 5: Enterprise pipeline
  Phase 6: Learning loops + nightly review
  Phase 7: PERSEUS World (deferred — 32GB mode)
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from enum import Enum

logger = logging.getLogger("titan.planner")

PLAN_FILE = os.getenv("TITAN_PLAN_FILE", "titan_builder/build_queue.json")
REPO_ROOT = os.getenv("REPO_ROOT", "/app")


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    TESTING = "testing"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    NEEDS_APPROVAL = "needs_approval"


class TaskPriority(int, Enum):
    CRITICAL = 0   # Self-improvement, broken fixes
    HIGH = 1       # Revenue-generating
    MEDIUM = 2     # Automation, efficiency
    LOW = 3        # Nice-to-have, polish
    DEFERRED = 4   # Needs more RAM / hardware


# ── Master Build Queue ────────────────────────────────────
# This is the initial queue. TITAN appends tasks as it discovers
# what's needed. Each task has enough context for the code agent
# to build it without additional guidance.

MASTER_QUEUE = [
    # ── Phase 0: Self-improvement ──────────────────────────
    {
        "id": "P0-001",
        "phase": 0,
        "priority": TaskPriority.CRITICAL,
        "title": "TITAN Builder self-test suite",
        "description": (
            "Write tests/test_titan_builder.py that validates the planner, "
            "code agent, test runner, deployer, reporter, and guardrails. "
            "Use pytest. Mock Ollama calls. Cover: task queue CRUD, "
            "code generation prompt format, test execution, rollback logic, "
            "Telegram message format, guardrail rejection of dangerous ops."
        ),
        "output_files": ["tests/test_titan_builder.py"],
        "depends_on": [],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 1: Outbound email pipeline ───────────────────
    {
        "id": "P1-001",
        "phase": 1,
        "priority": TaskPriority.HIGH,
        "title": "N8N lead intake workflow",
        "description": (
            "Create an N8N workflow JSON that: "
            "1) Triggers on webhook POST with lead data (name, email, business, city). "
            "2) Validates required fields. "
            "3) Stores lead in Mem0 with category 'lead'. "
            "4) Fires a WorldEvent (logged to Mem0, Hermes picks up via its own polling). "
            "5) Returns 201 with lead_id. "
            "Save as n8n_workflows/lead_intake.json."
        ),
        "output_files": ["n8n_workflows/lead_intake.json"],
        "depends_on": [],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P1-002",
        "phase": 1,
        "priority": TaskPriority.HIGH,
        "title": "Lead Research Agent logic",
        "description": (
            "Implement agents/lead_researcher/main.py that: "
            "1) Takes a business name + city. "
            "2) Searches for the business online (Google, Yelp, social). "
            "3) Checks if they have a website. "
            "4) Scores the lead (0-100) based on: no website (+40), "
            "   positive reviews (+20), local business (+10), "
            "   recent activity (+15), industry match (+15). "
            "5) Stores enriched lead data in Mem0. "
            "6) Returns structured JSON with score and all findings. "
            "Uses Qwen2.5 14B via Ollama for reasoning."
        ),
        "output_files": ["agents/lead_researcher/main.py"],
        "depends_on": [],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P1-003",
        "phase": 1,
        "priority": TaskPriority.HIGH,
        "title": "Copywriter Agent — cold email",
        "description": (
            "Implement agents/copywriter/main.py that: "
            "1) Takes enriched lead data from Lead Researcher. "
            "2) Loads soul_copy.md for voice/tone. "
            "3) Generates 3 email variants (subject + body) personalized "
            "   to the lead's business, city, and pain points. "
            "4) Each email must be under 150 words, no fluff, direct value prop. "
            "5) Includes a preview link placeholder for the auto-built website. "
            "6) Returns structured JSON with all 3 variants. "
            "Uses Qwen2.5 14B via Ollama."
        ),
        "output_files": ["agents/copywriter/main.py"],
        "depends_on": ["P1-002"],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P1-004",
        "phase": 1,
        "priority": TaskPriority.HIGH,
        "title": "N8N email send workflow (Smartlead integration)",
        "description": (
            "Create an N8N workflow JSON that: "
            "1) Triggers daily at 9am local time. "
            "2) Pulls leads scored > 60 from Mem0 that haven't been emailed. "
            "3) Calls Copywriter Agent for personalized emails. "
            "4) Sends via Smartlead API (or queues if API not configured). "
            "5) Logs send status to Mem0. "
            "6) Sends Telegram summary: 'Sent X emails today, top lead: Y'. "
            "Save as n8n_workflows/email_send.json."
        ),
        "output_files": ["n8n_workflows/email_send.json"],
        "depends_on": ["P1-001", "P1-003"],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P1-005",
        "phase": 1,
        "priority": TaskPriority.HIGH,
        "title": "N8N reply handler workflow",
        "description": (
            "Create an N8N workflow JSON that: "
            "1) Triggers on Smartlead webhook for email replies. "
            "2) Classifies reply as: interested, not interested, "
            "   out of office, bounce, unsubscribe. "
            "3) If interested: create task for Sales Closer, "
            "   send Telegram alert 'Hot lead: [name] replied interested'. "
            "4) If not interested: mark lead as cold in Mem0. "
            "5) If bounce: remove from future sends. "
            "Save as n8n_workflows/reply_handler.json."
        ),
        "output_files": ["n8n_workflows/reply_handler.json"],
        "depends_on": ["P1-004"],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 2: Website auto-builder ──────────────────────
    {
        "id": "P2-001",
        "phase": 2,
        "priority": TaskPriority.HIGH,
        "title": "Website template system",
        "description": (
            "Create tools/website_builder.py that: "
            "1) Takes business name, type, city, colors, and content. "
            "2) Generates a complete single-page website using HTML/CSS/JS. "
            "3) Mobile responsive, fast loading, professional. "
            "4) Templates for: restaurant, contractor, salon, retail, service. "
            "5) Includes SEO meta tags, favicon, contact form. "
            "6) Outputs to a directory ready for deployment. "
            "Uses Qwen2.5 14B for content generation, templates for structure."
        ),
        "output_files": ["tools/website_builder.py"],
        "depends_on": [],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P2-002",
        "phase": 2,
        "priority": TaskPriority.HIGH,
        "title": "Website deploy pipeline",
        "description": (
            "Create tools/website_deployer.py that: "
            "1) Takes a built website directory. "
            "2) Deploys to Netlify via API (free tier). "
            "3) Returns the live URL. "
            "4) Stores deploy metadata in Mem0. "
            "5) Generates a preview screenshot (headless browser). "
            "The preview URL goes in the cold email so leads see their site."
        ),
        "output_files": ["tools/website_deployer.py"],
        "depends_on": ["P2-001"],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 3: AI receptionist upsell ────────────────────
    {
        "id": "P3-001",
        "phase": 3,
        "priority": TaskPriority.MEDIUM,
        "title": "AI receptionist agent",
        "description": (
            "Create agents/receptionist/main.py that: "
            "1) Handles inbound calls via Vapi. "
            "2) Loads business-specific context from Mem0. "
            "3) Answers FAQs, books appointments, takes messages. "
            "4) Logs call summary to Mem0. "
            "5) Sends Telegram notification for calls needing human follow-up. "
            "This is an upsell after website sale (provisioned by Voice Delivery Agent)."
        ),
        "output_files": ["agents/receptionist/main.py"],
        "depends_on": ["P2-002"],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 4: Hermes configuration ──────────────────────
    # CRITICAL: Hermes is installed ONLY via the official Nous Research script:
    #   curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash
    # PERSEUS does NOT build, modify, or manage Hermes source code.
    # Anything calling itself "Hermes" that didn't come from that installer is INVALID.
    {
        "id": "P4-001",
        "phase": 4,
        "priority": TaskPriority.MEDIUM,
        "title": "Hermes SOUL.md + cron configuration",
        "description": (
            "Configure the officially-installed Hermes Agent: "
            "1) Copy soul/soul_hermes.md to ~/.hermes/SOUL.md. "
            "2) Write ~/.hermes/config.env pointing to local Ollama. "
            "3) Set up Hermes cron jobs: morning-briefing (7AM), "
            "   nightly-review (11PM), uptime-check (6h), "
            "   monthly-reports (1st of month), budget-check (Monday). "
            "4) Verify Hermes binary exists via 'command -v hermes'. "
            "5) Test Telegram gateway responds to /status. "
            "DO NOT create any hermes/ directory or hermes source code. "
            "Hermes is an external binary — we only configure it."
        ),
        "output_files": [],  # No PERSEUS source files — Hermes is external
        "depends_on": ["P1-004"],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 5: Enterprise pipeline ───────────────────────
    {
        "id": "P5-001",
        "phase": 5,
        "priority": TaskPriority.MEDIUM,
        "title": "Enterprise lead qualification agent",
        "description": (
            "Create agents/enterprise/main.py that: "
            "1) Identifies mid-size companies (50-500 employees) "
            "   in target industries. "
            "2) Researches their current tech stack and pain points. "
            "3) Scores enterprise fit (0-100). "
            "4) Generates personalized outreach for $50k PERSEUS Enterprise. "
            "5) Sends qualified leads to Nico via Telegram for approval "
            "   before any outreach. "
            "This is the high-ticket revenue stream."
        ),
        "output_files": ["agents/enterprise/main.py"],
        "depends_on": ["P1-002"],
        "status": TaskStatus.PENDING,
    },

    # ── Phase 6: Learning loops ────────────────────────────
    {
        "id": "P6-001",
        "phase": 6,
        "priority": TaskPriority.MEDIUM,
        "title": "Nightly learning loop workflow",
        "description": (
            "Create n8n_workflows/nightly_review.json that: "
            "1) Triggers at 11pm local time every night. "
            "2) Pulls today's metrics: emails sent, opens, replies, "
            "   leads scored, websites built, revenue. "
            "3) Compares to yesterday and weekly average. "
            "4) Uses Qwen2.5 14B to analyze: what worked, what didn't, "
            "   what to change tomorrow. "
            "5) Stores analysis in Mem0 as 'nightly_review'. "
            "6) Updates strategy variables (targeting, copy, pricing). "
            "7) Sends Telegram summary to Nico. "
            "This is how PERSEUS learns and improves every day."
        ),
        "output_files": ["n8n_workflows/nightly_review.json"],
        "depends_on": ["P1-004"],
        "status": TaskStatus.PENDING,
    },
    {
        "id": "P6-002",
        "phase": 6,
        "priority": TaskPriority.MEDIUM,
        "title": "Monthly strategy review workflow",
        "description": (
            "Create n8n_workflows/monthly_review.json that: "
            "1) Triggers on 1st of each month at 10am. "
            "2) Compiles all nightly reviews into monthly analysis. "
            "3) Reviews: total revenue, costs, ROI by channel, "
            "   best performing emails, lead sources, conversion rates. "
            "4) Proposes reinvestment allocation (50/50 rule). "
            "5) Proposes hardware/software upgrades if budget allows. "
            "6) Sends detailed report to Nico via Telegram. "
            "7) Waits for approval on any spend proposals."
        ),
        "output_files": ["n8n_workflows/monthly_review.json"],
        "depends_on": ["P6-001"],
        "status": TaskStatus.PENDING,
    },
]


class BuildPlanner:
    """Manages the PERSEUS build queue."""

    def __init__(self):
        self.queue = []
        self.plan_path = Path(REPO_ROOT) / PLAN_FILE
        self._load_or_init()

    def _load_or_init(self):
        """Load existing queue from disk, or initialize from master."""
        if self.plan_path.exists():
            try:
                with open(self.plan_path) as f:
                    saved = json.load(f)
                self.queue = saved.get("tasks", [])
                logger.info(f"Loaded {len(self.queue)} tasks from {self.plan_path}")
                return
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Corrupt plan file, reinitializing: {e}")

        # Initialize from master queue
        self.queue = []
        for task in MASTER_QUEUE:
            t = dict(task)
            t["priority"] = int(t["priority"])
            t["status"] = str(t["status"])
            t["created_at"] = datetime.now(timezone.utc).isoformat()
            t["started_at"] = None
            t["completed_at"] = None
            t["attempts"] = 0
            t["last_error"] = None
            t["built_by"] = None  # "titan" or "human"
            self.queue.append(t)
        self._save()
        logger.info(f"Initialized build queue with {len(self.queue)} tasks")

    def _save(self):
        """Persist queue to disk."""
        self.plan_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.plan_path, "w") as f:
            json.dump({
                "version": "1.0",
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "tasks": self.queue,
            }, f, indent=2)

    def get_next_task(self) -> dict | None:
        """Get the highest-priority task that's ready to build.
        A task is ready if all its dependencies are completed."""
        completed_ids = {
            t["id"] for t in self.queue if t["status"] == TaskStatus.COMPLETED
        }

        candidates = []
        for task in self.queue:
            if task["status"] != TaskStatus.PENDING:
                continue
            if task["priority"] == TaskPriority.DEFERRED:
                continue
            deps = set(task.get("depends_on", []))
            if deps.issubset(completed_ids):
                candidates.append(task)

        if not candidates:
            return None

        # Sort by priority (lower = more important), then phase, then id
        candidates.sort(key=lambda t: (t["priority"], t["phase"], t["id"]))
        return candidates[0]

    def start_task(self, task_id: str):
        """Mark task as in progress."""
        for task in self.queue:
            if task["id"] == task_id:
                task["status"] = TaskStatus.IN_PROGRESS
                task["started_at"] = datetime.now(timezone.utc).isoformat()
                task["attempts"] += 1
                self._save()
                logger.info(f"Started task {task_id}: {task['title']}")
                return
        raise ValueError(f"Task {task_id} not found")

    def complete_task(self, task_id: str):
        """Mark task as completed."""
        for task in self.queue:
            if task["id"] == task_id:
                task["status"] = TaskStatus.COMPLETED
                task["completed_at"] = datetime.now(timezone.utc).isoformat()
                task["built_by"] = "titan"
                self._save()
                logger.info(f"Completed task {task_id}: {task['title']}")
                return
        raise ValueError(f"Task {task_id} not found")

    def fail_task(self, task_id: str, error: str):
        """Mark task as failed with error details."""
        for task in self.queue:
            if task["id"] == task_id:
                task["status"] = TaskStatus.FAILED
                task["last_error"] = error
                self._save()
                logger.warning(f"Failed task {task_id}: {error}")
                return
        raise ValueError(f"Task {task_id} not found")

    def retry_task(self, task_id: str):
        """Reset a failed task back to pending for retry."""
        for task in self.queue:
            if task["id"] == task_id:
                if task["attempts"] >= 3:
                    task["status"] = TaskStatus.BLOCKED
                    logger.error(f"Task {task_id} blocked after 3 attempts")
                else:
                    task["status"] = TaskStatus.PENDING
                self._save()
                return
        raise ValueError(f"Task {task_id} not found")

    def add_task(self, task: dict):
        """Add a new task discovered during building."""
        task.setdefault("status", TaskStatus.PENDING)
        task.setdefault("created_at", datetime.now(timezone.utc).isoformat())
        task.setdefault("started_at", None)
        task.setdefault("completed_at", None)
        task.setdefault("attempts", 0)
        task.setdefault("last_error", None)
        task.setdefault("built_by", None)
        task["priority"] = int(task.get("priority", TaskPriority.MEDIUM))
        task["status"] = str(task["status"])
        self.queue.append(task)
        self._save()
        logger.info(f"Added new task: {task['id']} — {task['title']}")

    def get_status_summary(self) -> dict:
        """Get a summary of the build queue status."""
        counts = {}
        for task in self.queue:
            status = task["status"]
            counts[status] = counts.get(status, 0) + 1

        total = len(self.queue)
        completed = counts.get(TaskStatus.COMPLETED, 0)
        pct = (completed / total * 100) if total > 0 else 0

        return {
            "total_tasks": total,
            "completed": completed,
            "in_progress": counts.get(TaskStatus.IN_PROGRESS, 0),
            "pending": counts.get(TaskStatus.PENDING, 0),
            "failed": counts.get(TaskStatus.FAILED, 0),
            "blocked": counts.get(TaskStatus.BLOCKED, 0),
            "progress_pct": round(pct, 1),
            "current_phase": self._get_current_phase(),
        }

    def _get_current_phase(self) -> int:
        """Determine which phase we're currently building."""
        for task in self.queue:
            if task["status"] in (TaskStatus.PENDING, TaskStatus.IN_PROGRESS):
                return task["phase"]
        return -1  # All done
