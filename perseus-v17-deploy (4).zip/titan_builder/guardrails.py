"""
TITAN Builder — Guardrails
============================
Prevents the builder from doing anything dangerous.
Every operation passes through guardrails before execution.

Rules:
  1. Never delete production data
  2. Never modify .env directly
  3. Never write outside the repo root
  4. Never restart more than 2 services in a row
  5. Never deploy if Docker stack is unhealthy
  6. Never exceed cost thresholds without approval
  7. Never build during active service incidents
  8. Always back up before overwrite
"""

import logging
import os
import re
import subprocess
import time
from pathlib import Path

logger = logging.getLogger("titan.guardrails")

REPO_ROOT = Path(os.getenv("REPO_ROOT", "/app"))
MAX_CONSECUTIVE_RESTARTS = 2
MAX_FILE_WRITE_SIZE = 50_000  # 50KB per file
COST_ALERT_THRESHOLD = float(os.getenv("COST_ALERT_THRESHOLD", "450"))
COST_BLOCK_THRESHOLD = float(os.getenv("COST_BLOCK_THRESHOLD", "550"))
MONTHLY_BUDGET = float(os.getenv("MONTHLY_BUDGET", "600"))


class GuardrailViolation(Exception):
    """Raised when an operation violates a guardrail."""

    def __init__(self, rule: str, details: str):
        self.rule = rule
        self.details = details
        super().__init__(f"[GUARDRAIL {rule}] {details}")


# ── Forbidden Paths ─────────────────────────────────────────

FORBIDDEN_PATHS = {
    ".env",
    ".env.example",
    "docker-compose.yaml",     # Only deployer touches this
    "bootstrap.sh",            # Only human edits
    "verify.sh",               # Only human edits
    "Makefile",                # Only human edits
    ".git/",                   # Never touch git internals
}

FORBIDDEN_PATH_PREFIXES = (
    "/etc/",
    "/usr/",
    "/var/",
    "/tmp/",
    "/root/",
    "/System/",
    "/Library/",
    os.path.expanduser("~") + "/.",  # Hidden dirs in home
)


# ── Forbidden Code Patterns ─────────────────────────────────

FORBIDDEN_PATTERNS = [
    (r"os\.system\s*\(", "os.system() — use subprocess with shell=False"),
    (r"subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True",
     "subprocess with shell=True — injection risk"),
    (r"eval\s*\(", "eval() — never use on untrusted input"),
    (r"exec\s*\(", "exec() — never use on untrusted input"),
    (r"__import__\s*\(", "__import__() — use importlib"),
    (r"(?:rm\s+-rf|rmdir)\s+/", "Recursive delete on root path"),
    (r"shutil\.rmtree\s*\(\s*[\"']/", "rmtree on absolute root path"),
    (r"open\s*\(\s*[\"']/etc/", "Writing to /etc"),
    (r"open\s*\(\s*[\"']\.env", "Direct .env file access"),
    (r"password\s*=\s*[\"'][^\"']{4,}[\"']", "Hardcoded password"),
    (r"api_key\s*=\s*[\"'](?:sk-|pk_|rk_)", "Hardcoded API key"),
    (r"requests\.(?:get|post|put|delete)\s*\(\s*[\"']https?://(?!localhost|127\.0\.0\.1|mem0|qdrant|crewai|n8n|host\.docker\.internal)",
     "External HTTP call — only internal services allowed without review"),
    (r"socket\.(?:socket|create_connection)", "Raw socket — not allowed"),
    (r"ctypes\.", "ctypes — not allowed in builder code"),
    (r"pickle\.(?:load|loads)", "pickle.load — deserialization risk"),
]


# ── State Tracking ──────────────────────────────────────────

class GuardrailState:
    """Tracks guardrail state across operations."""

    def __init__(self):
        self.consecutive_restarts = 0
        self.last_restart_time = 0.0
        self.files_written_this_cycle = 0
        self.operations_blocked = 0
        self.operations_allowed = 0


_state = GuardrailState()


# ── Public API ──────────────────────────────────────────────

def check_file_write(filepath: str, content: str) -> None:
    """Validate a file write operation.

    Raises GuardrailViolation if the operation is not allowed.
    """
    # Rule 1: Path must be inside repo root
    resolved = (REPO_ROOT / filepath).resolve()
    if not str(resolved).startswith(str(REPO_ROOT.resolve())):
        _block("PATH_ESCAPE", f"Path escapes repo root: {filepath}")

    # Rule 2: No forbidden paths
    for forbidden in FORBIDDEN_PATHS:
        if filepath == forbidden or filepath.startswith(forbidden):
            _block("FORBIDDEN_PATH", f"Cannot write to protected file: {filepath}")

    # Rule 3: No writing to system paths
    abs_path = str(resolved)
    for prefix in FORBIDDEN_PATH_PREFIXES:
        if abs_path.startswith(prefix):
            _block("SYSTEM_PATH", f"Cannot write to system path: {abs_path}")

    # Rule 4: File size limit
    if len(content) > MAX_FILE_WRITE_SIZE:
        _block(
            "FILE_TOO_LARGE",
            f"File content is {len(content)} bytes (max {MAX_FILE_WRITE_SIZE}). "
            f"Split into smaller modules."
        )

    # Rule 5: Check content for dangerous patterns (Python files only)
    if filepath.endswith(".py"):
        check_code_safety(content, filepath)

    _state.files_written_this_cycle += 1
    _state.operations_allowed += 1
    logger.debug(f"Guardrail ALLOWED file write: {filepath}")


def check_code_safety(content: str, filepath: str) -> None:
    """Check generated code for dangerous patterns.

    Raises GuardrailViolation if dangerous patterns are found.
    """
    violations = []
    for pattern, description in FORBIDDEN_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE):
            violations.append(description)

    if violations:
        _block(
            "DANGEROUS_CODE",
            f"Dangerous patterns in {filepath}: {'; '.join(violations)}"
        )


def check_service_restart(service_name: str) -> None:
    """Validate a Docker service restart.

    Raises GuardrailViolation if too many restarts or stack unhealthy.
    """
    # Rule 1: Rate limit restarts
    now = time.time()
    if now - _state.last_restart_time < 30:
        _state.consecutive_restarts += 1
    else:
        _state.consecutive_restarts = 1
    _state.last_restart_time = now

    if _state.consecutive_restarts > MAX_CONSECUTIVE_RESTARTS:
        _block(
            "RESTART_LIMIT",
            f"Too many consecutive restarts ({_state.consecutive_restarts}). "
            f"Max is {MAX_CONSECUTIVE_RESTARTS}. Waiting for cooldown."
        )

    # Rule 2: Core data services cannot be restarted by TITAN
    protected_services = {"postgres", "qdrant"}
    if service_name in protected_services:
        _block(
            "PROTECTED_SERVICE",
            f"Cannot restart data service '{service_name}'. "
            f"Only human or deployer with approval can restart data services."
        )

    _state.operations_allowed += 1
    logger.debug(f"Guardrail ALLOWED restart: {service_name}")


def check_docker_health() -> bool:
    """Check if the Docker stack is healthy enough for building.

    Returns True if healthy, False if degraded.
    Does NOT raise — builder should just pause if unhealthy.
    """
    try:
        result = subprocess.run(
            ["docker", "compose", "ps", "--format", "{{.Name}} {{.State}}"],
            capture_output=True, text=True, timeout=10,
            cwd=str(REPO_ROOT),
        )
        if result.returncode != 0:
            logger.warning("Cannot check Docker health — docker compose failed")
            return False

        lines = result.stdout.strip().split("\n")
        running = sum(1 for line in lines if "running" in line.lower())
        total = len([line for line in lines if line.strip()])

        if total == 0:
            logger.warning("No Docker services found")
            return False

        health_pct = running / total * 100
        if health_pct < 80:
            logger.warning(
                f"Docker stack degraded: {running}/{total} running ({health_pct:.0f}%)"
            )
            return False

        return True

    except subprocess.TimeoutExpired:
        logger.warning("Docker health check timed out")
        return False
    except FileNotFoundError:
        logger.warning("Docker not found — running outside Docker host?")
        return True  # Allow building if Docker check isn't possible


def check_cost_threshold(current_spend: float) -> str:
    """Check spending against budget thresholds.

    Returns:
        "ok" — under alert threshold
        "alert" — between alert and block thresholds
        "block" — over block threshold, needs approval
    """
    if current_spend >= COST_BLOCK_THRESHOLD:
        logger.warning(
            f"COST BLOCK: ${current_spend:.2f} >= ${COST_BLOCK_THRESHOLD:.2f}"
        )
        return "block"
    elif current_spend >= COST_ALERT_THRESHOLD:
        logger.warning(
            f"COST ALERT: ${current_spend:.2f} >= ${COST_ALERT_THRESHOLD:.2f}"
        )
        return "alert"
    return "ok"


def check_file_delete(filepath: str) -> None:
    """Validate a file deletion. TITAN should almost never delete files.

    Raises GuardrailViolation for any delete attempt on non-backup files.
    """
    # Only allow deleting backup files
    if "backups/" not in filepath and ".bak" not in filepath:
        _block(
            "DELETE_FORBIDDEN",
            f"TITAN cannot delete non-backup files: {filepath}. "
            f"Only backup cleanup is allowed."
        )

    _state.operations_allowed += 1
    logger.debug(f"Guardrail ALLOWED delete: {filepath}")


def check_external_api_call(url: str) -> None:
    """Validate an external API call.

    Only internal services and approved external APIs are allowed.
    """
    allowed_hosts = {
        "localhost",
        "127.0.0.1",
        "host.docker.internal",
        "mem0",
        "qdrant",
        # Hermes is NOT a Docker service — installed natively via Nous Research script
        "crewai",
        "n8n",
        "postgres",
        "pinchtab",
        # Approved external services
        "api.telegram.org",
        "api.smartlead.ai",
        "api.netlify.com",
        "api.stripe.com",
        "api.vapi.ai",
    }

    from urllib.parse import urlparse

    parsed = urlparse(url)
    hostname = parsed.hostname or ""

    if hostname not in allowed_hosts:
        _block(
            "UNAPPROVED_API",
            f"External API call to '{hostname}' is not pre-approved. "
            f"Add to allowed_hosts or request approval."
        )

    _state.operations_allowed += 1


def reset_cycle_counters() -> None:
    """Reset per-build-cycle counters. Called at start of each task."""
    _state.files_written_this_cycle = 0
    _state.consecutive_restarts = 0
    logger.debug("Guardrail cycle counters reset")


def get_stats() -> dict:
    """Return guardrail statistics."""
    return {
        "operations_allowed": _state.operations_allowed,
        "operations_blocked": _state.operations_blocked,
        "files_written_this_cycle": _state.files_written_this_cycle,
        "consecutive_restarts": _state.consecutive_restarts,
    }


# ── Internal Helpers ────────────────────────────────────────

def _block(rule: str, details: str) -> None:
    """Block an operation and raise a violation."""
    _state.operations_blocked += 1
    logger.warning(f"GUARDRAIL BLOCKED [{rule}]: {details}")
    raise GuardrailViolation(rule, details)
