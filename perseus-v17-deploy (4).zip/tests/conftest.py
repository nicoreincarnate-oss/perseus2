"""PERSEUS V17 — Shared test fixtures."""

import os
import pytest

@pytest.fixture
def db_url():
    return os.getenv(
        "POSTGRES_URL",
        "postgresql://perseus:perseus_secure_2026@localhost:5432/perseus"
    )

@pytest.fixture
def mock_env(monkeypatch):
    monkeypatch.setenv("MONTHLY_BUDGET_CAP", "600")
    monkeypatch.setenv("BUDGET_ALERT_THRESHOLD", "0.80")
    monkeypatch.setenv("SMARTLEAD_API_KEY", "test_key")
    monkeypatch.setenv("WISE_API_TOKEN", "test_token")
