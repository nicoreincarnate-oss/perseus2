"""
PERSEUS V17 — Agent Registry & Configuration Tests

Tests that ALL 30 agents are registered, properly configured,
and that enterprise agents are correctly gated.

Run: pytest tests/ -v
"""

import os
import sys
import pytest
import yaml

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agents"))

# ── Constants ──────────────────────────────────────────────────────
EXPECTED_AGENT_COUNT = 30
EXPECTED_ACTIVE_AGENTS = 25
EXPECTED_DORMANT_AGENTS = 5

EXPECTED_DISTRICTS = {
    "sales": 5,
    "delivery": 5,
    "operations": 5,
    "learning": 2,
    "evolution": 5,
    "self_awareness": 3,
    "enterprise": 5,
}

CORRECT_PRICING = {
    "simple_website": 332,
    "landing_page": 265,
    "ecommerce": 1330,
    "logo_brand": 130,
    "ai_chatbot": 398,
    "hosting_monthly": 52,
    "social_media_monthly": 130,
}

REQUIRED_ENV_VARS = [
    "POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB",
    "OLLAMA_HOST", "OLLAMA_MODEL", "OLLAMA_SECONDARY", "OLLAMA_EMBED",
    "OPENAI_BASE_URL", "OPENAI_API_KEY", "LLM_MODEL",
    "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
    "SMARTLEAD_API_KEY",
    "WISE_API_TOKEN", "WISE_PROFILE_ID",
    "NETLIFY_AUTH_TOKEN",
    "MONTHLY_BUDGET_CAP",
]

PORT_TRUTH_TABLE = {
    "postgres": 5432,
    "qdrant": 6333,
    "mem0": 8888,
    "crewai": 8001,
    "n8n": 5678,
    "pinchtab": 9867,
    "ollama": 11434,
}


# ═══════════════════════════════════════════════════════════════════
# Test: CREW_REGISTRY has all 30 agents
# ═══════════════════════════════════════════════════════════════════

class TestCrewRegistry:
    """Tests for the central CREW_REGISTRY in agents/main.py."""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Import CREW_REGISTRY from main."""
        # Set required env vars for import
        os.environ.setdefault("OPENAI_BASE_URL", "http://localhost:11434/v1")
        os.environ.setdefault("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")
        from main import CREW_REGISTRY
        self.registry = CREW_REGISTRY

    def test_total_agent_count(self):
        """CREW_REGISTRY must have exactly 30 agents."""
        assert len(self.registry) == EXPECTED_AGENT_COUNT, (
            f"Expected {EXPECTED_AGENT_COUNT} agents, got {len(self.registry)}: "
            f"{list(self.registry.keys())}"
        )

    def test_active_agent_count(self):
        """25 agents must be active (non-dormant)."""
        active = sum(1 for v in self.registry.values() if not v.get("dormant"))
        assert active == EXPECTED_ACTIVE_AGENTS, f"Expected {EXPECTED_ACTIVE_AGENTS} active, got {active}"

    def test_dormant_agent_count(self):
        """5 enterprise agents must be dormant."""
        dormant = sum(1 for v in self.registry.values() if v.get("dormant"))
        assert dormant == EXPECTED_DORMANT_AGENTS, f"Expected {EXPECTED_DORMANT_AGENTS} dormant, got {dormant}"

    def test_district_agent_counts(self):
        """Each district must have the correct number of agents."""
        districts = {}
        for config in self.registry.values():
            d = config["district"]
            districts[d] = districts.get(d, 0) + 1

        for district, expected_count in EXPECTED_DISTRICTS.items():
            actual = districts.get(district, 0)
            assert actual == expected_count, (
                f"District '{district}' has {actual} agents, expected {expected_count}"
            )

    def test_all_agents_have_required_fields(self):
        """Every agent must have module, function, district, description."""
        required_fields = ["module", "function", "district", "description"]
        for name, config in self.registry.items():
            for field in required_fields:
                assert field in config, f"Agent '{name}' missing field '{field}'"

    def test_dormant_agents_have_activation_gate(self):
        """Every dormant agent must specify an activation gate."""
        for name, config in self.registry.items():
            if config.get("dormant"):
                assert "activation_gate" in config, (
                    f"Dormant agent '{name}' missing activation_gate"
                )
                assert "$8000" in config["activation_gate"], (
                    f"Dormant agent '{name}' activation gate doesn't reference $8000 MRR"
                )

    def test_no_hermes_in_registry(self):
        """Hermes must NOT be in CREW_REGISTRY — it's an external install."""
        for name in self.registry:
            assert "hermes" not in name.lower(), (
                f"Found 'hermes' in agent name: {name}. "
                "Hermes is NOT a PERSEUS agent — install via official script."
            )

    def test_enterprise_agents_are_dormant(self):
        """All enterprise district agents must be dormant."""
        for name, config in self.registry.items():
            if config["district"] == "enterprise":
                assert config.get("dormant") is True, (
                    f"Enterprise agent '{name}' is not dormant!"
                )


# ═══════════════════════════════════════════════════════════════════
# Test: Config YAML files
# ═══════════════════════════════════════════════════════════════════

class TestConfigYAML:
    """Tests for agents/config/ YAML files."""

    CONFIG_DIR = os.path.join(os.path.dirname(__file__), "..", "agents", "config")

    def _load_yaml(self, filename):
        path = os.path.join(self.CONFIG_DIR, filename)
        if not os.path.exists(path):
            pytest.skip(f"{filename} not found")
        with open(path) as f:
            return yaml.safe_load(f)

    def test_core_agents_yaml_exists(self):
        """core_agents.yaml must exist."""
        path = os.path.join(self.CONFIG_DIR, "core_agents.yaml")
        assert os.path.exists(path), "core_agents.yaml missing"

    def test_core_agents_count(self):
        """core_agents.yaml must define all 30 agents."""
        data = self._load_yaml("core_agents.yaml")
        if data and "agents" in data:
            assert len(data["agents"]) >= EXPECTED_AGENT_COUNT

    def test_core_tasks_yaml_exists(self):
        """core_tasks.yaml must exist."""
        path = os.path.join(self.CONFIG_DIR, "core_tasks.yaml")
        assert os.path.exists(path), "core_tasks.yaml missing"

    def test_schedules_yaml_exists(self):
        """schedules.yaml must exist."""
        path = os.path.join(self.CONFIG_DIR, "schedules.yaml")
        assert os.path.exists(path), "schedules.yaml missing"


# ═══════════════════════════════════════════════════════════════════
# Test: Pricing constants
# ═══════════════════════════════════════════════════════════════════

class TestPricing:
    """Verify all pricing matches the non-negotiable spec."""

    def test_email_crew_pricing(self):
        """email_crew.py must have correct PRICING dict."""
        from crews.email_crew import PRICING
        for service, expected_price in CORRECT_PRICING.items():
            assert PRICING.get(service) == expected_price, (
                f"email_crew PRICING['{service}'] = {PRICING.get(service)}, expected {expected_price}"
            )

    def test_no_old_pricing_in_codebase(self):
        """No file should contain the old $500-750 or $49/mo pricing."""
        project_root = os.path.join(os.path.dirname(__file__), "..")
        old_prices = ["$500-750", "$49/mo", "$149/mo"]

        for root, dirs, files in os.walk(project_root):
            # Skip .git, __pycache__, logs, backups
            dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "logs", "backups", "node_modules"}]
            for fname in files:
                if not fname.endswith((".py", ".md", ".yaml", ".yml", ".sh", ".json")):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath) as f:
                        content = f.read()
                    for old_price in old_prices:
                        assert old_price not in content, (
                            f"Old pricing '{old_price}' found in {fpath}"
                        )
                except (UnicodeDecodeError, PermissionError):
                    continue


# ═══════════════════════════════════════════════════════════════════
# Test: No Hermes violations
# ═══════════════════════════════════════════════════════════════════

class TestHermesGuardrails:
    """Ensure PERSEUS never builds/creates/installs Hermes itself."""

    HERMES_INSTALL_CMD = "curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash"

    def test_no_hermes_dockerfile(self):
        """No Dockerfile should build Hermes."""
        project_root = os.path.join(os.path.dirname(__file__), "..")
        for root, dirs, files in os.walk(project_root):
            dirs[:] = [d for d in dirs if d not in {".git", "__pycache__"}]
            for fname in files:
                if "dockerfile" in fname.lower():
                    fpath = os.path.join(root, fname)
                    with open(fpath) as f:
                        content = f.read().lower()
                    assert "hermes" not in content or "nous" not in content, (
                        f"Dockerfile {fpath} may be building Hermes — "
                        "Hermes must be installed via official script only"
                    )

    def test_titan_builder_doesnt_build_hermes(self):
        """titan_builder/planner.py must not create Hermes."""
        planner_path = os.path.join(
            os.path.dirname(__file__), "..", "titan_builder", "planner.py"
        )
        if not os.path.exists(planner_path):
            pytest.skip("planner.py not found")
        with open(planner_path) as f:
            content = f.read()
        # Should reference hermes only in comments/warnings, not in build logic
        lines = content.split("\n")
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'"):
                continue
            # Active code lines should not contain hermes build logic
            if "hermes" in stripped.lower() and "build" in stripped.lower():
                if "not" not in stripped.lower() and "warning" not in stripped.lower():
                    pytest.fail(
                        f"planner.py line {i+1} may build Hermes: {stripped}"
                    )


# ═══════════════════════════════════════════════════════════════════
# Test: .env.example completeness
# ═══════════════════════════════════════════════════════════════════

class TestEnvExample:
    """Verify .env.example has all required variables."""

    def test_all_required_vars_present(self):
        """Every required env var must appear in .env.example."""
        env_path = os.path.join(os.path.dirname(__file__), "..", ".env.example")
        assert os.path.exists(env_path), ".env.example missing"

        with open(env_path) as f:
            content = f.read()

        for var in REQUIRED_ENV_VARS:
            assert var in content, f"Missing env var in .env.example: {var}"

    def test_no_crypto_references(self):
        """.env.example must not reference crypto/USDC/stablecoins."""
        env_path = os.path.join(os.path.dirname(__file__), "..", ".env.example")
        with open(env_path) as f:
            content = f.read().lower()

        banned = ["usdc", "crypto", "stablecoin", "ethereum", "solana", "bitcoin", "wallet_address"]
        for term in banned:
            assert term not in content, f"Banned term '{term}' found in .env.example"


# ═══════════════════════════════════════════════════════════════════
# Test: Budget constraints
# ═══════════════════════════════════════════════════════════════════

class TestBudgetConstraints:
    """Verify budget enforcement constants."""

    def test_monthly_budget_cap(self):
        """Monthly budget must be $600."""
        os.environ.setdefault("MONTHLY_BUDGET_CAP", "600")
        assert int(os.environ["MONTHLY_BUDGET_CAP"]) == 600

    def test_cloud_gpu_cap(self):
        """Cloud GPU budget must be $500."""
        os.environ.setdefault("CLOUD_GPU_BUDGET_CAP", "500")
        assert int(os.environ["CLOUD_GPU_BUDGET_CAP"]) == 500

    def test_enterprise_mrr_gate(self):
        """Enterprise gate must be $8,000 MRR."""
        os.environ.setdefault("ENTERPRISE_MRR_GATE", "8000")
        assert int(os.environ["ENTERPRISE_MRR_GATE"]) == 8000


# ═══════════════════════════════════════════════════════════════════
# Test: Crew module imports (smoke test)
# ═══════════════════════════════════════════════════════════════════

class TestCrewImports:
    """Verify all crew modules can be imported without error."""

    @pytest.fixture(autouse=True)
    def setup(self):
        os.environ.setdefault("OPENAI_BASE_URL", "http://localhost:11434/v1")
        os.environ.setdefault("LLM_MODEL", "qwen2.5:14b-instruct-q4_K_M")

    def test_import_sales_crew(self):
        from crews.sales_crew import run_lead_gen, run_cold_outreach, run_proposal_writer

    def test_import_site_builder_crew(self):
        from crews.site_builder_crew import run_site_planner, run_code_generator, run_qa_reviewer

    def test_import_email_crew(self):
        from crews.email_crew import run_email_router, run_invoice_manager

    def test_import_nightly_review_crew(self):
        from crews.nightly_review_crew import run_nightly_reviewer, run_budget_sentinel

    def test_import_client_onboard_crew(self):
        from crews.client_onboard_crew import run_client_onboarder

    def test_import_learning_crew(self):
        from crews.learning_crew import run_reflection_engine, run_prompt_optimizer

    def test_import_evolution_crew(self):
        from crews.evolution_crew import run_ab_tester, run_template_evolver

    def test_import_self_awareness_crew(self):
        from crews.self_awareness_crew import run_code_auditor, run_env_validator

    def test_import_enterprise_crew(self):
        from crews.enterprise_crew import (
            run_enterprise_account_manager,
            run_enterprise_custom_builder,
            run_enterprise_sla_monitor,
            run_enterprise_analytics,
            run_enterprise_integrations,
        )

    def test_enterprise_agents_return_dormant(self):
        """Enterprise agent functions must return dormant status."""
        from crews.enterprise_crew import run_enterprise_account_manager
        result = run_enterprise_account_manager()
        assert result["status"] == "dormant"
        assert "enterprise" in result["district"]
