# PERSEUS V17 — COMMAND & PROMPT REFERENCE

Every command you need on Day 0 and beyond. Copy-paste ready. No thinking required.

---

## PHASE 1: PREREQUISITES (Copy-paste into Terminal)

### Install Homebrew
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Install Essentials
```bash
brew install git jq python3
```

### Install Docker Desktop
```bash
brew install --cask docker
```
Then open Docker Desktop → Settings → Resources → Memory: **6 GB** → Apply & Restart.

### Install Vast.ai CLI (for cloud GPU)
```bash
pip3 install vastai
vastai set api-key YOUR_VAST_AI_KEY
```

---

## PHASE 2: SETUP (Copy-paste in order)

### Get PERSEUS (Option A: USB)
```bash
cp -r /Volumes/USB/perseus-v17 ~/perseus-v17
cd ~/perseus-v17
```

### Get PERSEUS (Option B: GitHub)
```bash
git clone https://github.com/YOUR_USERNAME/perseus-v17.git ~/perseus-v17
cd ~/perseus-v17
```

### Run Setup Wizard
```bash
chmod +x setup-wizard.sh verify.sh backup.sh cloud/cloud_prime.sh
./setup-wizard.sh
```

### Verify Everything
```bash
./verify.sh
```

---

## PHASE 3: SMOKE TESTS (Copy-paste to confirm system works)

### Test Ollama
```bash
curl -s http://localhost:11434/api/tags | jq '.models[].name'
```
Expected: `qwen2.5:14b-instruct-q4_K_M`, `llama3.2:3b`, `nomic-embed-text`

### Test Ollama Inference
```bash
curl -s http://localhost:11434/api/generate -d '{
  "model": "qwen2.5:14b-instruct-q4_K_M",
  "prompt": "Write a one-sentence tagline for a plumbing company in Austin, TX.",
  "stream": false
}' | jq -r '.response'
```

### Test Docker Stack
```bash
docker compose ps
```
Expected: 6 containers, all "running" or "Up"

### Test Postgres
```bash
docker exec perseus-postgres psql -U perseus -d perseus -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';"
```

### Test Qdrant
```bash
curl -s http://localhost:6333/collections | jq .
```

### Test Mem0
```bash
curl -s http://localhost:8888/api/v1/health | jq .
```

### Test N8N
```bash
curl -s http://localhost:5678/healthz
```

### Test CrewAI — Generate a Site
```bash
curl -X POST http://localhost:8001/api/generate-site \
  -H "Content-Type: application/json" \
  -d '{
    "client_name": "Test Client",
    "business_name": "Test Plumbing Co",
    "industry": "plumber",
    "services": ["Drain cleaning", "Water heater repair", "Emergency plumbing"],
    "location": "Austin, TX",
    "phone": "512-555-0100"
  }'
```

### Test Hermes (Telegram)
Send `/status` to your PERSEUS Telegram bot.

### Test Morning Briefing
```bash
hermes run "Generate morning briefing"
```

### Quick Status
```bash
make status
```

---

## CLOUD GPU COMMANDS

### Check Available GPUs
```bash
vastai search offers 'gpu_name=A100_SXM4 num_gpus>=4 dph<=1.50 reliability>0.95' --order dph --limit 5
```

### Run Phase 1 — Heavy Bootstrap
```bash
cd ~/perseus-v17/cloud
./cloud_prime.sh phase1
```

### Run Phase 2 — Iterative Fine-Tuning
```bash
./cloud_prime.sh phase2
```

### Check GPU Budget
```bash
./cloud_prime.sh status
```

### Pull Results from GPU Instance
```bash
./cloud_prime.sh sync
```

### Kill All GPU Instances
```bash
./cloud_prime.sh teardown
```

### Load Custom Model into Ollama
```bash
cp ~/perseus-cloud-results/perseus-7b.gguf ~/
cat > ~/Modelfile << 'EOF'
FROM ./perseus-7b.gguf
PARAMETER temperature 0.7
PARAMETER num_ctx 2048
PARAMETER top_p 0.9
PARAMETER repeat_penalty 1.1
SYSTEM "You are Perseus, an AI website builder for small businesses. You generate production-ready HTML/CSS/JS websites, write cold outreach emails, manage client relationships, and monitor business operations. You are direct, efficient, and quality-obsessed."
EOF
cd ~ && ollama create perseus-7b -f Modelfile
```

### Test Custom Model
```bash
ollama run perseus-7b "Generate a homepage hero section for Mario's Plumbing in Phoenix, AZ. Services: drain cleaning, water heater repair, emergency plumbing. Phone: (602) 555-0100."
```

---

## DAILY OPERATIONS

### Morning Check
```bash
make status
```

### Start Everything
```bash
docker compose up -d
ollama serve &
```

### Stop Everything
```bash
docker compose down
```

### View Logs
```bash
make logs
# Or specific service:
docker compose logs -f crewai
docker compose logs -f n8n
```

### Manual Backup
```bash
./backup.sh
```

### Check Budget
```bash
hermes run "Calculate current month spending against $600 budget"
```

### Check Pipeline
```bash
hermes run "Show sales pipeline status: leads → prospects → proposals → signed → building → delivered → hosting"
```

---

## HERMES TELEGRAM COMMANDS

| Command | What It Does |
|---------|-------------|
| `/status` | System health: containers, Ollama, disk, RAM |
| `/briefing` | Morning briefing: pipeline, MRR, priorities |
| `/pipeline` | Sales pipeline breakdown |
| `/budget` | Current month spending vs $600 cap |
| `/site plumber "Business Name" "Location"` | Quick site generation |
| `/warmup` | Domain warm-up progress |
| `/uptime` | Client site uptime report |
| `/backup` | Trigger manual backup |

---

## EMERGENCY COMMANDS

### Restart Docker Stack
```bash
docker compose down && docker compose up -d
```

### Restart Ollama
```bash
pkill ollama
ollama serve &
```

### Restart Hermes
```bash
pkill hermes
source ~/.hermes/config.env
hermes serve &
```

### Check RAM Usage
```bash
top -l 1 | head -20
docker stats --no-stream
```

### Fix Database Connection
```bash
docker restart perseus-postgres
sleep 5
docker exec perseus-postgres psql -U perseus -d perseus -c "SELECT 1;"
```

### Nuclear Option — Full Reset
```bash
docker compose down -v  # WARNING: destroys all data
docker compose up -d
./setup-wizard.sh       # Re-run wizard
```

---

## SMARTLEAD EMAIL TEMPLATES

### Plumber Email #1
```
Subject: Quick thought about [BUSINESS_NAME]'s website

Hi [OWNER_NAME],

I was looking at plumbing services in [CITY] and came across [BUSINESS_NAME].
Noticed your current site might not be showing up as well as it could in local
searches.

We build websites specifically for plumbers — fast, mobile-friendly, designed
to show up in Google and get the phone ringing. Most of our plumber clients
see 30-40% more calls within 60 days.

Would a 10-minute call this week work?

Best,
Nico
```

### Dentist Email #1
```
Subject: Thought about [PRACTICE_NAME]'s online presence

Hi [DR_NAME],

I was researching dental practices in [CITY] and found [PRACTICE_NAME].
Your practice clearly does great work — but your website might not be
doing it justice.

We build modern, patient-friendly websites specifically for dental practices.
Online booking, before/after galleries, Google-optimized. Most practices we
work with see a noticeable bump in new patient inquiries.

Would a quick chat make sense?

Best,
Nico
```

### Restaurant Email #1
```
Subject: Idea for [RESTAURANT_NAME]'s website

Hi [OWNER_NAME],

I stumbled on [RESTAURANT_NAME] while looking for great food in [NEIGHBORHOOD].
Your menu looks amazing — but your website could be working harder for you.

We build restaurant websites that actually drive reservations and orders.
Updated menus, online ordering, gorgeous food photography, mobile-first.
Most restaurant owners we work with tell us they wish they'd done it sooner.

Interested in a quick 10-minute chat?

Best,
Nico
```

---

*PERSEUS V17 — Every command in one place.*
*Print this. Keep it next to the Mac Studio.*
