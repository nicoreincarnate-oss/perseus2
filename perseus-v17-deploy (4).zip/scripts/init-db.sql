-- PERSEUS V17 Database Schema
-- Auto-loaded on first Postgres container start

CREATE TABLE IF NOT EXISTS clients (
    id SERIAL PRIMARY KEY,
    business_name VARCHAR(255) NOT NULL,
    contact_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    industry VARCHAR(100),
    website_url VARCHAR(500),
    status VARCHAR(50) DEFAULT 'lead',
    source_campaign VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS deals (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    product VARCHAR(50) NOT NULL CHECK (product IN ('website', 'hosting', 'receptionist')),
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'refunded', 'cancelled')),
    paid_at TIMESTAMP,
    wise_reference VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hosting_subscriptions (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    domain VARCHAR(255),
    netlify_site_id VARCHAR(255),
    monthly_price DECIMAL(10,2) DEFAULT 49.00,
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'cancelled')),
    next_billing_date DATE,
    cancelled_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS receptionist_subscriptions (
    id SERIAL PRIMARY KEY,
    client_id INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    goodcall_agent_id VARCHAR(255),
    monthly_price DECIMAL(10,2) DEFAULT 149.00,
    goodcall_cost DECIMAL(10,2) DEFAULT 79.00,
    status VARCHAR(50) DEFAULT 'trial' CHECK (status IN ('trial', 'active', 'paused', 'cancelled')),
    trial_start DATE,
    trial_end DATE,
    next_billing_date DATE,
    cancelled_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS outreach_metrics (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    domain VARCHAR(255) NOT NULL,
    campaign VARCHAR(255),
    emails_sent INTEGER DEFAULT 0,
    opens INTEGER DEFAULT 0,
    replies INTEGER DEFAULT 0,
    bounces INTEGER DEFAULT 0,
    spam_complaints INTEGER DEFAULT 0,
    interested_replies INTEGER DEFAULT 0,
    unsubscribes INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, domain, campaign)
);

CREATE TABLE IF NOT EXISTS budget_tracking (
    id SERIAL PRIMARY KEY,
    month DATE NOT NULL,
    category VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    receipt_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS site_health (
    id SERIAL PRIMARY KEY,
    hosting_id INTEGER REFERENCES hosting_subscriptions(id) ON DELETE CASCADE,
    checked_at TIMESTAMP DEFAULT NOW(),
    http_status INTEGER,
    response_time_ms INTEGER,
    ssl_valid BOOLEAN DEFAULT true,
    ssl_expiry DATE,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS activity_log (
    id SERIAL PRIMARY KEY,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INTEGER,
    action VARCHAR(100) NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status);
CREATE INDEX IF NOT EXISTS idx_clients_industry ON clients(industry);
CREATE INDEX IF NOT EXISTS idx_clients_email ON clients(email);
CREATE INDEX IF NOT EXISTS idx_deals_client ON deals(client_id);
CREATE INDEX IF NOT EXISTS idx_deals_status ON deals(status);
CREATE INDEX IF NOT EXISTS idx_deals_paid ON deals(paid_at);
CREATE INDEX IF NOT EXISTS idx_outreach_date ON outreach_metrics(date);
CREATE INDEX IF NOT EXISTS idx_outreach_domain ON outreach_metrics(domain);
CREATE INDEX IF NOT EXISTS idx_budget_month ON budget_tracking(month);
CREATE INDEX IF NOT EXISTS idx_budget_category ON budget_tracking(category);
CREATE INDEX IF NOT EXISTS idx_site_health_hosting ON site_health(hosting_id);
CREATE INDEX IF NOT EXISTS idx_site_health_checked ON site_health(checked_at);
CREATE INDEX IF NOT EXISTS idx_activity_entity ON activity_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at);

-- Functions
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_clients_updated
    BEFORE UPDATE ON clients
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Views
CREATE OR REPLACE VIEW v_active_mrr AS
SELECT
    COALESCE(SUM(CASE WHEN h.status = 'active' THEN h.monthly_price ELSE 0 END), 0) AS hosting_mrr,
    COALESCE(SUM(CASE WHEN r.status = 'active' THEN r.monthly_price ELSE 0 END), 0) AS receptionist_mrr,
    COALESCE(SUM(CASE WHEN h.status = 'active' THEN h.monthly_price ELSE 0 END), 0) +
    COALESCE(SUM(CASE WHEN r.status = 'active' THEN r.monthly_price ELSE 0 END), 0) AS total_mrr
FROM hosting_subscriptions h
FULL OUTER JOIN receptionist_subscriptions r ON true;

CREATE OR REPLACE VIEW v_monthly_budget AS
SELECT
    month,
    SUM(amount) AS total_spent,
    600.00 - SUM(amount) AS remaining,
    ROUND(SUM(amount) / 600.00 * 100, 1) AS percent_used
FROM budget_tracking
GROUP BY month
ORDER BY month DESC;

CREATE OR REPLACE VIEW v_domain_health AS
SELECT
    domain,
    date,
    emails_sent,
    CASE WHEN emails_sent > 0 THEN ROUND(bounces::numeric / emails_sent * 100, 2) ELSE 0 END AS bounce_rate,
    CASE WHEN emails_sent > 0 THEN ROUND(opens::numeric / emails_sent * 100, 2) ELSE 0 END AS open_rate,
    CASE WHEN opens > 0 THEN ROUND(replies::numeric / opens * 100, 2) ELSE 0 END AS reply_rate,
    CASE
        WHEN emails_sent > 0 AND bounces::numeric / emails_sent > 0.05 THEN 'CRITICAL'
        WHEN emails_sent > 0 AND bounces::numeric / emails_sent > 0.03 THEN 'WARNING'
        ELSE 'OK'
    END AS health_status
FROM outreach_metrics
ORDER BY date DESC, domain;
