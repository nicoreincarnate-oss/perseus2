#!/bin/bash
set -euo pipefail

# ─── PERSEUS V17 Daily Backup Script ─────────────────────────────────
# Run via cron at 2:00 AM daily

BACKUP_DIR="$HOME/backups"
DATE=$(date +%Y-%m-%d)
RETENTION_DAYS=30

mkdir -p "$BACKUP_DIR/postgres" "$BACKUP_DIR/qdrant" "$BACKUP_DIR/hermes" "$BACKUP_DIR/n8n"

echo "[$(date)] Starting daily backup..."

# 1. Postgres (includes Mem0 relational data)
echo "  Backing up Postgres..."
docker exec perseus-postgres pg_dump -U perseus -F c -f /tmp/backup.dump perseus 2>/dev/null
docker cp perseus-postgres:/tmp/backup.dump "$BACKUP_DIR/postgres/postgres-$DATE.dump"
docker exec perseus-postgres rm /tmp/backup.dump
echo "  Postgres backup: $BACKUP_DIR/postgres/postgres-$DATE.dump"

# 2. Qdrant snapshot
echo "  Backing up Qdrant..."
curl -sf -X POST http://localhost:6333/collections/perseus_memories/snapshots >/dev/null 2>&1 || true
SNAPSHOT=$(curl -sf http://localhost:6333/collections/perseus_memories/snapshots 2>/dev/null | jq -r '.result[-1].name // empty' || echo "")
if [ -n "$SNAPSHOT" ]; then
    curl -sf -o "$BACKUP_DIR/qdrant/qdrant-$DATE.snapshot" \
        "http://localhost:6333/collections/perseus_memories/snapshots/$SNAPSHOT" || true
    echo "  Qdrant backup: $BACKUP_DIR/qdrant/qdrant-$DATE.snapshot"
else
    echo "  Qdrant: no snapshots available (collection may not exist yet)"
fi

# 3. Hermes directory
echo "  Backing up Hermes..."
if [ -d "$HOME/.hermes" ]; then
    rsync -a "$HOME/.hermes/" "$BACKUP_DIR/hermes/hermes-$DATE/"
    echo "  Hermes backup: $BACKUP_DIR/hermes/hermes-$DATE/"
else
    echo "  Hermes: ~/.hermes not found (not installed yet)"
fi

# 4. Cleanup old backups
echo "  Cleaning up backups older than $RETENTION_DAYS days..."
find "$BACKUP_DIR" -type f -mtime +$RETENTION_DAYS -delete 2>/dev/null || true
find "$BACKUP_DIR" -type d -empty -delete 2>/dev/null || true

echo "[$(date)] Daily backup completed."
