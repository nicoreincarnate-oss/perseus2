#!/bin/bash
set -euo pipefail

# ─── PERSEUS Cloud GPU Bootstrap — cloud_prime.sh ────────────────────
# Phase 1: Rent multi-GPU instance, generate synthetic data, fine-tune
# Run this BEFORE or ON arrival day (Mac Studio not required)
#
# Prerequisites: vastai CLI installed, funded account ($500 budget)
#   pip install vastai
#   vastai set api-key <YOUR_KEY>
#
# Usage: ./cloud_prime.sh [phase1|phase2|phase3|status|teardown]
# ──────────────────────────────────────────────────────────────────────

BOLD='\033[1m'
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# ─── Budget Controls ─────────────────────────────────────────────────
BUDGET_HARD_CAP=500          # Absolute maximum spend (USD)
PHASE1_MAX_HOURS=48          # Kill phase 1 after this many hours
PHASE2_MAX_HOURS=72          # Kill phase 2 after this many hours
INSTANCE_KILL_TIMER=4        # Kill any single instance after 4 hours
BUDGET_FILE="$HOME/.perseus/gpu_budget.json"
STATE_FILE="$HOME/.perseus/cloud_state.json"

# ─── Configuration ───────────────────────────────────────────────────
WORK_DIR="/workspace/perseus"
RESULTS_DIR="$HOME/perseus-cloud-results"
LOGFILE="$HOME/perseus-cloud.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOGFILE"; }
info() { echo -e "${CYAN}[INFO]${NC} $*"; log "INFO: $*"; }
ok() { echo -e "${GREEN}[  OK]${NC} $*"; log "OK: $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; log "WARN: $*"; }
fail() { echo -e "${RED}[FAIL]${NC} $*"; log "FAIL: $*"; }

# ─── Budget Guard ────────────────────────────────────────────────────
init_budget() {
    mkdir -p "$HOME/.perseus"
    mkdir -p "$RESULTS_DIR"
    if [ ! -f "$BUDGET_FILE" ]; then
        cat > "$BUDGET_FILE" << 'EOF'
{
  "hard_cap": 500,
  "spent": 0.00,
  "sessions": [],
  "created": "",
  "last_check": ""
}
EOF
        # Set created timestamp
        local ts=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
        if command -v jq &>/dev/null; then
            jq --arg ts "$ts" '.created = $ts | .last_check = $ts' "$BUDGET_FILE" > /tmp/budget_tmp.json && mv /tmp/budget_tmp.json "$BUDGET_FILE"
        fi
    fi
    ok "Budget tracker initialized (cap: \$${BUDGET_HARD_CAP})"
}

check_budget() {
    local cost_estimate="${1:-0}"
    if [ ! -f "$BUDGET_FILE" ]; then
        init_budget
    fi
    local spent=$(jq '.spent' "$BUDGET_FILE" 2>/dev/null || echo "0")
    local remaining=$(echo "$BUDGET_HARD_CAP - $spent" | bc)
    local would_exceed=$(echo "$spent + $cost_estimate > $BUDGET_HARD_CAP" | bc)

    if [ "$would_exceed" -eq 1 ]; then
        fail "BUDGET GUARD: This would exceed \$${BUDGET_HARD_CAP} cap!"
        fail "  Spent so far: \$${spent}"
        fail "  Estimated cost: \$${cost_estimate}"
        fail "  Remaining budget: \$${remaining}"
        return 1
    fi

    info "Budget: \$${spent} spent / \$${remaining} remaining"
    return 0
}

record_spend() {
    local amount="$1"
    local description="$2"
    local ts=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
    if command -v jq &>/dev/null; then
        jq --arg amt "$amount" --arg desc "$description" --arg ts "$ts" \
           '.spent = (.spent + ($amt | tonumber)) | .sessions += [{"amount": ($amt | tonumber), "description": $desc, "timestamp": $ts}] | .last_check = $ts' \
           "$BUDGET_FILE" > /tmp/budget_tmp.json && mv /tmp/budget_tmp.json "$BUDGET_FILE"
    fi
    info "Recorded spend: \$${amount} — ${description}"
}

# ─── Instance Management ─────────────────────────────────────────────
find_instance() {
    local gpu_count="$1"
    local gpu_model="${2:-A100_SXM4}"
    local max_price="${3:-1.50}"

    info "Searching Vast.ai for ${gpu_count}x ${gpu_model} at ≤\$${max_price}/GPU/hr..."

    # Search for instances matching criteria
    vastai search offers \
        "gpu_name=${gpu_model} num_gpus>=${gpu_count} dph<=${max_price} inet_down>500 disk_space>100 reliability>0.95" \
        --order "dph" \
        --limit 5 \
        --raw 2>/dev/null || {
        warn "Vast.ai search failed — check CLI installation and API key"
        return 1
    }
}

rent_instance() {
    local offer_id="$1"
    local image="${2:-pytorch/pytorch:2.2.0-cuda12.1-cudnn8-devel}"
    local disk="${3:-150}"
    local label="${4:-perseus-bootstrap}"

    info "Renting instance ${offer_id} with ${disk}GB disk..."

    local instance_id
    instance_id=$(vastai create instance "$offer_id" \
        --image "$image" \
        --disk "$disk" \
        --label "$label" \
        --onstart-cmd "apt-get update && apt-get install -y rsync tmux htop" \
        --raw 2>/dev/null | jq -r '.new_contract')

    if [ -z "$instance_id" ] || [ "$instance_id" = "null" ]; then
        fail "Failed to create instance"
        return 1
    fi

    ok "Instance created: $instance_id"

    # Save state
    cat > "$STATE_FILE" << EOF
{
  "instance_id": "$instance_id",
  "offer_id": "$offer_id",
  "label": "$label",
  "started": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "kill_at": "$(date -u -d "+${INSTANCE_KILL_TIMER} hours" '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date -u -v+${INSTANCE_KILL_TIMER}H '+%Y-%m-%dT%H:%M:%SZ')"
}
EOF

    # Start kill timer in background
    (
        sleep $((INSTANCE_KILL_TIMER * 3600))
        warn "KILL TIMER: ${INSTANCE_KILL_TIMER}hr limit reached — destroying instance ${instance_id}"
        vastai destroy instance "$instance_id" 2>/dev/null
        record_spend "$(echo "${INSTANCE_KILL_TIMER} * ${max_price:-1.50}" | bc)" "Auto-killed instance ${instance_id}"
    ) &
    local kill_pid=$!
    echo "$kill_pid" > "$HOME/.perseus/kill_timer.pid"

    echo "$instance_id"
}

wait_for_instance() {
    local instance_id="$1"
    local max_wait=300  # 5 minutes

    info "Waiting for instance ${instance_id} to be ready..."
    local elapsed=0
    while [ $elapsed -lt $max_wait ]; do
        local status
        status=$(vastai show instance "$instance_id" --raw 2>/dev/null | jq -r '.actual_status' 2>/dev/null || echo "unknown")
        if [ "$status" = "running" ]; then
            ok "Instance is running"
            return 0
        fi
        sleep 10
        elapsed=$((elapsed + 10))
        info "  Status: ${status} (${elapsed}s elapsed)"
    done

    fail "Instance did not start within ${max_wait}s"
    return 1
}

get_ssh_command() {
    local instance_id="$1"
    vastai ssh-url "$instance_id" 2>/dev/null
}

# ─── Phase 1: Heavy Bootstrap (48hrs, multi-GPU) ─────────────────────
phase1() {
    echo -e "${BOLD}"
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║    PERSEUS CLOUD PRIME — Phase 1: Heavy Bootstrap       ║"
    echo "║    Target: 3-4× A100 80GB  |  Budget: \$500 max         ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    init_budget

    # Estimate Phase 1 cost: 4x A100 @ $0.86/hr × 4hr sessions × ~8 sessions = ~$110
    local estimated_cost=120
    check_budget "$estimated_cost" || exit 1

    info "Phase 1 generates:"
    info "  • 500K synthetic training examples"
    info "  • Fine-tuned 7B GGUF model for local inference"
    info "  • Full agent scaffolding + prompt library"
    info "  • Mem0/Qdrant bootstrap data"
    echo ""

    # Step 1: Find best deal
    info "Step 1: Finding optimal GPU instance..."
    find_instance 4 "A100_SXM4" "1.50"

    echo ""
    read -rp "Enter offer ID to rent (or 'skip' to use existing instance): " OFFER_ID

    if [ "$OFFER_ID" = "skip" ]; then
        read -rp "Enter existing instance ID: " INSTANCE_ID
    else
        INSTANCE_ID=$(rent_instance "$OFFER_ID" "pytorch/pytorch:2.2.0-cuda12.1-cudnn8-devel" 200 "perseus-phase1")
        wait_for_instance "$INSTANCE_ID"
    fi

    # Step 2: Upload bootstrap payload
    info "Step 2: Uploading bootstrap payload..."
    local ssh_url
    ssh_url=$(get_ssh_command "$INSTANCE_ID")

    # SCP the generation scripts
    info "  Copying generate_agents.py and training configs..."
    scp -o StrictHostKeyChecking=no \
        "$(dirname "$0")/generate_agents.py" \
        "$(dirname "$0")/training_config.yaml" \
        "$(dirname "$0")/synthetic_data_gen.py" \
        "${ssh_url}:/workspace/" 2>/dev/null || {
        warn "SCP failed — you may need to copy files manually"
        info "SSH into: $ssh_url"
    }

    # Step 3: Run the heavy jobs
    info "Step 3: Starting GPU workloads..."
    echo ""
    echo -e "${BOLD}Run these commands on the GPU instance:${NC}"
    echo ""
    echo "  # 1. Generate synthetic training data"
    echo "  cd /workspace && python synthetic_data_gen.py --output-dir ./training_data --examples 500000"
    echo ""
    echo "  # 2. Fine-tune 7B model with LoRA"
    echo "  python generate_agents.py --mode finetune --base-model meta-llama/Llama-3.2-7B --data ./training_data --output ./perseus-7b-lora"
    echo ""
    echo "  # 3. Merge LoRA and convert to GGUF"
    echo "  python generate_agents.py --mode merge --lora-path ./perseus-7b-lora --output ./perseus-7b-merged"
    echo "  python generate_agents.py --mode quantize --model-path ./perseus-7b-merged --quant q4_K_M --output ./perseus-7b.gguf"
    echo ""
    echo "  # 4. Generate agent scaffolding"
    echo "  python generate_agents.py --mode scaffold --output ./agent_scaffolding"
    echo ""
    echo -e "${YELLOW}REMINDER: Instance auto-kills in ${INSTANCE_KILL_TIMER} hours.${NC}"
    echo -e "${YELLOW}Run 'cloud_prime.sh teardown' when done to save money.${NC}"
    echo ""

    ok "Phase 1 initialized. Monitor with: cloud_prime.sh status"
}

# ─── Phase 2: Iterative LoRA Fine-Tuning ─────────────────────────────
phase2() {
    echo -e "${BOLD}"
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║    PERSEUS CLOUD PRIME — Phase 2: Iterative Tuning      ║"
    echo "║    Target: 1× A100 80GB  |  4hr sessions               ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    init_budget

    # Phase 2: 1x A100 @ $0.86/hr × 4hr × ~5 sessions = ~$17
    local estimated_cost=20
    check_budget "$estimated_cost" || exit 1

    info "Phase 2: Iterative fine-tuning using real client data"
    info "  Run 4hr sessions as needed, fed by actual PERSEUS outputs"
    echo ""

    find_instance 1 "A100_SXM4" "1.00"

    echo ""
    read -rp "Enter offer ID to rent (or 'skip'): " OFFER_ID

    if [ "$OFFER_ID" != "skip" ]; then
        INSTANCE_ID=$(rent_instance "$OFFER_ID" "pytorch/pytorch:2.2.0-cuda12.1-cudnn8-devel" 100 "perseus-phase2")
        wait_for_instance "$INSTANCE_ID"
        local ssh_url
        ssh_url=$(get_ssh_command "$INSTANCE_ID")
        ok "Phase 2 instance ready: $ssh_url"
    fi

    echo ""
    echo -e "${BOLD}Phase 2 session workflow:${NC}"
    echo "  1. Export latest Mem0 + Qdrant data from Mac Studio"
    echo "  2. SCP to GPU instance"
    echo "  3. Run incremental LoRA fine-tune on real data"
    echo "  4. Convert to GGUF, SCP back to Mac Studio"
    echo "  5. Teardown instance"
    echo ""
    echo -e "${YELLOW}Budget remaining after this session: check with 'cloud_prime.sh status'${NC}"
}

# ─── Phase 3: Nightly Reflection Runs ────────────────────────────────
phase3() {
    echo -e "${BOLD}"
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║    PERSEUS CLOUD PRIME — Phase 3: Nightly Reflection    ║"
    echo "║    Target: 1× A100 80GB  |  1-2hr sessions             ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"

    init_budget
    local estimated_cost=3
    check_budget "$estimated_cost" || exit 1

    info "Phase 3: Nightly reflection runs"
    info "  Short sessions: process day's data, update model weights"
    info "  Automated via N8N workflow on Mac Studio"
    echo ""

    find_instance 1 "A100_SXM4" "1.00"

    echo ""
    echo -e "${BOLD}Automate Phase 3 via N8N:${NC}"
    echo "  1. N8N webhook triggers at 11 PM"
    echo "  2. Export Mem0 + Qdrant delta"
    echo "  3. Rent cheapest A100 via Vast.ai API"
    echo "  4. SSH → upload data → run reflection job"
    echo "  5. Download updated weights → destroy instance"
    echo "  6. Reload model in Ollama"
    echo ""
}

# ─── Status ──────────────────────────────────────────────────────────
status() {
    echo -e "${BOLD}PERSEUS Cloud GPU Status${NC}"
    echo ""

    if [ -f "$BUDGET_FILE" ]; then
        local spent=$(jq '.spent' "$BUDGET_FILE" 2>/dev/null || echo "0")
        local remaining=$(echo "$BUDGET_HARD_CAP - $spent" | bc)
        local pct=$(echo "scale=1; $spent * 100 / $BUDGET_HARD_CAP" | bc)
        echo -e "  Budget:  ${GREEN}\$${spent}${NC} spent / ${CYAN}\$${remaining}${NC} remaining (${pct}%)"

        local session_count=$(jq '.sessions | length' "$BUDGET_FILE" 2>/dev/null || echo "0")
        echo -e "  Sessions: ${session_count}"
    else
        warn "No budget file found — run a phase first"
    fi

    echo ""

    if [ -f "$STATE_FILE" ]; then
        local instance_id=$(jq -r '.instance_id' "$STATE_FILE" 2>/dev/null || echo "none")
        local label=$(jq -r '.label' "$STATE_FILE" 2>/dev/null || echo "unknown")
        local started=$(jq -r '.started' "$STATE_FILE" 2>/dev/null || echo "unknown")
        local kill_at=$(jq -r '.kill_at' "$STATE_FILE" 2>/dev/null || echo "unknown")

        echo -e "  Active Instance: ${YELLOW}${instance_id}${NC} (${label})"
        echo -e "  Started: ${started}"
        echo -e "  Kill Timer: ${kill_at}"

        # Check actual status
        local actual_status
        actual_status=$(vastai show instance "$instance_id" --raw 2>/dev/null | jq -r '.actual_status' 2>/dev/null || echo "unknown")
        echo -e "  Live Status: ${actual_status}"
    else
        info "No active instance"
    fi
}

# ─── Teardown ────────────────────────────────────────────────────────
teardown() {
    echo -e "${BOLD}Tearing down active instances...${NC}"

    if [ -f "$STATE_FILE" ]; then
        local instance_id=$(jq -r '.instance_id' "$STATE_FILE" 2>/dev/null)
        if [ -n "$instance_id" ] && [ "$instance_id" != "null" ]; then
            info "Destroying instance: ${instance_id}"
            vastai destroy instance "$instance_id" 2>/dev/null && ok "Instance destroyed" || warn "Could not destroy (may already be gone)"
            rm -f "$STATE_FILE"
        fi
    fi

    # Kill the background timer
    if [ -f "$HOME/.perseus/kill_timer.pid" ]; then
        local pid=$(cat "$HOME/.perseus/kill_timer.pid")
        kill "$pid" 2>/dev/null && info "Kill timer cancelled" || true
        rm -f "$HOME/.perseus/kill_timer.pid"
    fi

    ok "Teardown complete"
}

# ─── Sync Results Back to Mac Studio ──────────────────────────────────
sync_results() {
    local instance_id="${1:-}"
    if [ -z "$instance_id" ] && [ -f "$STATE_FILE" ]; then
        instance_id=$(jq -r '.instance_id' "$STATE_FILE" 2>/dev/null)
    fi

    if [ -z "$instance_id" ]; then
        fail "No instance ID provided or found in state"
        exit 1
    fi

    local ssh_url
    ssh_url=$(get_ssh_command "$instance_id")

    info "Syncing results from GPU instance to local..."
    mkdir -p "$RESULTS_DIR"

    rsync -avz --progress \
        "${ssh_url}:/workspace/perseus-7b.gguf" \
        "${ssh_url}:/workspace/agent_scaffolding/" \
        "${ssh_url}:/workspace/training_data/stats.json" \
        "$RESULTS_DIR/" 2>/dev/null || {
        warn "rsync failed — try manual SCP"
        echo "  scp ${ssh_url}:/workspace/perseus-7b.gguf $RESULTS_DIR/"
    }

    ok "Results synced to $RESULTS_DIR"
    ls -lh "$RESULTS_DIR/"
}

# ─── Main ────────────────────────────────────────────────────────────
case "${1:-help}" in
    phase1)  phase1 ;;
    phase2)  phase2 ;;
    phase3)  phase3 ;;
    status)  status ;;
    teardown) teardown ;;
    sync)    sync_results "${2:-}" ;;
    help|*)
        echo -e "${BOLD}PERSEUS Cloud GPU Bootstrap${NC}"
        echo ""
        echo "Usage: $0 <command>"
        echo ""
        echo "Commands:"
        echo "  phase1    — Heavy bootstrap: 4× A100, synthetic data + fine-tune (48hrs)"
        echo "  phase2    — Iterative LoRA: 1× A100, real data refinement"
        echo "  phase3    — Nightly reflection: 1× A100, short sessions"
        echo "  status    — Show budget, active instances"
        echo "  sync      — Download results from GPU instance"
        echo "  teardown  — Destroy all active instances"
        echo ""
        echo "Budget: \$${BUDGET_HARD_CAP} hard cap | ${INSTANCE_KILL_TIMER}hr auto-kill per instance"
        echo ""
        echo "Pricing (March 2026):"
        echo "  Vast.ai A100 80GB SXM: ~\$0.86/hr"
        echo "  RunPod  A100 80GB:     ~\$1.49/hr (Secure Cloud)"
        echo "  Phase 1 est. cost:     ~\$110-150 (4× A100, 8 sessions)"
        echo "  Phase 2 est. cost:     ~\$15-25  (1× A100, 5 sessions)"
        echo "  Phase 3 est. cost:     ~\$30-50  (1× A100, nightly Month 1)"
        ;;
esac
