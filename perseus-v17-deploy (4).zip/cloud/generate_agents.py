#!/usr/bin/env python3
"""
PERSEUS Cloud GPU — Agent Generator & Fine-Tuning Pipeline
============================================================
Run on rented GPU instance (A100 80GB recommended).
Modes: finetune | merge | quantize | scaffold

Usage:
    python generate_agents.py --mode finetune --base-model meta-llama/Llama-3.2-7B \
        --data ./training_data --output ./perseus-7b-lora
    python generate_agents.py --mode merge --lora-path ./perseus-7b-lora \
        --output ./perseus-7b-merged
    python generate_agents.py --mode quantize --model-path ./perseus-7b-merged \
        --quant q4_K_M --output ./perseus-7b.gguf
    python generate_agents.py --mode scaffold --output ./agent_scaffolding
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

# ─── Configuration ───────────────────────────────────────────────────

PERSEUS_AGENTS = {
    "site_builder": {
        "role": "AI Website Builder",
        "goal": "Generate complete, production-ready websites for small businesses",
        "backstory": (
            "You are a senior web developer specializing in small business websites. "
            "You build fast, mobile-first, SEO-optimized sites using clean HTML/CSS/JS. "
            "Your sites convert visitors into customers. You follow the PERSEUS template "
            "system and never use frameworks that require server-side rendering."
        ),
        "tools": ["code_generation", "template_loader", "seo_optimizer", "image_selector"],
        "model": "perseus-7b",
    },
    "email_outreach": {
        "role": "Cold Email Specialist",
        "goal": "Write personalized cold emails that get responses from small business owners",
        "backstory": (
            "You are a B2B email marketing expert who writes for small business owners. "
            "You never use corporate jargon. You write like a helpful neighbor, not a salesperson. "
            "You follow warm-up schedules religiously and track deliverability metrics."
        ),
        "tools": ["smartlead_client", "lead_enricher", "template_personalizer"],
        "model": "qwen2.5:14b-instruct-q4_K_M",
    },
    "client_manager": {
        "role": "Client Relationship Manager",
        "goal": "Manage client onboarding, communication, and deliverable tracking",
        "backstory": (
            "You manage the full client lifecycle from signed contract to ongoing hosting. "
            "You communicate clearly, set expectations, and ensure every deliverable meets "
            "the 7-stage pipeline standards. You escalate to the founder only for approval gates."
        ),
        "tools": ["mem0_client", "telegram_notifier", "invoice_generator"],
        "model": "qwen2.5:14b-instruct-q4_K_M",
    },
    "nightly_reviewer": {
        "role": "Nightly Operations Reviewer",
        "goal": "Analyze daily metrics, identify issues, and prepare morning briefing",
        "backstory": (
            "You run every night at 11 PM. You pull Smartlead metrics, check domain health, "
            "verify hosted site uptime, calculate spending against budget, and generate a "
            "morning briefing. You flag anything that needs the founder's attention."
        ),
        "tools": ["metrics_collector", "site_monitor", "budget_guard", "smartlead_client"],
        "model": "llama3.2:3b",
    },
    "quality_auditor": {
        "role": "Deliverable Quality Auditor",
        "goal": "Review all generated websites and content for quality before delivery",
        "backstory": (
            "You are the last line of defense before any deliverable reaches a client. "
            "You check for broken links, missing images, SEO issues, mobile responsiveness, "
            "accessibility problems, and brand consistency. You block delivery until fixed."
        ),
        "tools": ["lighthouse_runner", "link_checker", "accessibility_checker"],
        "model": "perseus-7b",
    },
}

# ─── Training Data Categories ────────────────────────────────────────

TRAINING_CATEGORIES = {
    "website_generation": {
        "description": "HTML/CSS/JS generation for small business websites",
        "example_count": 150000,
        "format": "instruction-response pairs",
    },
    "email_writing": {
        "description": "Cold email sequences for plumbers, dentists, restaurants",
        "example_count": 100000,
        "format": "context-email pairs with personalization slots",
    },
    "client_communication": {
        "description": "Professional client messages, status updates, invoicing",
        "example_count": 75000,
        "format": "scenario-response pairs",
    },
    "code_review": {
        "description": "HTML/CSS review, bug identification, improvement suggestions",
        "example_count": 100000,
        "format": "code-review pairs",
    },
    "seo_optimization": {
        "description": "Meta tags, structured data, content optimization",
        "example_count": 75000,
        "format": "page-optimization pairs",
    },
}


def check_gpu():
    """Verify GPU availability and VRAM."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.free",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True
        )
        gpus = []
        for line in result.stdout.strip().split("\n"):
            parts = [p.strip() for p in line.split(",")]
            gpus.append({
                "name": parts[0],
                "total_mb": int(parts[1]),
                "free_mb": int(parts[2]),
            })
        print(f"  Found {len(gpus)} GPU(s):")
        total_vram = 0
        for i, gpu in enumerate(gpus):
            total_gb = gpu["total_mb"] / 1024
            free_gb = gpu["free_mb"] / 1024
            total_vram += gpu["total_mb"]
            print(f"    GPU {i}: {gpu['name']} — {total_gb:.0f}GB total, {free_gb:.0f}GB free")
        print(f"  Total VRAM: {total_vram / 1024:.0f}GB")
        return gpus
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("  WARNING: nvidia-smi not found or failed")
        return []


def install_dependencies():
    """Install required Python packages for fine-tuning."""
    packages = [
        "torch>=2.2.0",
        "transformers>=4.38.0",
        "peft>=0.8.0",
        "datasets>=2.17.0",
        "accelerate>=0.27.0",
        "bitsandbytes>=0.42.0",
        "trl>=0.7.10",
        "llama-cpp-python>=0.2.50",
        "sentencepiece",
        "protobuf",
        "wandb",
    ]
    print("  Installing fine-tuning dependencies...")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet"] + packages,
        check=True
    )
    print("  Dependencies installed.")


def mode_finetune(args):
    """Fine-tune a 7B model with LoRA on synthetic PERSEUS data."""
    print("\n═══ PERSEUS Fine-Tuning Pipeline ═══\n")

    gpus = check_gpu()
    install_dependencies()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    data_dir = Path(args.data)
    if not data_dir.exists():
        print(f"  ERROR: Training data directory not found: {data_dir}")
        print(f"  Run synthetic_data_gen.py first.")
        sys.exit(1)

    # Build training config
    config = {
        "base_model": args.base_model,
        "data_dir": str(data_dir),
        "output_dir": str(output_dir),
        "lora_r": 64,
        "lora_alpha": 128,
        "lora_dropout": 0.05,
        "target_modules": ["q_proj", "k_proj", "v_proj", "o_proj",
                           "gate_proj", "up_proj", "down_proj"],
        "per_device_train_batch_size": 4,
        "gradient_accumulation_steps": 4,
        "num_train_epochs": 3,
        "learning_rate": 2e-4,
        "warmup_ratio": 0.03,
        "lr_scheduler_type": "cosine",
        "bf16": True,
        "logging_steps": 10,
        "save_steps": 500,
        "max_seq_length": 2048,
        "gradient_checkpointing": True,
    }

    config_path = output_dir / "training_config.json"
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
    print(f"  Training config saved: {config_path}")

    # Write the actual training script
    train_script = output_dir / "run_training.py"
    with open(train_script, "w") as f:
        f.write(f'''#!/usr/bin/env python3
"""Auto-generated PERSEUS LoRA training script."""
import json
import torch
from datasets import load_dataset, concatenate_datasets
from transformers import (
    AutoModelForCausalLM, AutoTokenizer,
    BitsAndBytesConfig, TrainingArguments
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer

config = json.load(open("{config_path}"))

# Load model with 4-bit quantization for training
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)

print("Loading base model: {{}}".format(config["base_model"]))
model = AutoModelForCausalLM.from_pretrained(
    config["base_model"],
    quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
)
tokenizer = AutoTokenizer.from_pretrained(config["base_model"], trust_remote_code=True)
tokenizer.pad_token = tokenizer.eos_token

model = prepare_model_for_kbit_training(model)

# LoRA config
lora_config = LoraConfig(
    r=config["lora_r"],
    lora_alpha=config["lora_alpha"],
    lora_dropout=config["lora_dropout"],
    target_modules=config["target_modules"],
    bias="none",
    task_type="CAUSAL_LM",
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

# Load training data
print("Loading training data from: {{}}".format(config["data_dir"]))
dataset = load_dataset("json", data_dir=config["data_dir"], split="train")
print(f"  Total examples: {{len(dataset)}}")

# Training
training_args = TrainingArguments(
    output_dir=config["output_dir"],
    per_device_train_batch_size=config["per_device_train_batch_size"],
    gradient_accumulation_steps=config["gradient_accumulation_steps"],
    num_train_epochs=config["num_train_epochs"],
    learning_rate=config["learning_rate"],
    warmup_ratio=config["warmup_ratio"],
    lr_scheduler_type=config["lr_scheduler_type"],
    bf16=config["bf16"],
    logging_steps=config["logging_steps"],
    save_steps=config["save_steps"],
    save_total_limit=3,
    gradient_checkpointing=config["gradient_checkpointing"],
    report_to="wandb",
    run_name="perseus-7b-lora",
)

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=dataset,
    args=training_args,
    max_seq_length=config["max_seq_length"],
    dataset_text_field="text",
)

print("Starting training...")
trainer.train()
trainer.save_model(config["output_dir"])
print(f"LoRA adapter saved to: {{config['output_dir']}}")
''')

    print(f"\n  Training script generated: {train_script}")
    print(f"  Run: python {train_script}")
    print(f"\n  Estimated time: ~2-3 hours on 4× A100 80GB")
    print(f"  Estimated cost: ~$10-15 on Vast.ai\n")


def mode_merge(args):
    """Merge LoRA adapter with base model."""
    print("\n═══ Merging LoRA Adapter ═══\n")
    install_dependencies()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    merge_script = output_dir / "run_merge.py"
    with open(merge_script, "w") as f:
        f.write(f'''#!/usr/bin/env python3
"""Merge LoRA adapter with base model."""
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import torch

base_model_name = "meta-llama/Llama-3.2-7B"
lora_path = "{args.lora_path}"
output_path = "{args.output}"

print(f"Loading base model: {{base_model_name}}")
base_model = AutoModelForCausalLM.from_pretrained(
    base_model_name, torch_dtype=torch.bfloat16, device_map="auto"
)
tokenizer = AutoTokenizer.from_pretrained(base_model_name)

print(f"Loading LoRA adapter: {{lora_path}}")
model = PeftModel.from_pretrained(base_model, lora_path)

print("Merging weights...")
merged = model.merge_and_unload()

print(f"Saving merged model: {{output_path}}")
merged.save_pretrained(output_path)
tokenizer.save_pretrained(output_path)
print("Done!")
''')

    print(f"  Merge script generated: {merge_script}")
    print(f"  Run: python {merge_script}")


def mode_quantize(args):
    """Convert merged model to GGUF for Ollama."""
    print("\n═══ Quantizing to GGUF ═══\n")

    quant = args.quant or "q4_K_M"
    output = args.output or "./perseus-7b.gguf"

    print(f"  Model path: {args.model_path}")
    print(f"  Quantization: {quant}")
    print(f"  Output: {output}")
    print()

    # Check for llama.cpp
    if not Path("llama.cpp").exists():
        print("  Cloning llama.cpp for GGUF conversion...")
        subprocess.run(["git", "clone", "https://github.com/ggerganov/llama.cpp.git"], check=True)
        subprocess.run(["make", "-C", "llama.cpp", "-j"], check=True)

    print("  Step 1: Convert to GGUF format...")
    subprocess.run([
        "python", "llama.cpp/convert_hf_to_gguf.py",
        args.model_path,
        "--outfile", output.replace(f".gguf", "-f16.gguf"),
        "--outtype", "f16",
    ], check=True)

    print(f"  Step 2: Quantize to {quant}...")
    subprocess.run([
        "./llama.cpp/llama-quantize",
        output.replace(f".gguf", "-f16.gguf"),
        output,
        quant,
    ], check=True)

    size_gb = Path(output).stat().st_size / (1024**3) if Path(output).exists() else 0
    print(f"\n  Output: {output} ({size_gb:.1f} GB)")
    print(f"\n  To use with Ollama:")
    print(f"  1. Copy {output} to Mac Studio")
    print(f"  2. Create Modelfile:")
    print(f"     FROM ./{Path(output).name}")
    print(f"     PARAMETER temperature 0.7")
    print(f"     PARAMETER num_ctx 2048")
    print(f"     SYSTEM \"You are Perseus, an AI assistant...\"")
    print(f"  3. ollama create perseus-7b -f Modelfile")


def mode_scaffold(args):
    """Generate agent scaffolding files for the PERSEUS system."""
    print("\n═══ Generating Agent Scaffolding ═══\n")

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Generate agent config files
    for agent_name, agent_config in PERSEUS_AGENTS.items():
        agent_dir = output_dir / agent_name
        agent_dir.mkdir(parents=True, exist_ok=True)

        # Agent definition
        agent_def = {
            "name": agent_name,
            "role": agent_config["role"],
            "goal": agent_config["goal"],
            "backstory": agent_config["backstory"],
            "tools": agent_config["tools"],
            "model": agent_config["model"],
            "verbose": True,
            "allow_delegation": False,
            "max_iterations": 10,
            "created": datetime.utcnow().isoformat(),
        }
        with open(agent_dir / "agent.json", "w") as f:
            json.dump(agent_def, f, indent=2)

        # System prompt
        system_prompt = f"""You are {agent_config['role']} in the PERSEUS system.

GOAL: {agent_config['goal']}

BACKGROUND: {agent_config['backstory']}

CONSTRAINTS:
- You operate within a $600/month total budget
- You run on a Mac Studio M4 Max with 32GB RAM
- You must log all significant actions to Mem0
- You must notify the founder via Telegram for approval gates
- You never hallucinate data — if uncertain, say so
- You follow the PERSEUS soul values at all times

AVAILABLE TOOLS: {', '.join(agent_config['tools'])}
"""
        with open(agent_dir / "system_prompt.txt", "w") as f:
            f.write(system_prompt)

        print(f"  Generated: {agent_name}/")

    # Generate crew definitions
    crews_dir = output_dir / "crews"
    crews_dir.mkdir(exist_ok=True)

    crew_defs = {
        "site_builder_crew": {
            "agents": ["site_builder", "quality_auditor"],
            "tasks": ["generate_site", "review_site", "deploy_site"],
            "process": "sequential",
        },
        "outreach_crew": {
            "agents": ["email_outreach", "client_manager"],
            "tasks": ["find_leads", "write_sequence", "track_responses"],
            "process": "sequential",
        },
        "nightly_crew": {
            "agents": ["nightly_reviewer"],
            "tasks": ["collect_metrics", "check_health", "generate_briefing"],
            "process": "sequential",
        },
    }

    for crew_name, crew_config in crew_defs.items():
        with open(crews_dir / f"{crew_name}.json", "w") as f:
            json.dump(crew_config, f, indent=2)
        print(f"  Generated: crews/{crew_name}.json")

    # Generate prompt library
    prompts_dir = output_dir / "prompts"
    prompts_dir.mkdir(exist_ok=True)

    prompts = {
        "morning_briefing": "Generate the morning briefing. Include: pipeline status (leads → prospects → proposals → signed → building → delivered → hosting), current MRR, system health, domain warm-up progress, and today's top 3 priorities.",
        "site_generation": "Build a website for {business_name}, a {industry} business in {location}. Services: {services}. Phone: {phone}. Use the {industry} template. Ensure mobile-first design, <3s load time, and include structured data markup.",
        "email_sequence": "Write a 3-email cold outreach sequence for {industry} businesses in {location}. Tone: helpful neighbor, not salesperson. Include personalization slots for {business_name} and {owner_name}. Follow warm-up schedule limits.",
        "nightly_review": "Run nightly review. Pull Smartlead metrics for all active campaigns. Check domain reputation for all sending domains. Verify uptime for all hosted client sites. Calculate MTD spending against $600 budget. Flag anything above 80% threshold.",
        "client_onboard": "Onboard new client: {client_name} ({business_name}, {industry}, {location}). Create Mem0 record. Set up project tracking. Generate contract from template. Send welcome email. Schedule kickoff.",
    }

    for prompt_name, prompt_text in prompts.items():
        with open(prompts_dir / f"{prompt_name}.txt", "w") as f:
            f.write(prompt_text)
        print(f"  Generated: prompts/{prompt_name}.txt")

    # Summary
    print(f"\n  Scaffolding complete: {output_dir}/")
    print(f"  Agents: {len(PERSEUS_AGENTS)}")
    print(f"  Crews: {len(crew_defs)}")
    print(f"  Prompts: {len(prompts)}")


# ─── Main ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="PERSEUS Agent Generator & Fine-Tuning Pipeline")
    parser.add_argument("--mode", required=True,
                        choices=["finetune", "merge", "quantize", "scaffold"],
                        help="Operation mode")
    parser.add_argument("--base-model", default="meta-llama/Llama-3.2-7B",
                        help="Base model for fine-tuning")
    parser.add_argument("--data", help="Training data directory")
    parser.add_argument("--output", required=True, help="Output directory/file")
    parser.add_argument("--lora-path", help="Path to LoRA adapter (for merge)")
    parser.add_argument("--model-path", help="Path to merged model (for quantize)")
    parser.add_argument("--quant", default="q4_K_M", help="Quantization level")

    args = parser.parse_args()

    print("╔══════════════════════════════════════════════════════════╗")
    print("║       PERSEUS — Agent Generator & Training Pipeline      ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print()

    if args.mode == "finetune":
        mode_finetune(args)
    elif args.mode == "merge":
        mode_merge(args)
    elif args.mode == "quantize":
        mode_quantize(args)
    elif args.mode == "scaffold":
        mode_scaffold(args)


if __name__ == "__main__":
    main()
