#!/usr/bin/env python3
"""
PERSEUS — Synthetic Training Data Generator
=============================================
Generates 500K instruction-response training examples for fine-tuning.
Run on GPU instance with access to a frontier model (or local Qwen2.5:14b).

Categories:
  - Website generation (HTML/CSS/JS for small businesses)
  - Cold email writing (plumber/dentist/restaurant sequences)
  - Client communication (status updates, onboarding, invoicing)
  - Code review (HTML/CSS bug detection and fixes)
  - SEO optimization (meta tags, structured data, content)

Usage:
    python synthetic_data_gen.py --output-dir ./training_data --examples 500000
    python synthetic_data_gen.py --output-dir ./training_data --examples 1000 --category email_writing --dry-run
"""

import argparse
import json
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

# ─── Industry Data ───────────────────────────────────────────────────

INDUSTRIES = {
    "plumber": {
        "services": [
            "Emergency plumbing", "Drain cleaning", "Water heater repair",
            "Pipe repair", "Sewer line repair", "Toilet repair",
            "Faucet installation", "Garbage disposal repair",
            "Water softener installation", "Gas line repair",
            "Bathroom remodeling", "Kitchen plumbing",
        ],
        "pain_points": [
            "website looks outdated", "no online presence",
            "losing customers to competitors with better websites",
            "can't take online bookings", "bad Google reviews visibility",
            "no mobile-friendly site", "paying too much for current website",
        ],
        "locations": [
            "Austin, TX", "Phoenix, AZ", "Denver, CO", "Portland, OR",
            "San Antonio, TX", "Tampa, FL", "Nashville, TN", "Charlotte, NC",
            "Columbus, OH", "Indianapolis, IN", "Jacksonville, FL", "Tucson, AZ",
        ],
        "owner_names": [
            "Mike", "Dave", "Steve", "Tom", "Rick", "Joe", "Chris", "Dan",
            "Bob", "Jim", "Gary", "Mark", "Jeff", "Brian", "Scott",
        ],
    },
    "dentist": {
        "services": [
            "General dentistry", "Cosmetic dentistry", "Teeth whitening",
            "Dental implants", "Invisalign", "Root canal therapy",
            "Emergency dental care", "Pediatric dentistry",
            "Dental crowns", "Veneers", "Periodontal treatment",
            "Oral surgery", "TMJ treatment",
        ],
        "pain_points": [
            "website doesn't reflect quality of practice",
            "patients can't book online", "no patient reviews on site",
            "site loads slowly on mobile", "not showing up in local search",
            "current site was built 5+ years ago", "no before/after gallery",
        ],
        "locations": [
            "Scottsdale, AZ", "Plano, TX", "Boca Raton, FL", "Naperville, IL",
            "Bellevue, WA", "Gilbert, AZ", "Cary, NC", "Sugar Land, TX",
            "Frisco, TX", "Alpharetta, GA", "Overland Park, KS", "Lakewood, CO",
        ],
        "owner_names": [
            "Dr. Sarah", "Dr. Chen", "Dr. Patel", "Dr. Johnson", "Dr. Kim",
            "Dr. Rodriguez", "Dr. Thompson", "Dr. Lee", "Dr. Garcia",
            "Dr. Martinez", "Dr. Anderson", "Dr. Wilson",
        ],
    },
    "restaurant": {
        "services": [
            "Dine-in", "Takeout", "Catering", "Private events",
            "Online ordering", "Delivery", "Happy hour specials",
            "Brunch service", "Late night menu", "Food truck",
            "Meal prep", "Cooking classes",
        ],
        "pain_points": [
            "menu not updated online", "no online ordering",
            "photos don't show food quality", "hard to find hours",
            "no reservation system", "website doesn't match brand",
            "lost revenue from no delivery presence",
        ],
        "locations": [
            "Brooklyn, NY", "West Hollywood, CA", "Old Town Scottsdale, AZ",
            "South Congress, Austin, TX", "Pearl District, Portland, OR",
            "Wynwood, Miami, FL", "East Nashville, TN", "Logan Square, Chicago, IL",
            "Capitol Hill, Seattle, WA", "RiNo, Denver, CO",
        ],
        "owner_names": [
            "Maria", "Tony", "Chef Michael", "Rosa", "Carlos",
            "Jenny", "Marco", "Lisa", "Ahmed", "Yuki", "Sam", "Nina",
        ],
    },
}

# ─── Template Generators ─────────────────────────────────────────────

def gen_website_example(industry: str) -> dict:
    """Generate a website creation instruction-response pair."""
    data = INDUSTRIES[industry]
    services = random.sample(data["services"], min(random.randint(3, 6), len(data["services"])))
    location = random.choice(data["locations"])
    biz_name = f"{random.choice(data['owner_names'])}'s {industry.title()} {'Co' if industry == 'plumber' else 'Practice' if industry == 'dentist' else 'Kitchen'}"
    phone = f"({random.randint(200,999)}) {random.randint(200,999)}-{random.randint(1000,9999)}"

    instruction = (
        f"Build a professional website for {biz_name}, a {industry} business in {location}. "
        f"Services: {', '.join(services)}. Phone: {phone}. "
        f"The site must be mobile-first, load under 3 seconds, include structured data markup, "
        f"and have clear calls to action."
    )

    # Simplified response template (real training would have full HTML)
    response = (
        f"Here's the website structure for {biz_name}:\n\n"
        f"## Pages\n"
        f"1. **Homepage** — Hero with CTA, services overview, testimonials, contact\n"
        f"2. **Services** — Detailed page for each: {', '.join(services[:3])}\n"
        f"3. **About** — Business story, team, credentials\n"
        f"4. **Contact** — Form, map, phone ({phone}), hours\n\n"
        f"## Technical\n"
        f"- Mobile-first responsive (flexbox/grid)\n"
        f"- Structured data: LocalBusiness schema + Service schema\n"
        f"- Meta: title, description, og:image per page\n"
        f"- Performance: lazy images, minified CSS, no JS frameworks\n"
        f"- Accessibility: semantic HTML, ARIA labels, contrast AA\n"
    )

    return {"text": f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n{response}<|im_end|>",
            "category": "website_generation", "industry": industry}


def gen_email_example(industry: str) -> dict:
    """Generate a cold email instruction-response pair."""
    data = INDUSTRIES[industry]
    owner = random.choice(data["owner_names"])
    location = random.choice(data["locations"])
    pain = random.choice(data["pain_points"])
    biz_name = f"{owner}'s {industry.title()} {'Service' if industry == 'plumber' else 'Practice' if industry == 'dentist' else ''}"

    email_num = random.choice([1, 2, 3])
    instruction = (
        f"Write cold email #{email_num} of a 3-email sequence targeting {biz_name} ({industry}) "
        f"in {location}. Their main pain point: {pain}. "
        f"Tone: helpful neighbor, not salesperson. Keep under 100 words."
    )

    subjects = {
        1: f"Quick thought about {biz_name.split()[0]}'s website",
        2: f"Following up — {location} {industry}s are booking online now",
        3: f"Last note — built something for a {industry} like you",
    }

    response = (
        f"**Subject:** {subjects[email_num]}\n\n"
        f"Hi {owner},\n\n"
        f"{'I noticed ' + pain + '.' if email_num == 1 else 'Just circling back on my last email.' if email_num == 2 else 'Final follow-up — I know you are busy.'}\n\n"
        f"{'We build websites specifically for ' + industry + 's in areas like ' + location + '.' if email_num == 1 else ''}"
        f"{'Most ' + industry + 's we work with see a 30-40% increase in online bookings within 60 days.' if email_num <= 2 else ''}\n\n"
        f"Would a quick 10-minute call this week make sense?\n\n"
        f"Best,\nNico"
    )

    return {"text": f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n{response}<|im_end|>",
            "category": "email_writing", "industry": industry}


def gen_client_comm_example(industry: str) -> dict:
    """Generate a client communication example."""
    data = INDUSTRIES[industry]
    owner = random.choice(data["owner_names"])
    biz_name = f"{owner}'s {industry.title()}"

    scenarios = [
        ("project_kickoff", f"Write a project kickoff message for {owner} at {biz_name}. We just signed the contract for a simple 5-page website build at $332. Set expectations for the 7-stage delivery timeline."),
        ("progress_update", f"Write a mid-project update for {owner} at {biz_name}. We're in stage 4 (review & revisions). The site is 80% complete. One round of revisions remaining."),
        ("delivery", f"Write a delivery message for {owner} at {biz_name}. The website is live. Include instructions for reviewing, the hosting details ($52/mo), and how to request changes."),
        ("invoice", f"Write an invoice follow-up for {owner} at {biz_name}. Invoice #INV-{random.randint(100,999)} for $332 was sent 5 days ago. Payment is via Wise Business transfer. Friendly reminder tone."),
        ("upsell", f"Write a soft upsell message for {owner} at {biz_name}. They've been a hosting client for 2 months. Introduce the AI chatbot add-on ($398) with a free 14-day trial."),
    ]

    scenario_type, instruction = random.choice(scenarios)
    response = f"Hi {owner},\n\n[Professional, warm message appropriate for {scenario_type} stage]\n\nBest,\nNico\nPERSEUS"

    return {"text": f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n{response}<|im_end|>",
            "category": "client_communication", "industry": industry}


def gen_code_review_example(industry: str) -> dict:
    """Generate a code review example."""
    issues = [
        ("Missing alt text on images", "accessibility", "Add descriptive alt attributes to all img tags"),
        ("No viewport meta tag", "mobile", "Add <meta name='viewport' content='width=device-width, initial-scale=1'>"),
        ("Render-blocking CSS", "performance", "Move non-critical CSS to async loading or inline critical CSS"),
        ("Missing structured data", "seo", "Add LocalBusiness JSON-LD schema in <head>"),
        ("No lazy loading on images", "performance", "Add loading='lazy' to below-fold images"),
        ("Missing canonical URL", "seo", "Add <link rel='canonical'> to prevent duplicate content"),
        ("Low contrast text", "accessibility", "Ensure 4.5:1 contrast ratio for body text"),
        ("No 404 page", "ux", "Create a custom 404 page with navigation back to homepage"),
    ]

    issue_name, category, fix = random.choice(issues)
    instruction = f"Review this {industry} website for issues. Found: {issue_name}. Explain the problem and provide the fix."
    response = f"**Issue:** {issue_name}\n**Category:** {category}\n**Impact:** {'High' if category in ('accessibility', 'mobile') else 'Medium'}\n\n**Problem:** {issue_name} affects {'user experience for disabled users' if category == 'accessibility' else 'search rankings' if category == 'seo' else 'page load speed' if category == 'performance' else 'user experience'}.\n\n**Fix:** {fix}\n"

    return {"text": f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n{response}<|im_end|>",
            "category": "code_review", "industry": industry}


def gen_seo_example(industry: str) -> dict:
    """Generate an SEO optimization example."""
    data = INDUSTRIES[industry]
    location = random.choice(data["locations"])
    service = random.choice(data["services"])

    instruction = f"Optimize the meta tags and structured data for a {industry} website's {service} page in {location}."
    response = (
        f"**Title tag:** {service} in {location} | [Business Name]\n"
        f"**Meta description:** Professional {service.lower()} in {location}. [Unique selling point]. Call today for a free estimate.\n"
        f"**H1:** {service} in {location}\n\n"
        f"**Structured Data (JSON-LD):**\n"
        f"```json\n"
        f'{{"@context": "https://schema.org", "@type": "Service", "name": "{service}", '
        f'"provider": {{"@type": "LocalBusiness", "name": "[Business Name]", '
        f'"address": {{"@type": "PostalAddress", "addressLocality": "{location.split(",")[0]}"}}}}}}\n'
        f"```\n"
    )

    return {"text": f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n{response}<|im_end|>",
            "category": "seo_optimization", "industry": industry}


GENERATORS = {
    "website_generation": gen_website_example,
    "email_writing": gen_email_example,
    "client_communication": gen_client_comm_example,
    "code_review": gen_code_review_example,
    "seo_optimization": gen_seo_example,
}

CATEGORY_WEIGHTS = {
    "website_generation": 0.30,
    "email_writing": 0.20,
    "client_communication": 0.15,
    "code_review": 0.20,
    "seo_optimization": 0.15,
}


def main():
    parser = argparse.ArgumentParser(description="PERSEUS Synthetic Training Data Generator")
    parser.add_argument("--output-dir", required=True, help="Output directory for training data")
    parser.add_argument("--examples", type=int, default=500000, help="Number of examples to generate")
    parser.add_argument("--category", choices=list(GENERATORS.keys()), help="Generate only this category")
    parser.add_argument("--dry-run", action="store_true", help="Generate 10 samples and print them")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")

    args = parser.parse_args()
    random.seed(args.seed)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    industries = list(INDUSTRIES.keys())
    categories = [args.category] if args.category else list(GENERATORS.keys())

    if args.dry_run:
        print("═══ DRY RUN — 10 samples ═══\n")
        for cat in categories:
            industry = random.choice(industries)
            example = GENERATORS[cat](industry)
            print(f"--- [{cat}] [{industry}] ---")
            print(example["text"][:500])
            print()
        return

    print("╔══════════════════════════════════════════════════════════╗")
    print("║     PERSEUS Synthetic Training Data Generator            ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print(f"  Target: {args.examples:,} examples")
    print(f"  Output: {output_dir}")
    print(f"  Categories: {', '.join(categories)}")
    print()

    stats = {cat: 0 for cat in categories}
    batch_size = 10000
    file_index = 0
    total_generated = 0
    start_time = time.time()

    batch = []
    for i in range(args.examples):
        # Weighted category selection
        if args.category:
            cat = args.category
        else:
            cat = random.choices(
                list(CATEGORY_WEIGHTS.keys()),
                weights=list(CATEGORY_WEIGHTS.values()),
                k=1
            )[0]

        industry = random.choice(industries)
        example = GENERATORS[cat](industry)
        batch.append(example)
        stats[cat] += 1
        total_generated += 1

        if len(batch) >= batch_size:
            file_path = output_dir / f"train_{file_index:04d}.jsonl"
            with open(file_path, "w") as f:
                for ex in batch:
                    f.write(json.dumps(ex) + "\n")
            file_index += 1
            batch = []

            elapsed = time.time() - start_time
            rate = total_generated / elapsed
            remaining = (args.examples - total_generated) / rate if rate > 0 else 0
            print(f"  [{total_generated:>8,}/{args.examples:,}] "
                  f"{total_generated * 100 / args.examples:.1f}% — "
                  f"{rate:.0f} examples/sec — "
                  f"~{remaining:.0f}s remaining")

    # Write remaining
    if batch:
        file_path = output_dir / f"train_{file_index:04d}.jsonl"
        with open(file_path, "w") as f:
            for ex in batch:
                f.write(json.dumps(ex) + "\n")

    # Write stats
    elapsed = time.time() - start_time
    summary = {
        "total_examples": total_generated,
        "categories": stats,
        "industries": industries,
        "files": file_index + 1,
        "generation_time_seconds": round(elapsed, 1),
        "generated_at": datetime.utcnow().isoformat(),
        "seed": args.seed,
    }
    with open(output_dir / "stats.json", "w") as f:
        json.dump(summary, f, indent=2)

    print(f"\n  Done! Generated {total_generated:,} examples in {elapsed:.1f}s")
    print(f"  Files: {file_index + 1} JSONL files in {output_dir}")
    print(f"  Stats: {output_dir / 'stats.json'}")
    print(f"\n  Category breakdown:")
    for cat, count in sorted(stats.items(), key=lambda x: -x[1]):
        print(f"    {cat}: {count:,} ({count * 100 / total_generated:.1f}%)")


if __name__ == "__main__":
    main()
