# PERSEUS AGENTS.md
# Cursor reads this before every operation. No exceptions.
# ╔══════════════════════════════════════════════════════════════╗
# ║  HERMES IS NOT DEFINED HERE.                                ║
# ║  Hermes is installed ONLY via the official Nous Research     ║
# ║  script:                                                     ║
# ║    curl -fsSL https://raw.githubusercontent.com/             ║
# ║      NousResearch/hermes-agent/main/scripts/install.sh       ║
# ║      | bash                                                  ║
# ║  Anything calling itself "Hermes" that didn't come from      ║
# ║  that installer is INVALID and a bug.                        ║
# ║  PERSEUS configures Hermes (SOUL.md, cron) — never builds it.║
# ╚══════════════════════════════════════════════════════════════╝

## PROJECT
PERSEUS — autonomous business engine. El Sargento, BCS, MX.
Owner: Nico O.

## ARCHITECTURE OVERVIEW
- Brain: Mac Studio M4 Max (32GB unified RAM). Budget cap $600/month.
- Stack: Ollama (ARM-native, outside Docker) + Docker services
- Models: Qwen2.5 14B Instruct Q4_K_M (~9GB, reasoner),
  Llama 3.2 3B (~2GB, extractor/lightweight, loads on-demand),
  nomic-embed-text (~0.5GB, embeddings, on-demand).
  32GB RAM constraint: only Qwen2.5 14B stays resident. Others load/unload via Ollama.
  NO Qwen3 30B — does not fit in 32GB.
- Memory: Mem0 API (port 8888) + Qdrant vector DB (port 6333)
- Orchestration: N8N (port 5678) → CrewAI async pattern (port 8001)
- Hermes: Native macOS install via Nous Research (NOT Docker, NOT PERSEUS-built)
- World: DEFERRED to Month 5+ (requires RAM upgrade to 48-64GB)
- Docker stack capped at ~4.2GB total to leave room for Ollama models
- RAM budget: OS ~4GB, Docker ≤6GB, Ollama models ≤18-20GB

## PORT TRUTH TABLE
| Service | Port |
|---------|------|
| Mem0 | 8888 |
| CrewAI | 8001 |
| N8N | 5678 |
| Qdrant | 6333 |
| Pinchtab | 9867 |
| Ollama | 11434 |
| Postgres | 5432 |

## BUILD COMMANDS
```
make test      # run test suite
make deploy    # deploy to live stack (approval required first)
make lint      # linting
make skill     # generate new SKILL.md for current agent
make health    # check all service health
```

## DIRECTORY RULES

Builder Agent write access ONLY to:
- /agents/ — agent CrewAI files
- /tools/ — shared tool functions
- /world/ — Three.js world code
- /mobile/ — GrapheneOS app source

NEVER TOUCH (explicit approval required):
- docker-compose.yaml
- soul/
- .env files
- RECOVERY.md
- Any N8N core flow
- Any Postgres/Qdrant schema migration
- Pricing config
- Email sending config

## SOUL LOADING ORDER (mandatory for every agent)
1. soul/soul_values.md       ← always, highest priority
2. soul/soul_agent.md        ← TITAN agents
   soul/soul_hermes.md       ← Hermes only (copied to ~/.hermes/SOUL.md)
   soul/soul_copy.md         ← Copywriter + Sales Closer
3. .agent/skills/titan/*.md  ← progressive disclosure
4. Task context              ← memory reads + lead data

## SKILLS SCOPE WHITELIST
- Deliverables Agent: UI/UX Pro Max
- Builder Agent: Senior Engineering, Clean Architecture, Loki Mode
- Guardrail/Rebuff: Security Audit, OWASP Top 10
- Offer Strategist: Growth & Product, RICE Prioritization
- Sales Closer: Persuasion & Negotiation, Active Listening
- Gap Analyst: Growth & Product, RICE Prioritization
- All agents: Progressive Disclosure, <thinking> chain

DISABLED FOR ALL: infra changes, external git ops, cloud provisioning

## AUTONOMY MODEL

PERSEUS decides and executes everything EXCEPT:
- New recurring cost > $50/mo or one-time > $200
- Production schema changes / LoRA training runs
- Enterprise deal decisions ($50k close, SOW, architecture)
- StrategyConfig changes (boostedNiches, suppressedNiches,
  priceRangeByNiche, activeOffers) → shadow_pending=True for 24h first
- New payment routing destinations → ApprovalRequest regardless of amount

Everything else: act, log it, brief Nico daily.

## COMPLIANCE (NON-NEGOTIABLE)

All outbound emails MUST include:
- Physical mailing address footer (BCS mailing address)
- One-click unsubscribe link (Smartlead native)
- Truthful subject lines (no bait — CAN-SPAM)

Check Lead.unsubscribed = false before writing. If true, do not write. Full stop.
All sending domains MUST have valid SPF/DKIM/DMARC.
No EU-targeted emails after August 2026 without AI disclosure marker.
Log every send to RawEmailLog — no exceptions.

## PRICING (Nico's final decision — non-negotiable)

| Product | Price | Type |
|---------|-------|------|
| Simple 5-page business site | $332 | One-time (door-kicker) |
| Landing page (1-page) | $265 | One-time |
| E-commerce site | $1,330 | One-time |
| Logo + brand kit | $130 | One-time |
| AI chatbot install | $398 | One-time |
| Monthly hosting + maintenance | $52/mo | Recurring |
| Social media content pack | $130/mo | Recurring |

Enterprise ($50k): dormant until Month 10+.
No crypto. No USDC. All revenue → Wise Business → MXN bank account.

## FULL AGENT ROSTER — 30 Agents Across 6 Districts

### OPERATIONS DISTRICT (6 agents)
| Agent | LLM | Schedule | Autonomy |
|-------|-----|----------|----------|
| Lead Researcher | Qwen2.5 14B | Event-driven | Full |
| Copywriter | Qwen2.5 14B | Event-driven | Full |
| Offer Strategist | Qwen2.5 14B | Event-driven | Within StrategyConfig bands |
| Deliverables Agent (3-stage) | Qwen2.5 14B | Event-driven (post-payment) | Full |
| Guardrail Filter + Rebuff | Qwen2.5 14B | Always (intercepts all inbound) | Full |
| QA Checker | Qwen2.5 14B | Event-driven (post-build) | Full |

### SALES DISTRICT (5 agents)
| Agent | LLM | Schedule | Autonomy |
|-------|-----|----------|----------|
| Sales Closer Agent | Qwen2.5 14B | Event-driven (inbound call) | Full for Layer 1 |
| Social Showcase Agent | Qwen2.5 14B | Event-driven (milestone_hit) | Full |
| Voice Delivery Agent | Qwen2.5 14B | Event-driven (payment confirmed) | Full |
| Client Success Agent | Qwen2.5 14B | 30-day cycle + events | Full (upsell: 6hr delay) |
| Payment Router Agent | Llama 3.2 3B | Event-driven (Stripe webhook) | Full for known destinations |

### LEARNING DISTRICT (2 agents)
| Agent | LLM | Schedule | Autonomy |
|-------|-----|----------|----------|
| Reflection Agent | Qwen2.5 14B | Nightly 2 AM | Shadow for high-impact changes |
| Prompt Optimizer | Qwen2.5 14B | Nightly 2 AM | Approval required |

### EVOLUTION DISTRICT (5 agents)
| Agent | LLM | Schedule | Autonomy |
|-------|-----|----------|----------|
| Tech Radar Agent | Qwen2.5 14B | Weekly Sunday 3 AM | Approval for additions |
| Gap Analyst | Qwen2.5 14B | Weekly Sunday 4 AM | Approval for blueprints |
| Architect Agent | Qwen2.5 14B | Event-driven (approved gap) | Full |
| Builder Agent | Qwen2.5 14B | Event-driven (approved blueprint) | Approval before merge |
| System Auditor | Llama 3.2 3B | Weekly Sunday 5 AM | Escalate on regression |

### SELF-AWARENESS DISTRICT — Always Running (3 agents)
These three agents form PERSEUS's immune system. No bug should survive
24 hours in the codebase before being detected and routed to Builder Agent for a fix.
Target: zero undocumented failure modes, ever.

#### Code Auditor Agent
- Runs nightly at 1 AM. READ-ONLY. Never touches code.
- All findings logged as CapabilityGap records.
- Gap Analyst reviews these weekly and routes to Architect → Builder pipeline.
- If Code Auditor finds a CRITICAL gap, fires Telegram alert immediately.

#### Env Validator Agent
- Runs nightly at 1 AM AND after every Builder Agent merge.
- READ-ONLY. Never touches docker-compose.yaml or .env.
- Critical env var gaps fire immediate Telegram alert.
- All findings logged as CapabilityGap records.

#### Builder Test Enforcer
- MANDATORY GATE on every Builder Agent merge attempt.
- Builder Agent MUST POST diff to http://crewai:8001/kickoff/enforce_tests before merge.
- If enforcer returns block_merge: Builder Agent fixes and resubmits. Does NOT bypass.
- If enforcer is unavailable (container down): Builder Agent escalates to Nico via Telegram.
  NO auto-merge without either enforcer sign-off or explicit Nico override.
- Enforcer has write access to /tests/ ONLY.

### ENTERPRISE DISTRICT — DORMANT (8 agents)
Activation: Month 10+ AND Builder Agent ≥3 ships AND 1 case study.
No enterprise sales in first 9 months.
| Agent | Role |
|-------|------|
| Enterprise Lead Researcher | Finds + scores ICP companies for $50k product |
| Enterprise Copywriter | Ultra-personalized 5-touch outreach |
| Enterprise Discovery Prep | Pre-call brief + discovery questions |
| Proposal Generator | Discovery notes → full proposal PDF |
| SOW Generator | Proposal → Statement of Work → contract |
| Deployment Packager | Packages custom system → client-ready bundle |
| Enterprise Hermes Tuner | Configures Hermes for client's team and voice |
| PERSEUS Demo Agent | Spins up sandboxed live demo for sales calls |

### PHASE B (1 agent)
| Agent | Role |
|-------|------|
| Logo Kit Agent | FLUX.1 via ComfyUI — generates professional logo kits |

## CREW REGISTRY RULES

Every new crew MUST be registered with @register_crew("crew_name") in agents/main.py.
Builder Agent is responsible for adding its own registry entry when it ships a new agent.
No crew is callable via N8N until it is in CREW_REGISTRY.

## TEST RULES

Every new agent or tool MUST include at least one test in /tests/.
Builder Agent MUST run `make test` before any merge. If tests fail, do NOT merge.
Test coverage minimum: happy path + one failure/edge case per agent function.

## LORA RULES

LoRA training ALWAYS uses the unquantized BF16 base model.
NEVER train on a GGUF file. NEVER train on the running Ollama model.
Pipeline: BF16 base → LoRA train → merge → quantize → Ollama import → smoke test.
Requires Nico approval before every run.

## WORLD + MOBILE BUILD RULES
- /world/ — Three.js + WebXR. Served on port 3000.
  WebSocket server broadcasts WorldEvents to all clients.
  GLTF models from Mixamo. 3 animations each (idle/walk/talk).
  DEFERRED to Month 5+ (requires RAM upgrade).
- /mobile/ — React Native targeting GrapheneOS (Pixel 9).
  APKs sideloaded via ADB. Builder Agent builds, not deploys.

## ENTERPRISE BUILD RULES
- /agents/enterprise/ — DORMANT until PERSEUS_Enterprise_Activation trigger fires
  (Month 10+ AND 3 successful Builder agent ships).
- Do not activate without explicit Nico approval.
- No enterprise sales in first 9 months.

## SKILL.md FORMAT (Builder Agent Output Template)

Every time Builder Agent ships a new agent, it outputs a SKILL.md:
```
# SKILL: [Agent Name]
version: 1.0
author: Builder Agent
date: YYYY-MM-DD
scope: [operations/sales/learning/evolution/enterprise]
soul_files: [soul_values, soul_agent] # or soul_copy, soul_hermes

## ROLE
[One sentence: what this agent does]
## TOOLS
## MEMORY READS
## MEMORY WRITES
## N8N TRIGGER
## CREWAI PROCESS
## SOUL LOADING ORDER
## TEST CRITERIA
## ROLLBACK PLAN
## AUTONOMY LEVEL
```

## N8N → CrewAI ASYNC PATTERN (mandatory)

N8N fires /kickoff → disconnects immediately. CrewAI calls webhook
back on completion. Avoids N8N 30-60s timeout on long agent tasks.
This is critical. Do not let N8N wait synchronously for CrewAI agent chains.

## THREE-LAYER GUARDRAIL SYSTEM

### Layer 1 — Scope Lock
Builder Agent: /agents/, /tools/, /world/, /mobile/ only.
Production schemas, N8N core flows, email config, pricing → explicit approval required.

### Layer 2 — Approval Gates
Every ApprovalRequest includes goal_alignment tag. Required for:
- CapabilityGap → AgentBlueprint
- Pricing/offer changes above StrategyConfig threshold
- LoRA training runs
- All ProposedAdditions from Tech Radar
- All Superset diffs before merge
- StrategyConfig shadow changes — 24h window, auto-apply if no NO
- New payment routing destinations — regardless of amount

### Layer 3 — Audit + Rollback
- Every agent has rollback pointer
- System Auditor weekly regression tests
- Metric drop >10% → auto ApprovalRequest
- SystemChangeLog append-only
- N8N Error Workflow → Telegram alert for any workflow failure
- Daily N8N health check — detects silent-killer workflow failures
